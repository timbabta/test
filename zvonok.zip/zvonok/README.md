# SmartDialer Flow v2

Система автообзвона для Asterisk с MySQL, несколькими кампаниями и аналитикой IVR (клавиши 1–5).

## Требования

- PHP 7.4+ с PDO MySQL
- MySQL / MariaDB
- Веб-сервер (Apache/Nginx) или `php -S localhost:8080`
- Для Asterisk: mono WAV 8 kHz (конвертация встроена)

## Установка

1. Импортируйте схему БД:
   ```bash
   mysql -u root -p < db_setup.sql
   ```

2. Настройте `config.php`:
   ```php
   $db_host = "localhost";
   $db_user = "root";
   $db_pass = "ваш_пароль";
   $db_name = "smartdialer_db";
   ```

3. Запустите веб-сервер из папки проекта:
   ```bash
   php -S localhost:8080
   ```

4. Откройте `http://localhost:8080/index.html`

## Возможности v2

| Функция | Описание |
|---------|----------|
| **Только БД** | localStorage отключён, все данные в MySQL |
| **Статус БД** | Зелёный/красный индикатор в шапке |
| **Несколько кампаний** | Акция1, Акция2 — независимый запуск/остановка |
| **IVR 1–5** | До 5 цифр + таймаут + ошибка |
| **Сохранить IVR** | Генерирует `extensions_custom.conf` |
| **Excel импорт** | .xlsx — Имя, Фамилия, Телефон |
| **Обзвон в реальном времени** | Пауза / стоп, активные каналы |
| **Аналитика** | История звонков, IVR 1–5, таймаут, ошибка |

## Структура БД

```
campaigns       — кампании (status: idle/running/paused)
contacts        — список для обзвона
audio_files     — WAV + путь на диске
call_history    — история каждого звонка + ivr_result
active_calls    — текущие звонки (live)
logs            — события обзвона
```

## Asterisk

1. Нажмите **Сохранить IVR** — файл `output/extensions_custom.conf`
2. Скопируйте в `/etc/asterisk/extensions_custom.conf`
3. Аудио сохраняется в `sounds/dialer-sounds/{кампания}/`
4. Скопируйте WAV в `/var/lib/asterisk/sounds/dialer-sounds/{кампания}/`
5. `asterisk -rx "dialplan reload"`

## API

- `GET api.php?action=health` — проверка БД
- `GET api.php?action=list_campaigns` — список кампаний
- `POST api.php?action=save_ivr` — сохранить IVR + dialplan
- `POST api.php?action=dialer_start` — запуск обзвона
- `POST api.php?action=dialer_pause` / `dialer_stop`
- `GET api.php?action=get_live_status&id=1` — мониторинг
- `GET api.php?action=get_analytics&id=1` — отчёты
