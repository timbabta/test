<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/dialer_engine.php';

$pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
$dialer = new DialerEngine($pdo, $dialer_mode);

// Тикаем все запущенные кампании
$stmt = $pdo->query("SELECT id FROM campaigns WHERE status = 'running'");
foreach ($stmt->fetchAll() as $row) {
    $dialer->tick(intval($row['id']));
}
