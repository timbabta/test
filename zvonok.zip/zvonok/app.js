/* --- Crocus FLOW v2 — DATABASE MODE --- */

const API_URL = "api.php";
const IVR_KEYS = ["1", "2", "3", "4", "5", "timeout", "invalid"];

let state = {
    campaignId: null,
    campaign: {
        name: "AutoDialer_Promo",
        trunk: "SIP/sip_trunk_name",
        maxCalls: 5,
        waitTime: 45,
        maxRetries: 3,
        retryTime: 60,
        scheduleEnabled: false,
        scheduleTime: "",
        status: "idle"
    },
    nodes: [
        { id: "start", type: "start", name: "Начало звонка", target: "" }
    ],
    contacts: [],
    audioFiles: [],
    logs: [],
    live: {
        status: "idle",
        stats: { answered: 0, retry: 0, failed: 0, total: 0 },
        ivrPressed: { "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "other": 0, "timeout": 0, "invalid": 0, "none": 0 },
        activeCalls: []
    }
};

let dbConnected = false;
let lastApiError = "";
let livePollInterval = null;
let livePollErrorCount = 0;
let dbHealthInterval = null;

const ASTERISK_SAMPLE_RATE = 8000;

// Транслитерация кириллицы → латиница для имён кампаний и файлов
function transliterate(str) {
    const map = {
        'а':'a','б':'b','в':'v','г':'g','д':'d','е':'e','ё':'yo','ж':'zh',
        'з':'z','и':'i','й':'j','к':'k','л':'l','м':'m','н':'n','о':'o',
        'п':'p','р':'r','с':'s','т':'t','у':'u','ф':'f','х':'kh','ц':'ts',
        'ч':'ch','ш':'sh','щ':'sch','ъ':'','ы':'y','ь':'','э':'e','ю':'yu',
        'я':'ya',
        'А':'A','Б':'B','В':'V','Г':'G','Д':'D','Е':'E','Ё':'Yo','Ж':'Zh',
        'З':'Z','И':'I','Й':'J','К':'K','Л':'L','М':'M','Н':'N','О':'O',
        'П':'P','Р':'R','С':'S','Т':'T','У':'U','Ф':'F','Х':'Kh','Ц':'Ts',
        'Ч':'Ch','Ш':'Sh','Щ':'Sch','Ъ':'','Ы':'Y','Ь':'','Э':'E','Ю':'Yu',
        'Я':'Ya'
    };
    return str.split('').map(c => map[c] !== undefined ? map[c] : c).join('');
}

function sanitizeCampaignName(name) {
    return transliterate(name.trim())
        .replace(/\s+/g, '_')          // пробелы → _
        .replace(/[^a-zA-Z0-9_]/g, '') // убираем всё лишнее
        .replace(/_+/g, '_')           // двойные _ → одинарный
        .replace(/^_|_$/g, '');        // убираем _ в начале/конце
}

// --- API CLIENT ---
async function apiCall(action, method = "GET", body = null, query = {}) {
    const params = new URLSearchParams({ action, ...query });
    const opts = { method, headers: { "Content-Type": "application/json" } };
    if (body && method !== "GET") opts.body = JSON.stringify(body);
    const res = await fetch(`${API_URL}?${params}`, opts);
    const text = await res.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        lastApiError = text || e.message;
        throw new Error(lastApiError);
    }
    if (!res.ok || data.success === false) {
        lastApiError = data.error || `HTTP ${res.status}`;
        throw new Error(lastApiError);
    }
    return data;
}

async function checkDbHealth() {
    try {
        const data = await apiCall("health");
        dbConnected = data.success && data.connected;
        updateDbStatusUI(dbConnected);
        return dbConnected;
    } catch (e) {
        lastApiError = e.message || lastApiError;
        dbConnected = false;
        updateDbStatusUI(false);
        return false;
    }
}

function updateDbStatusUI(connected) {
    const dot = document.getElementById("db-status-dot");
    const text = document.getElementById("db-status-text");
    const sidebarDot = document.getElementById("status-indicator-dot");
    if (dot) {
        dot.className = "db-status-dot " + (connected ? "online" : "offline");
    }
    if (text) {
        text.textContent = connected ? "БД подключена" : "БД недоступна";
        text.style.color = connected ? "#10b981" : "#f43f5e";
    }
    if (sidebarDot) {
        sidebarDot.className = "status-indicator " + (connected ? "online" : "offline");
    }
}

async function loadCampaignFromDb(name) {
    const data = await apiCall("get_campaign", "GET", null, { name });
    if (!data.success) throw new Error(data.error || "Ошибка загрузки");
    state.campaignId = data.campaignId;
    state.campaign = data.campaign;
    state.nodes = normalizeNodes(data.nodes);
    state.contacts = data.contacts || [];
    state.audioFiles = data.audioFiles || [];

    state.logs = data.logs || [];
    applyCampaignToForm();
    document.getElementById("active-campaign-name").textContent = state.campaign.name;
    updateContactsSummary();
    renderContactsTable();
    renderAudioPlaylist();
    renderIVRWorkspace();
    generateAsteriskCode();
}

function normalizeNodes(nodes) {
    if (!Array.isArray(nodes) || nodes.length === 0) {
        return [{ id: "start", type: "start", name: "Начало звонка", target: "" }];
    }
    return nodes.map(n => {
        if (n.type === "ivr" && n.branches) {
            IVR_KEYS.forEach(k => {
                if (!(k in n.branches)) n.branches[k] = "";
            });
        }
        return n;
    });
}

function emptyIvrBranches() {
    return { "1": "", "2": "", "3": "", "4": "", "5": "", "timeout": "", "invalid": "" };
}

async function saveCampaignToDb() {
    return apiCall("save_campaign", "POST", {
        campaign: state.campaign,
        nodes: state.nodes
    });
}

async function saveContactsToDb() {
    return apiCall("upload_contacts", "POST", {
        campaignName: state.campaign.name,
        contacts: state.contacts
    });
}

async function refreshCampaignsList() {
    const data = await apiCall("list_campaigns");
    if (!data.success) return;
    const selector = document.getElementById("campaign-selector");
    const container = document.getElementById("campaigns-list-container");
    if (selector) {
        selector.innerHTML = data.campaigns.map(c =>
            `<option value="${c.name}" ${c.name === state.campaign.name ? "selected" : ""}>${c.name} (${c.status})</option>`
        ).join("");
    }
    if (container) {
        container.innerHTML = data.campaigns.map(c => `
            <div class="campaign-list-item">
                <span><strong>${c.name}</strong> — ${c.contacts_count} контактов</span>
                <span style="display:flex;align-items:center;gap:8px;">
                    <span class="status-pill ${c.status}">${c.status}</span>
                    ${c.status === "running" ? `<button class="btn btn-warning btn-small" data-stop-campaign="${c.id}">Стоп</button>` : ""}
                    ${c.status === "running" ? `<button class="btn btn-secondary btn-small" data-pause-campaign="${c.id}">Пауза</button>` : ""}
                </span>
            </div>
        `).join("") || '<span class="text-muted">Нет кампаний</span>';

        container.querySelectorAll("[data-stop-campaign]").forEach(btn => {
            btn.addEventListener("click", async () => {
                await apiCall("dialer_stop", "POST", { campaignId: parseInt(btn.dataset.stopCampaign) });
                await refreshCampaignsList();
                if (parseInt(btn.dataset.stopCampaign) === state.campaignId) await pollLiveStatus();
            });
        });
        container.querySelectorAll("[data-pause-campaign]").forEach(btn => {
            btn.addEventListener("click", async () => {
                await apiCall("dialer_pause", "POST", { campaignId: parseInt(btn.dataset.pauseCampaign) });
                await refreshCampaignsList();
            });
        });
    }
}

function applyCampaignToForm() {
    const c = state.campaign;
    document.getElementById("camp-name").value = c.name;
    document.getElementById("sip-trunk").value = c.trunk;
    document.getElementById("max-calls").value = c.maxCalls;
    document.getElementById("wait-time").value = c.waitTime;
    document.getElementById("max-retries").value = c.maxRetries;
    document.getElementById("retry-time").value = c.retryTime;
    document.getElementById("schedule-enabled").checked = c.scheduleEnabled;
    document.getElementById("schedule-datetime").value = c.scheduleTime || "";
    document.getElementById("schedule-time-container").style.display = c.scheduleEnabled ? "block" : "none";
}

function updateSidebarProgress() {
    const processed = state.contacts.filter(c => c.status !== "Pending").length;
    const remaining = state.contacts.filter(c => c.status === "Pending" || c.status === "Busy").length;
    const el = document.getElementById("sidebar-status-text");
    if (el) el.textContent = `Обработано: ${processed} | Осталось: ${remaining}`;
}

function saveState() {
    // Данные хранятся в MySQL; локальный режим отключён
}

// --- INITIALIZATION ---
document.addEventListener("DOMContentLoaded", async () => {
    initTabs();
    initCampaignSettings();
    initCampaignManager();
    initIVRBuilder();
    initContactsManager();
    initAudioFiles();
    initLiveDialer();
    initReports();
    initExportPage();

    await checkDbHealth();
    dbHealthInterval = setInterval(checkDbHealth, 10000);

    if (dbConnected) {
        try {
            await loadCampaignFromDb("AutoDialer_Promo");
            await refreshCampaignsList();
        } catch (e) {
            alert("Ошибка загрузки кампании: " + e.message);
        }
    } else {
        alert("Не удалось подключиться к базе данных: " + (lastApiError || "проверьте MySQL и db_setup.sql"));
    }
});

// --- NAVIGATION & TABS ---
function initTabs() {
    const menuItems = document.querySelectorAll(".menu-item");
    const tabPanels = document.querySelectorAll(".tab-panel");
    const panelTitle = document.getElementById("panel-title");

    menuItems.forEach(item => {
        item.addEventListener("click", () => {
            const tabName = item.getAttribute("data-tab");
            
            // Toggle active menu class
            menuItems.forEach(i => i.classList.remove("active"));
            item.classList.add("active");
            
            // Toggle active tab panel
            tabPanels.forEach(panel => {
                panel.classList.remove("active");
                if (panel.id === `panel-${tabName}`) {
                    panel.classList.add("active");
                }
            });
            
            // Update panel title
            let title = "Параметры";
            switch (tabName) {
                case "campaigns": title = "Параметры кампании"; break;
                case "ivr": title = "Визуальный конструктор IVR"; break;
                case "contacts": title = "База контактов обзвона"; break;
                case "audio": title = "Аудиозаписи и Конвертер"; break;
                case "live": title = "Панель обзвона"; break;
                case "reports": title = "Аналитика и Отчёты"; break;
                case "export": title = "Экспорт для Asterisk"; break;
            }
            panelTitle.textContent = title;
            

            // Perform context refreshes on tab change
	if (tabName === "ivr") {
                if (dbConnected) {
                    apiCall("get_campaign", "GET", null, { name: state.campaign.name }).then(data => {
                        if (data.success) {
                            state.audioFiles = data.audioFiles || [];
 console.log('audioFiles из БД:', state.audioFiles); 
                        }
                        renderIVRWorkspace();
                    }).catch(() => renderIVRWorkspace());
                } else {
                    renderIVRWorkspace();
                }
            } else if (tabName === "live") {
                startLivePolling();
            } else if (tabName === "reports") {
                updateReportsUI();
            } else if (tabName === "export") {
                generateAsteriskCode();
            } else {
                stopLivePolling();
            }
        });
    });

    // Reset All Button
    document.getElementById("btn-reset-all").addEventListener("click", async () => {
        if (!confirm("Сбросить статистику текущей кампании? Контакты и IVR сохранятся.")) return;
        if (!dbConnected) { alert("БД недоступна"); return; }
        await apiCall("reset_campaign", "GET", null, { name: state.campaign.name });
        await loadCampaignFromDb(state.campaign.name);
        updateLiveDashboardUI();
        updateReportsUI();
        alert("Статистика кампании сброшена");
    });
}

function initCampaignManager() {
    document.getElementById("campaign-selector").addEventListener("change", async (e) => {
        const name = e.target.value;
        if (name && name !== state.campaign.name) {
            await loadCampaignFromDb(name);
            await refreshCampaignsList();
        }
    });

    document.getElementById("btn-new-campaign").addEventListener("click", async () => {
        const name = prompt("Имя новой кампании (без пробелов, например: Akcia_2):");
        if (!name) return;
	const sanitized = sanitizeCampaignName(name);
        const data = await apiCall("create_campaign", "POST", { name: sanitized });
        if (data.success) {
            await loadCampaignFromDb(sanitized);
            await refreshCampaignsList();
            alert("Кампания «" + sanitized + "» создана");
        } else {
            alert(data.error || "Ошибка создания");
        }
    });
}

// --- CAMPAIGN SETTINGS ---
function initCampaignSettings() {
    const nameInput = document.getElementById("camp-name");
    const trunkInput = document.getElementById("sip-trunk");
    const maxCallsInput = document.getElementById("max-calls");
    const waitTimeInput = document.getElementById("wait-time");
    const maxRetriesInput = document.getElementById("max-retries");
    const retryTimeInput = document.getElementById("retry-time");
    const scheduleCheck = document.getElementById("schedule-enabled");
    const scheduleTimeContainer = document.getElementById("schedule-time-container");
    const scheduleTimeInput = document.getElementById("schedule-datetime");
    const saveBtn = document.getElementById("btn-save-settings");
    const activeBadge = document.getElementById("active-campaign-name");

    // Load initial values
    nameInput.value = state.campaign.name;
    trunkInput.value = state.campaign.trunk;
    maxCallsInput.value = state.campaign.maxCalls;
    waitTimeInput.value = state.campaign.waitTime;
    maxRetriesInput.value = state.campaign.maxRetries;
    retryTimeInput.value = state.campaign.retryTime;
    scheduleCheck.checked = state.campaign.scheduleEnabled;
    scheduleTimeInput.value = state.campaign.scheduleTime;
    
    if (state.campaign.scheduleEnabled) {
        scheduleTimeContainer.style.display = "block";
    }
    
    activeBadge.textContent = state.campaign.name;

    scheduleCheck.addEventListener("change", (e) => {
        scheduleTimeContainer.style.display = e.target.checked ? "block" : "none";
    });

    saveBtn.addEventListener("click", async () => {
        if (!dbConnected) { alert("БД недоступна"); return; }
const sanitizedName = sanitizeCampaignName(nameInput.value);
        nameInput.value = sanitizedName;

        state.campaign = {
            ...state.campaign,
            name: sanitizedName,
            trunk: trunkInput.value.trim() || "SIP/sip_trunk_name",
            maxCalls: parseInt(maxCallsInput.value) || 5,
            waitTime: parseInt(waitTimeInput.value) || 45,
            maxRetries: parseInt(maxRetriesInput.value) || 3,
            retryTime: parseInt(retryTimeInput.value) || 60,
            scheduleEnabled: scheduleCheck.checked,
            scheduleTime: scheduleTimeInput.value
        };

        activeBadge.textContent = sanitizedName;
        const result = await saveCampaignToDb();
        if (result.success) {
            await refreshCampaignsList();
            alert("Настройки сохранены в базе данных");
        } else {
            alert(result.error || "Ошибка сохранения");
        }
    });
}

// --- VISUAL IVR BUILDER MODULE ---
let editingNodeId = null;

function initIVRBuilder() {
    const btnAddBlockTypes = document.querySelectorAll(".btn-block-type");
    const modal = document.getElementById("node-settings-modal");
    const btnCloseModal = document.getElementById("btn-close-node-modal");
    const btnSaveNode = document.getElementById("btn-save-node-settings");
    const btnDeleteNode = document.getElementById("btn-delete-node");

    // Add nodes
    btnAddBlockTypes.forEach(btn => {
        btn.addEventListener("click", () => {
            const type = btn.getAttribute("data-type");
            addIVRNode(type);
        });
    });

    // Modal Close
    btnCloseModal.addEventListener("click", () => {
        modal.style.display = "none";
        editingNodeId = null;
    });

    // Save Node Settings
    btnSaveNode.addEventListener("click", () => {
        if (editingNodeId) {
            saveNodeSettings(editingNodeId);
            modal.style.display = "none";
            editingNodeId = null;
            renderIVRWorkspace();
            saveState();
        }
    });
    btnDeleteNode.addEventListener("click", () => {
        if (editingNodeId && editingNodeId !== "start") {
            if (confirm("Вы уверены, что хотите удалить этот блок? Связи с ним будут разорваны.")) {
                deleteIVRNode(editingNodeId);
                modal.style.display = "none";
                editingNodeId = null;
                renderIVRWorkspace();
            }
        }
    });

    document.getElementById("btn-save-ivr").addEventListener("click", async () => {
        if (!dbConnected) { alert("БД недоступна"); return; }
        const statusEl = document.getElementById("ivr-save-status");
        statusEl.textContent = "Сохранение...";
        const result = await apiCall("save_ivr", "POST", {
            campaignName: state.campaign.name,
            nodes: state.nodes
        });
        if (result.success) {
            statusEl.textContent = "✓ Сохранено → " + (result.file || "extensions_custom.conf");
            statusEl.style.color = "#10b981";
            downloadTextFile(result.dialplan, "extensions_custom.conf");
            generateAsteriskCode();
        } else {
            statusEl.textContent = "✗ " + (result.error || "Ошибка");
            statusEl.style.color = "#f43f5e";
        }
    });
}

function downloadTextFile(content, filename) {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function getFriendlyBlockName(type) {
    switch (type) {
        case "start": return "Начало звонка";
        case "play": return "Воспроизведение";
        case "ivr": return "Меню IVR";
        case "tts": return "Озвучка текста";
        case "transfer": return "Перевод";
        case "wait": return "Ожидание";
        case "hangup": return "Завершение";
        default: return "Блок";
    }
}

function addIVRNode(type) {
    const id = `node_${type}_${Date.now()}`;
    const friendlyName = getFriendlyBlockName(type);
    
    let newNode = {
        id: id,
        type: type,
        name: friendlyName,
        target: "" // Default empty target (hang up)
    };

    // Node Type specific defaults
if (type === "play") {
    newNode.audioId = state.audioFiles.length > 0 ? state.audioFiles[0].id : "";
} else if (type === "tts") {
    newNode.text = "Здравствуйте! Это автообзвон.";
} else if (type === "transfer") {
    newNode.destination = "701";
} else if (type === "wait") {
    newNode.seconds = 5;
} else if (type === "ivr") {
    newNode.audioId = state.audioFiles.length > 0 ? state.audioFiles[0].id : "";
    newNode.branches = emptyIvrBranches();
}
    state.nodes.push(newNode);
    saveState();
    renderIVRWorkspace();
}

function deleteIVRNode(nodeId) {
    // Remove the node itself
    state.nodes = state.nodes.filter(n => n.id !== nodeId);
    
    // Scan all other nodes to remove connections pointing to this deleted node
    state.nodes.forEach(n => {
        if (n.target === nodeId) {
            n.target = "";
        }
        if (n.type === "ivr" && n.branches) {
            for (let key in n.branches) {
                if (n.branches[key] === nodeId) {
                    n.branches[key] = "";
                }
            }
        }
    });
    
    saveState();
}

function openNodeSettings(nodeId) {
    if (state.audioFiles.length === 0 && dbConnected) {
        apiCall("get_campaign", "GET", null, { name: state.campaign.name }).then(data => {
            if (data.success) {
                state.audioFiles = data.audioFiles || [];
            }
            openNodeSettings(nodeId);
        });
        return;
    }

    const node = state.nodes.find(n => n.id === nodeId);
    if (!node) return;



    editingNodeId = nodeId;
    const title = document.getElementById("modal-node-title");
    const body = document.getElementById("modal-node-body");
    const btnDelete = document.getElementById("btn-delete-node");

    title.textContent = `Настройки: ${node.name} (${node.id.split("_")[1]})`;
    btnDelete.style.display = nodeId === "start" ? "none" : "block";

    // Build Form Content based on Node Type
    let html = `
        <div class="form-group">
            <label for="node-edit-name">Название блока</label>
            <input type="text" id="node-edit-name" value="${node.name}">
        </div>
    `;

if (node.type === "play" || node.type === "ivr") {
    const audioOptions = state.audioFiles.length > 0
        ? state.audioFiles.map(a =>
            `<option value="${a.id}" ${node.audioId === a.id ? "selected" : ""}>${a.name}</option>`
          ).join("")
        : `<option value="" disabled>Сначала загрузите аудиофайлы на вкладке «Аудиофайлы»</option>`;
html += `
    <div class="form-group">
        <label for="node-edit-audio">Выберите аудиозапись</label>
        <select id="node-edit-audio" style="
            width: 100%;
            padding: 10px 12px;
            background: rgba(0,0,0,0.35);
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 8px;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
            appearance: none;
            -webkit-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2212%22 height=%2212%22 viewBox=%220 0 24 24%22><path fill=%22%23ffffff%22 d=%22M7 10l5 5 5-5z%22/></svg>');
            background-repeat: no-repeat;
            background-position: right 12px center;
            padding-right: 36px;
        ">
            <option value="" style="background:#1e1e2e;">-- Выберите аудиозапись --</option>
            ${state.audioFiles.map(a => `
                <option value="${a.id}"
                    ${node.audioId === a.id ? "selected" : ""}
                    style="background:#1e1e2e; padding: 8px;">
                    🎵 ${a.name} (${a.duration ? a.duration.toFixed(1) + 'с' : '?'})
                </option>
            `).join("")}
        </select>
        ${state.audioFiles.length === 0
            ? `<small style="color:#f87171; margin-top:6px; display:block;">
                Нет аудиофайлов. <a href="#" onclick="switchTab('audio');return false;" style="color:#60a5fa;">Загрузить →</a>
               </small>`
            : `<small style="color:#86efac; margin-top:6px; display:block;">
                ${state.audioFiles.length} файл(ов) доступно
               </small>`
        }
    </div>
`;
}

    if (node.type === "tts") {
        html += `
            <div class="form-group">
                <label for="node-edit-text">Текст для озвучки (TTS)</label>
                <textarea id="node-edit-text" style="width: 100%; height: 80px; background: rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.1); border-radius:6px; padding:8px; color:#fff;">${node.text || ""}</textarea>
                <small>Будет прочитан синтезатором речи при входящем звонке</small>
            </div>
        `;
    }

    if (node.type === "transfer") {
        html += `
            <div class="form-group">
                <label for="node-edit-dest">Назначение перевода звонка</label>
                <input type="text" id="node-edit-dest" value="${node.destination || ""}" placeholder="Например: 701, Queue/operator или SIP/101">
                <small>Куда направить клиента в Asterisk (например, номер очереди или транк оператора)</small>
            </div>
        `;
    }

    if (node.type === "wait") {
        html += `
            <div class="form-group">
                <label for="node-edit-sec">Время ожидания (секунды)</label>
                <input type="number" id="node-edit-sec" value="${node.seconds || 5}" min="1" max="60">
            </div>
        `;
    }

    // Modal Content loaded, display it
    body.innerHTML = html;
    document.getElementById("node-settings-modal").style.display = "flex";
}

function saveNodeSettings(nodeId) {
    const node = state.nodes.find(n => n.id === nodeId);
    if (!node) return;

    const nameInput = document.getElementById("node-edit-name");
    node.name = nameInput.value.trim() || getFriendlyBlockName(node.type);

    if (node.type === "play" || node.type === "ivr") {
        const audioSelect = document.getElementById("node-edit-audio");
        node.audioId = audioSelect.value;
    }

    if (node.type === "tts") {
        const textInput = document.getElementById("node-edit-text");
        node.text = textInput.value;
    }

    if (node.type === "transfer") {
        const destInput = document.getElementById("node-edit-dest");
        node.destination = destInput.value.trim();
    }

    if (node.type === "wait") {
        const secInput = document.getElementById("node-edit-sec");
        node.seconds = parseInt(secInput.value) || 5;
    }
}

function renderIVRWorkspace() {
    const canvas = document.getElementById("ivr-canvas");
    
    // Clear and restore start node
    canvas.innerHTML = "";
    
    // Generate Dropdown list options for all nodes (excluding target loop-back)
    const getNodeOptions = (currentNodeId, selectedId) => {
        return state.nodes
            .filter(n => n.id !== currentNodeId)
            .map(n => `<option value="${n.id}" ${selectedId === n.id ? "selected" : ""}>${n.name} [${n.type.toUpperCase()}]</option>`)
            .join("");
    };

    // Render node cards
    state.nodes.forEach(node => {
        const card = document.createElement("div");
        card.className = `ivr-card ${node.type}-card`;
        card.id = `workspace-card-${node.id}`;

        // Header
        const header = document.createElement("div");
        header.className = "node-header";
        
        const badge = document.createElement("span");
        badge.className = "node-badge";
        badge.textContent = node.type.toUpperCase();
        
        const title = document.createElement("h4");
        title.textContent = node.name;
        
        header.appendChild(badge);
        header.appendChild(header.appendChild(title));

        if (node.type !== "start") {
            const btnSettings = document.createElement("button");
            btnSettings.className = "node-btn-settings";
            btnSettings.innerHTML = `
                <svg viewBox="0 0 24 24" width="14" height="14"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z" fill="currentColor"/></svg>
            `;
            btnSettings.addEventListener("click", () => openNodeSettings(node.id));
            header.appendChild(btnSettings);
        }
        card.appendChild(header);

        // Body
        const body = document.createElement("div");
        body.className = "node-body";

        // Display quick info
        let info = document.createElement("div");
        info.className = "node-info-text";
        
        switch (node.type) {
            case "start":
                info.textContent = "Начало дозвона";
                body.appendChild(info);
                break;
            case "play":
console.log('render play node:', node.audioId, 'audioFiles:', state.audioFiles);
                const audio = state.audioFiles.find(a => a.id === node.audioId);
                info.textContent = audio ? `Звук: ${audio.name}` : "⚠️ Аудиозапись не выбрана";
                body.appendChild(info);
                break;
            case "tts":
                info.textContent = node.text ? `Синтез: "${node.text.slice(0, 40)}${node.text.length > 40 ? "..." : ""}"` : "⚠️ Текст пуст";
                body.appendChild(info);
                break;
            case "transfer":
                info.textContent = `На номер: ${node.destination || "[Пусто]"}`;
                body.appendChild(info);
                break;
            case "wait":
                info.textContent = `Задержка: ${node.seconds || 5} сек.`;
                body.appendChild(info);
                break;
            case "hangup":
                info.textContent = "Обрыв соединения";
                body.appendChild(info);
                break;
        }

        // Branching or Next Target Connections
        if (node.type !== "hangup" && node.type !== "transfer" && node.type !== "ivr") {
            const connGroup = document.createElement("div");
            connGroup.className = "form-group";
            connGroup.style.marginTop = "12px";
            connGroup.style.marginBottom = "0px";
            
            const connLabel = document.createElement("label");
            connLabel.textContent = "Далее переходим к:";
            
            const select = document.createElement("select");
            select.className = "node-connector";
            select.setAttribute("data-node", node.id);
            select.innerHTML = `
                <option value="">-- Повесить трубку --</option>
                ${getNodeOptions(node.id, node.target)}
            `;
            
            select.addEventListener("change", (e) => {
                node.target = e.target.value;
                saveState();
            });

            connGroup.appendChild(connLabel);
            connGroup.appendChild(select);
            body.appendChild(connGroup);
        } else if (node.type === "ivr") {
            // Render branches
            const branchBox = document.createElement("div");
            branchBox.className = "node-ivr-branches";
            
            const keys = ["1", "2", "3", "4", "5", "timeout", "invalid"];
            keys.forEach(key => {
                const row = document.createElement("div");
                row.className = "ivr-branch-row";
                
                const label = document.createElement("span");
                label.className = "branch-key";
                if (key === "timeout") label.textContent = "T";
                else if (key === "invalid") label.textContent = "i";
                else label.textContent = key;
                
                const select = document.createElement("select");
                select.className = "node-connector-branch";
                select.setAttribute("data-node", node.id);
                select.setAttribute("data-branch", key);
                select.innerHTML = `
                    <option value="">-- Обрыв --</option>
                    ${getNodeOptions(node.id, node.branches[key])}
                `;
                
                select.addEventListener("change", (e) => {
                    node.branches[key] = e.target.value;
                    saveState();
                });
                
                row.appendChild(label);
                row.appendChild(select);
                branchBox.appendChild(row);
            });
            body.appendChild(branchBox);
        }

        card.appendChild(body);
        canvas.appendChild(card);
    });
}

// --- CRM DATABASE & CONTACTS MANAGER ---
function initContactsManager() {
    const dropzone = document.getElementById("csv-dropzone");
    const fileInput = document.getElementById("csv-file-input");
    const clearBtn = document.getElementById("btn-clear-contacts");
    const searchInput = document.getElementById("contact-search");

    // Click to choose file
    dropzone.addEventListener("click", () => fileInput.click());

    // File Drag and Drop events
    dropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropzone.classList.add("dragover");
    });

    dropzone.addEventListener("dragleave", () => {
        dropzone.classList.remove("dragover");
    });

    dropzone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropzone.classList.remove("dragover");
        const file = e.dataTransfer.files[0];
        if (file) handleContactsUpload(file);
    });

    fileInput.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) handleContactsUpload(file);
    });

    // Clear contacts
    clearBtn.addEventListener("click", async () => {
        if (confirm("Вы действительно хотите очистить всю базу контактов?")) {
            state.contacts = [];
            if (dbConnected) await saveContactsToDb();
            updateContactsSummary();
            renderContactsTable();
            updateSidebarProgress();
        }
    });

    // Search contacts
    searchInput.addEventListener("input", (e) => {
        renderContactsTable(e.target.value.trim());
    });

    // Download CSV template
document.getElementById("btn-download-template-csv").addEventListener("click", () => {
    const csv = "\ufeffИмя,Фамилия,Телефон,Дата_Рождения\n"
        + "Иван,Иванов,+79991234567,25.05.1990\n"
        + "Анна,Смирнова,+79997654321,12.08.1995\n"
        + "Петр,Петров,+79990001122,03.11.1988\n";
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "contacts_template.csv";
    link.click();
});

document.getElementById("btn-download-template-xlsx").addEventListener("click", () => {
    const rows = [
        ["Имя", "Фамилия", "Телефон", "Дата_Рождения"],
        ["Иван", "Иванов", "+79991234567", "25.05.1990"],
        ["Анна", "Смирнова", "+79997654321", "12.08.1995"],
        ["Петр", "Петров", "+79990001122", "03.11.1988"],
    ];
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(rows);
    ws["!cols"] = [{ wch: 16 }, { wch: 16 }, { wch: 18 }, { wch: 16 }];
    XLSX.utils.book_append_sheet(wb, ws, "Контакты");
    XLSX.writeFile(wb, "contacts_template.xlsx");
});
}

function handleContactsUpload(file) {
    const ext = file.name.split(".").pop().toLowerCase();
    if (ext === "csv") {
        handleCSVUpload(file);
    } else if (ext === "xlsx" || ext === "xls") {
        handleExcelUpload(file);
    } else {
        alert("Поддерживаются форматы CSV и Excel (.xlsx)");
    }
}

function handleExcelUpload(file) {
    const reader = new FileReader();
    reader.onload = async function(e) {
        try {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: "array" });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });
            if (rows.length < 2) {
                alert("Файл Excel пуст или содержит только заголовок");
                return;
            }
            const newContacts = [];
            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                if (!row || row.length < 3) continue;
                const contact = parseContactRow(row[0], row[1], row[2], row[3]);
                if (contact) newContacts.push(contact);
            }
            await applyImportedContacts(newContacts);
        } catch (err) {
            alert("Ошибка чтения Excel: " + err.message);
        }
    };
    reader.readAsArrayBuffer(file);
}

function parseContactRow(name, lastName, phone, birthDate) {
    name = String(name || "").trim();
    lastName = String(lastName || "").trim();
    let phoneStr = String(phone || "").trim().replace(/[^0-9+]/g, "");
    if (phoneStr.startsWith("8") && phoneStr.length === 11) phoneStr = "+7" + phoneStr.slice(1);
    else if (!phoneStr.startsWith("+") && phoneStr.length === 10) phoneStr = "+7" + phoneStr;
    if (!name || !phoneStr) return null;
    return {
        name, lastName, phone: phoneStr,
        birthDate: birthDate ? String(birthDate).trim() : "",
        status: "Pending", tries: 0
    };
}

async function applyImportedContacts(newContacts) {
    if (newContacts.length === 0) {
        alert("Не удалось импортировать контакты. Проверьте колонки: Имя, Фамилия, Телефон");
        return;
    }
    state.contacts = newContacts;
    if (dbConnected) {
        const result = await saveContactsToDb();
        if (!result.success) { alert(result.error); return; }
    }
    updateContactsSummary();
    renderContactsTable();
    updateSidebarProgress();
    alert("Загружено номеров: " + newContacts.length);
}

function handleCSVUpload(file) {
    const readerUtf = new FileReader();
    readerUtf.onload = function(e) {
        const text = e.target.result;
        // Если есть символ замены — файл не в UTF-8, пробуем windows-1251
        if (text.includes('\uFFFD')) {
            const readerWin = new FileReader();
            readerWin.onload = function(e2) { parseCSVText(e2.target.result); };
            readerWin.readAsText(file, "windows-1251");
        } else {
            parseCSVText(text);
        }
    };
    readerUtf.readAsText(file, "UTF-8");
}

function parseCSVText(text) {
    const lines = text.split(/\r\n|\n/);
    if (lines.length < 2) {
        alert("Файл CSV слишком короткий или пуст!");
        return;
    }

    const newContacts = [];
    // Start reading lines (skip header)
    for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        // Smart split taking into account commas/semicolons
        let parts = line.split(",");
        if (parts.length < 3) {
            parts = line.split(";"); // Try semicolon fallback
        }

        if (parts.length >= 3) {
            const name = parts[0].trim();
            const lastName = parts[1].trim();
            // Sanitize phone number (remove spaces, braces, dashes)
            let phone = parts[2].trim().replace(/[^0-9+]/g, "");
            
            // Format phone number to standard: +7...
            if (phone.startsWith("8") && phone.length === 11) {
                phone = "+7" + phone.slice(1);
            } else if (!phone.startsWith("+") && phone.length === 10) {
                phone = "+7" + phone;
            }

            const birthDate = parts[3] ? parts[3].trim() : "Не указана";

            if (name && phone) {
                newContacts.push({
                    name: name,
                    lastName: lastName,
                    phone: phone,
                    birthDate: birthDate,
                    status: "Pending", // Pending, Answered, Busy, Failed
                    tries: 0
                });
            }
        }
    }

    if (newContacts.length > 0) {
        applyImportedContacts(newContacts);
    } else {
        alert("Не удалось импортировать контакты. Проверьте соответствие CSV шаблону.");
    }
}

function updateContactsSummary() {
    const totalEl = document.getElementById("contacts-count-total");
    const validEl = document.getElementById("contacts-count-valid");
    
    totalEl.textContent = state.contacts.length;
    validEl.textContent = state.contacts.filter(c => c.phone.length >= 10).length;
}

function renderContactsTable(searchQuery = "") {
    const tbody = document.getElementById("contacts-list-tbody");
    tbody.innerHTML = "";

    let filtered = state.contacts;
    if (searchQuery) {
        const q = searchQuery.toLowerCase();
        filtered = state.contacts.filter(c => 
            c.name.toLowerCase().includes(q) || 
            c.lastName.toLowerCase().includes(q) || 
            c.phone.includes(q)
        );
    }

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted">Контакты не найдены.</td></tr>`;
        return;
    }

    filtered.forEach((contact, index) => {
        const tr = document.createElement("tr");
        
        let statusBadge = `<span class="badge badge-pending">Ожидание</span>`;
        if (contact.status === "Answered") statusBadge = `<span class="badge badge-success">Успешно</span>`;
        else if (contact.status === "Busy") statusBadge = `<span class="badge badge-warning">Занято (${contact.tries})</span>`;
        else if (contact.status === "Failed") statusBadge = `<span class="badge badge-danger">Сбой</span>`;

        tr.innerHTML = `
            <td><strong>${contact.name}</strong></td>
            <td>${contact.lastName || ""}</td>
            <td><code>${contact.phone}</code></td>
            <td>${contact.birthDate || "-"}</td>
            <td>${statusBadge}</td>
            <td>
                <button class="btn-delete-row" data-index="${index}">
                    <svg viewBox="0 0 24 24" width="14" height="14"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" fill="currentColor"/></svg>
                </button>
            </td>
        `;

        tr.querySelector(".btn-delete-row").addEventListener("click", () => {
            if (confirm("Удалить контакт из списка?")) {
                state.contacts.splice(index, 1);
                saveState();
                updateContactsSummary();
                renderContactsTable(searchQuery);
            }
        });

        tbody.appendChild(tr);
    });
}

// --- AUDIO FILES & WAV CONVERTER ENGINE ---
function initAudioFiles() {
    const dropzone = document.getElementById("audio-dropzone");
    const fileInput = document.getElementById("audio-file-input");

    dropzone.addEventListener("click", () => fileInput.click());

    dropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropzone.classList.add("dragover");
    });

    dropzone.addEventListener("dragleave", () => {
        dropzone.classList.remove("dragover");
    });

    dropzone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropzone.classList.remove("dragover");
        const file = e.dataTransfer.files[0];
        if (file && file.type.startsWith("audio/")) {
            convertAndSaveAudio(file);
        } else {
            alert("Пожалуйста, загрузите валидный аудиофайл!");
        }
    });

    fileInput.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) {
            convertAndSaveAudio(file);
        }
    });
}

function audioLog(text, type = "success") {
    const logsContainer = document.getElementById("audio-logs");
    const line = document.createElement("div");
    line.style.color = type === "error" ? "var(--danger)" : "var(--success)";
    line.textContent = `[${new Date().toLocaleTimeString()}] ${text}`;
    logsContainer.appendChild(line);
    logsContainer.scrollTop = logsContainer.scrollHeight;
}

// Resamples uploaded file to Mono 8kHz 16-bit PCM WAV compatible with Asterisk
function convertAndSaveAudio(file) {
    audioLog(`Начало импорта файла: ${file.name}...`);
    audioLog(`Размер файла: ${(file.size / 1024 / 1024).toFixed(2)} MB`);

    const reader = new FileReader();
    reader.onload = function(e) {
        const arrayBuffer = e.target.result;
        
        // Initialize Web Audio API context
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        const audioCtx = new AudioContext();
        
        audioLog("Декодирование аудиоданных в буфер...");
        audioCtx.decodeAudioData(arrayBuffer, function(decodedBuffer) {
            audioLog(`Файл успешно декодирован. Каналов: ${decodedBuffer.numberOfChannels}, Частота: ${decodedBuffer.sampleRate}Гц`);
            audioLog(`Продолжительность записи: ${decodedBuffer.duration.toFixed(1)} сек.`);
            audioLog("Запуск ресемплирования в Mono 8000Гц (Asterisk PCM Standard)...");

            // Offline Audio Context to Resample to 8000Hz mono
            const offlineCtx = new OfflineAudioContext(
                1, // 1 channel
                ASTERISK_SAMPLE_RATE * decodedBuffer.duration,
                ASTERISK_SAMPLE_RATE
            );

            // Create buffer source
            const bufferSource = offlineCtx.createBufferSource();
            bufferSource.buffer = decodedBuffer;
            bufferSource.connect(offlineCtx.destination);
            bufferSource.start();

            offlineCtx.startRendering().then(function(renderedBuffer) {
                audioLog("Ресемплирование завершено успешно.");
                audioLog("Кодирование в 16-bit linear PCM WAV формат...");

                // Convert Float32Array to 16-bit PCM WAV Binary Blob
                const wavBlob = encodeWAV16BitPCM(renderedBuffer);
                audioLog("Кодирование завершено. Сборка WAV файла готова!");

                // Make Base64 data to store in state
                const readerBase64 = new FileReader();
                readerBase64.onloadend = async function() {
                    const base64data = readerBase64.result;
                    const audioId = `audio_${Date.now()}`;

                    // originalName — исходное имя файла, которое видит пользователь
                    const originalName = file.name;
                    // safeName — только безопасные символы, используется как имя файла на диске
                    const safeName = file.name.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9_]/g, "_") + ".wav";

                    state.audioFiles.push({
                        id: audioId,
                        name: originalName,       // показываем пользователю оригинальное имя
                        safeName: safeName,        // для диалплана Asterisk
                        duration: decodedBuffer.duration,
                        sizeBytes: wavBlob.size,
                        data: base64data
                    });

                    renderAudioPlaylist();
                    audioLog(`Файл ${originalName} добавлен в список.`);

                    if (dbConnected) {
                        audioLog(`Сохранение на сервер...`);
                        try {
                            const result = await apiCall("upload_audio", "POST", {
                                campaignName: state.campaign.name,
                                audio: {
                                    id: audioId,
                                    originalName: originalName,   // имя для отображения
                                    name: safeName,               // безопасное имя для диска
                                    duration: decodedBuffer.duration,
                                    sizeBytes: wavBlob.size,
                                    data: base64data
                                }
                            });
                            if (result.success) {
                                audioLog(`✓ Файл сохранён на сервере: ${result.filePath}`);
                                alert(`Файл «${originalName}» успешно сконвертирован и сохранён!`);
                            } else {
                                audioLog(`✗ Ошибка сохранения на сервере: ${result.error}`, "error");
                                alert(`Ошибка сохранения: ${result.error}`);
                            }
                        } catch (err) {
                            audioLog(`✗ Ошибка соединения с сервером: ${err.message}`, "error");
                        }
                    } else {
                        alert(`Файл «${originalName}» успешно сконвертирован (БД недоступна, сохранено локально).`);
                    }
                };
                readerBase64.readAsDataURL(wavBlob);

            }).catch(function(err) {
                audioLog(`Ошибка ресемплирования: ${err.message}`, "error");
            });

        }, function(err) {
            audioLog(`Ошибка декодирования файла: ${err.message}. Проверьте кодек.`, "error");
        });
    };
    reader.readAsArrayBuffer(file);
}

// JS WAV Encoder Function (RIFF Header + 16bit Linear PCM)
function encodeWAV16BitPCM(audioBuffer) {
    const channelData = audioBuffer.getChannelData(0); // Mono channel
    const buffer = new ArrayBuffer(44 + channelData.length * 2);
    const view = new DataView(buffer);

    /* RIFF identifier */
    writeString(view, 0, 'RIFF');
    /* file length */
    view.setUint32(4, 36 + channelData.length * 2, true);
    /* RIFF type */
    writeString(view, 8, 'WAVE');
    /* format chunk identifier */
    writeString(view, 12, 'fmt ');
    /* format chunk length */
    view.setUint32(16, 16, true);
    /* sample format (raw PCM = 1) */
    view.setUint16(20, 1, true);
    /* channel count (Mono = 1) */
    view.setUint16(22, 1, true);
    /* sample rate */
    view.setUint32(24, ASTERISK_SAMPLE_RATE, true);
    /* byte rate (sample rate * block align) */
    view.setUint32(28, ASTERISK_SAMPLE_RATE * 2, true);
    /* block align (channel count * bytes per sample) */
    view.setUint16(32, 2, true);
    /* bits per sample */
    view.setUint16(34, 16, true);
    /* data chunk identifier */
    writeString(view, 36, 'data');
    /* data chunk length */
    view.setUint32(40, channelData.length * 2, true);

    // Write Float PCM samples mapped to Int16 PCM samples
    floatTo16BitPCM(view, 44, channelData);

    return new Blob([view], { type: 'audio/wav' });
}

function floatTo16BitPCM(output, offset, input) {
    for (let i = 0; i < input.length; i++, offset += 2) {
        let s = Math.max(-1, Math.min(1, input[i]));
        output.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
}

function writeString(view, offset, string) {
    for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
    }
}

function renderAudioPlaylist() {
    const container = document.getElementById("audio-list-container");
    container.innerHTML = "";

    if (state.audioFiles.length === 0) {
        container.innerHTML = `
            <div class="no-audio-msg text-center text-muted">
                Аудиофайлы не загружены. Загрузите файлы для озвучки IVR.
            </div>
        `;
        return;
    }

    state.audioFiles.forEach((audio) => {
        const item = document.createElement("div");
        item.className = "audio-item";
        
        const sizeMb = (audio.sizeBytes / 1024 / 1024).toFixed(2);
        // Показываем оригинальное имя файла пользователю
        const displayName = audio.name || audio.safeName || 'audio.wav';
        
        item.innerHTML = `
            <div class="audio-item-info">
                <span class="audio-name" title="${displayName}">${displayName}</span>
                <span class="audio-meta">${audio.duration.toFixed(1)} сек | ${sizeMb} MB | Mono 8kHz</span>
            </div>
            <canvas class="audio-waveform-canvas" id="canvas-wave-${audio.id}"></canvas>
            <div class="audio-actions">
                <button class="btn-play-pause" id="btn-play-${audio.id}">
                    <svg viewBox="0 0 24 24" id="play-icon-${audio.id}"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>
                </button>
                <button class="btn btn-secondary btn-small" id="btn-dl-${audio.id}">WAV</button>
                <button class="btn-delete-row" id="btn-del-audio-${audio.id}">
                    <svg viewBox="0 0 24 24" width="14" height="14"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" fill="currentColor"/></svg>
                </button>
            </div>
        `;

        container.appendChild(item);

        // Drawing beautiful static Waveform preview
        drawStaticWaveform(audio.id);

        // Play/Pause Action
        const playBtn = item.querySelector(`#btn-play-${audio.id}`);
        const playIcon = item.querySelector(`#play-icon-${audio.id}`);
        let playing = false;
        let audioHTMLObj = null;

        playBtn.addEventListener("click", () => {
            if (!playing) {
                // Pause all other plays
                document.querySelectorAll(".btn-play-pause").forEach(b => {
                    if (b.id !== `btn-play-${audio.id}`) {
                        b.innerHTML = `<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>`;
                    }
                });

                audioHTMLObj = new Audio(audio.data);
                audioHTMLObj.play();
                playIcon.innerHTML = `<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" fill="currentColor"/>`;
                playing = true;

                audioHTMLObj.onended = () => {
                    playIcon.innerHTML = `<path d="M8 5v14l11-7z" fill="currentColor"/>`;
                    playing = false;
                };
            } else {
                if (audioHTMLObj) {
                    audioHTMLObj.pause();
                }
                playIcon.innerHTML = `<path d="M8 5v14l11-7z" fill="currentColor"/>`;
                playing = false;
            }
        });

        // Download Converted WAV
        item.querySelector(`#btn-dl-${audio.id}`).addEventListener("click", () => {
            const link = document.createElement("a");
            link.href = audio.data;
            link.setAttribute("download", audio.name);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });

        // Delete Audio
        item.querySelector(`#btn-del-audio-${audio.id}`).addEventListener("click", async () => {
            if (confirm(`Вы действительно хотите удалить запись ${audio.name}?`)) {
                if (dbConnected) await apiCall("delete_audio", "GET", null, { id: audio.id });
                state.audioFiles = state.audioFiles.filter(a => a.id !== audio.id);
                state.nodes.forEach(n => {
                    if (n.audioId === audio.id) n.audioId = "";
                });
                renderAudioPlaylist();
            }
        });
    });
}

// Function to draw simple decorative wave lines on canvas
function drawStaticWaveform(audioId) {
    const canvas = document.getElementById(`canvas-wave-${audioId}`);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    
    // Set width according to element display
    canvas.width = canvas.offsetWidth;
    canvas.height = 40;

    ctx.fillStyle = "rgba(139, 92, 246, 0.15)";
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const barsCount = 40;
    const barWidth = 3;
    const gap = 2;
    const padding = (canvas.width - (barsCount * (barWidth + gap))) / 2;

    for (let i = 0; i < barsCount; i++) {
        // Generate pseudo random waves heights
        const height = Math.abs(Math.sin(i * 0.15) * 25) + Math.random() * 8 + 4;
        const x = padding + i * (barWidth + gap);
        const y = (canvas.height - height) / 2;

        ctx.fillStyle = i % 2 === 0 ? "#8b5cf6" : "#3b82f6";
        ctx.fillRect(x, y, barWidth, height);
    }
}

// --- LIVE DIALER (SERVER + DB) ---
function initLiveDialer() {
    document.getElementById("btn-live-start").addEventListener("click", () => startDialer());
    document.getElementById("btn-live-pause").addEventListener("click", () => pauseDialer());
    document.getElementById("btn-live-stop").addEventListener("click", () => stopDialer());
    document.getElementById("btn-clear-terminal").addEventListener("click", () => {
        document.getElementById("live-terminal-logs").innerHTML = "";
    });
}

function startLivePolling() {
    if (livePollInterval) return;
    livePollErrorCount = 0;
    pollLiveStatus();
    livePollInterval = setInterval(pollLiveStatus, 2000);
}

function stopLivePolling() {
    if (livePollInterval) {
        clearInterval(livePollInterval);
        livePollInterval = null;
    }
}

async function pollLiveStatus() {
    if (!dbConnected || !state.campaignId) return;
    try {
        const data = await apiCall("get_live_status", "GET", null, { id: state.campaignId });
        if (!data.success) return;
        livePollErrorCount = 0;
        state.live.status = data.status;
        state.live.stats = data.stats || state.live.stats;
        state.live.activeCalls = (data.activeCalls || []).map(c => ({
            id: c.id,
            name: c.contact_name.split(" ")[0] || "",
            lastName: c.contact_name.split(" ").slice(1).join(" ") || "",
            phone: c.phone,
            status: c.status === "talking" ? "talking" : "dialing",
            duration: parseInt(c.duration_sec) || 0,
            currentNodeId: c.current_node || "start"
        }));
        if (data.logs) {
            renderTerminalLogs(data.logs);
        }
        updateLiveDashboardUI();
        updateSidebarProgress();
        syncLiveButtons(data.status);
    } catch (e) {
        livePollErrorCount++;
        if (livePollErrorCount >= 3) {
            stopLivePolling();
            addTerminalLine("error", `Live status stopped: ${e.message}`);
        }
    }
}

function addTerminalLine(type, text) {
    const terminal = document.getElementById("live-terminal-logs");
    if (!terminal) return;
    const row = document.createElement("div");
    row.className = `terminal-log log-${type}`;
    row.textContent = `[${new Date().toLocaleTimeString()}] ${text}`;
    terminal.appendChild(row);
    terminal.scrollTop = terminal.scrollHeight;
}

function renderTerminalLogs(logs) {
    const terminal = document.getElementById("live-terminal-logs");
    if (!terminal) return;
    terminal.innerHTML = logs.map(l =>
        `<div class="terminal-line ${l.type}">[${l.time}] [${l.type.toUpperCase()}] ${l.text}</div>`
    ).join("");
    terminal.scrollTop = terminal.scrollHeight;
}

function syncLiveButtons(status) {
    document.getElementById("btn-live-start").disabled = status === "running";
    document.getElementById("btn-live-pause").disabled = status !== "running";
    document.getElementById("btn-live-stop").disabled = status === "idle";
}

async function startDialer() {
    if (!dbConnected) { alert("БД недоступна"); return; }
    if (state.contacts.length === 0) {
        alert("Загрузите список контактов перед началом обзвона");
        return;
    }
    const result = await apiCall("dialer_start", "POST", { campaignId: state.campaignId });
    if (result.success) {
        startLivePolling();
        await pollLiveStatus();
    } else {
        alert(result.error || "Не удалось запустить");
    }
}

async function pauseDialer() {
    await apiCall("dialer_pause", "POST", { campaignId: state.campaignId });
    await pollLiveStatus();
}

async function stopDialer() {
    await apiCall("dialer_stop", "POST", { campaignId: state.campaignId });
    await pollLiveStatus();
    await refreshCampaignsList();
}

function addLog(type, text) {
    const terminal = document.getElementById("live-terminal-logs");
    if (!terminal) return;
    const time = new Date().toLocaleTimeString();
    const line = document.createElement("div");
    line.className = `terminal-line ${type}`;
    line.textContent = `[${time}] [${type.toUpperCase()}] ${text}`;
    terminal.appendChild(line);
    terminal.scrollTop = terminal.scrollHeight;
}

function resetSimulationStats() {
    state.live.currentIndex = 0;
    state.live.stats = { answered: 0, retry: 0, failed: 0 };
    state.contacts.forEach(c => {
        c.status = "Pending";
        c.tries = 0;
    });
    state.live.ivrPressed = { "1": 0, "2": 0, "3": 0, "other": 0, "timeout": 0 };
    saveState();
}

function startSimulation() {
    if (state.contacts.length === 0) {
        alert("Загрузите список контактов во вкладке CRM перед началом обзвона!");
        return;
    }

    // If campaign was already fully finished, reset statistics
    const hasPending = state.contacts.some(c => c.status === "Pending");
    if (!hasPending) {
        if (confirm("Все звонки уже завершены. Начать обзвон сначала?")) {
            resetSimulationStats();
            renderContactsTable();
        } else {
            return;
        }
    }

    state.live.status = "running";
    addLog("system", "Автообзвон запущен!");
    
    document.getElementById("btn-live-start").disabled = true;
    document.getElementById("btn-live-pause").disabled = false;
    document.getElementById("btn-live-stop").disabled = false;

    updateLiveDashboardUI();

    // Start Worker Loop running every 3 seconds to simulate line processing
    liveInterval = setInterval(() => {
        processSimulationStep();
    }, 3000);
}

function pauseSimulation() {
    state.live.status = "paused";
    addLog("system", "Кампания временно приостановлена пользователем.");
    
    clearInterval(liveInterval);
    
    document.getElementById("btn-live-start").disabled = false;
    document.getElementById("btn-live-pause").disabled = true;
    document.getElementById("btn-live-stop").disabled = false;
    
    updateLiveDashboardUI();
}

function stopSimulation() {
    state.live.status = "idle";
    addLog("system", "Обзвон завершён/остановлен.");
    
    clearInterval(liveInterval);
    
    // Clear active channels
    state.live.activeCalls = [];
    // Reset phone ring
    hangupPhoneCall();

    document.getElementById("btn-live-start").disabled = false;
    document.getElementById("btn-live-pause").disabled = true;
    document.getElementById("btn-live-stop").disabled = true;
    
    updateLiveDashboardUI();
}

// Simulation Dialer Core logic
function processSimulationStep() {
    if (state.live.status !== "running") return;

    // 1. Maintain concurrently running channels (up to maxCalls)
    while (state.live.activeCalls.length < state.campaign.maxCalls) {
        // Find next pending contact or retryable contact
        const nextContact = state.contacts.find(c => 
            c.status === "Pending" || 
            (c.status === "Busy" && c.tries < state.campaign.maxRetries)
        );

        if (!nextContact) {
            // No more contacts!
            if (state.live.activeCalls.length === 0) {
                addLog("system", "Все контакты в базе обзвонены. Кампания завершена!");
                stopSimulation();
            }
            break;
        }

        // Lock contact and originate a simulated call
        const contactIndex = state.contacts.indexOf(nextContact);
        nextContact.tries++;
        
        const newCall = {
            id: `call_${Date.now()}_${contactIndex}`,
            contactIndex: contactIndex,
            name: nextContact.name,
            lastName: nextContact.lastName,
            phone: nextContact.phone,
            status: "dialing", // dialing, connected, talking, hangup
            duration: 0,
            currentNodeId: "start"
        };

        state.live.activeCalls.push(newCall);
        addLog("dial", `Звоним контакту: ${nextContact.name} ${nextContact.lastName} (${nextContact.phone}) [Линия ${state.live.activeCalls.length}]`);
    }

    // 2. Process active calls states
    state.live.activeCalls.forEach((call, index) => {
        call.duration += 3; // Add seconds per interval step

        if (call.status === "dialing") {
            // Decide call outcomes: 60% answer, 25% busy, 15% failed
            const rand = Math.random();
            if (rand < 0.6) {
                call.status = "talking";
                call.currentNodeId = "start"; // Start block
                
                state.contacts[call.contactIndex].status = "Answered";
                state.live.stats.answered++;
                addLog("answer", `Номер ${call.phone} ОТВЕТИЛ! Выполняем логику IVR...`);

                // Dynamic Phone simulation hook!
                // Connect ONE call to the virtual telephone widget so user can interact!
                if (state.live.phoneState === "idle") {
                    setupVirtualPhoneCall(call);
                }

            } else if (rand < 0.85) {
                // Busy / retry path
                call.status = "hangup";
                state.contacts[call.contactIndex].status = "Busy";
                state.live.stats.retry++;
                addLog("ivr", `Номер ${call.phone} занят. Будет повторная попытка дозвона через ${state.campaign.retryTime} сек.`);
            } else {
                // Failed / error path
                call.status = "hangup";
                state.contacts[call.contactIndex].status = "Failed";
                state.live.stats.failed++;
                addLog("hangup", `Абонент ${call.phone} недоступен. Звонок завершен ошибкой.`);
            }
        } else if (call.status === "talking") {
            // Progress automatic execution of IVR for background simulated callers
            // Skip the one interactive caller that is hooked to the virtual phone!
            const isHookedToPhone = state.live.phoneCall && state.live.phoneCall.id === call.id;
            
            if (!isHookedToPhone) {
                executeAutoIVRStep(call);
            }
        }
    });

    // 3. Filter out hung up calls
    state.live.activeCalls = state.live.activeCalls.filter(call => call.status !== "hangup");

    updateLiveDashboardUI();
    saveState();
}

// Background Simulated automatic IVR steps
function executeAutoIVRStep(call) {
    const node = state.nodes.find(n => n.id === call.currentNodeId);
    if (!node) {
        call.status = "hangup";
        return;
    }

    if (node.type === "start") {
        call.currentNodeId = node.target || "hangup";
    } else if (node.type === "play" || node.type === "tts" || node.type === "wait") {
        // Go to next target
        call.currentNodeId = node.target || "hangup";
    } else if (node.type === "transfer" || node.type === "hangup") {
        call.status = "hangup";
        if (node.type === "transfer") {
            addLog("ivr", `Вызов ${call.phone} успешно переведён на номер оператора: ${node.destination}`);
        }
    } else if (node.type === "ivr") {
        // Pseudo-random user DTMF key press in IVR
        const keys = ["1", "2", "3", "timeout"];
        const pressed = keys[Math.floor(Math.random() * keys.length)];
        
        if (pressed === "timeout") {
            state.live.ivrPressed.timeout++;
            call.currentNodeId = node.branches.timeout || "hangup";
            addLog("ivr", `Абонент ${call.phone} не выбрал опцию (таймаут IVR)`);
        } else {
            if (node.branches[pressed]) {
                state.live.ivrPressed[pressed]++;
                call.currentNodeId = node.branches[pressed];
                addLog("ivr", `Абонент ${call.phone} нажал клавишу [${pressed}]`);
            } else {
                state.live.ivrPressed.other++;
                call.currentNodeId = node.branches.invalid || "hangup";
                addLog("ivr", `Абонент ${call.phone} ввёл некорректную клавишу [${pressed}]`);
            }
        }
    }

    if (call.currentNodeId === "hangup" || call.currentNodeId === "") {
        call.status = "hangup";
    }
}

// --- VIRTUAL TELEPHONE SIMULATOR CODES ---
function setupVirtualPhoneCall(call) {
    state.live.phoneCall = call;
    state.live.phoneState = "ringing";
    
    document.getElementById("phone-screen-idle").style.display = "none";
    document.getElementById("phone-screen-ringing").style.display = "flex";
    document.getElementById("phone-screen-connected").style.display = "none";

    document.getElementById("phone-ring-name").textContent = `${call.name} ${call.lastName}`;
    document.getElementById("phone-ring-number").textContent = call.phone;
    
    // Put initials on avatar
    const initials = (call.name[0] || "") + (call.lastName[0] || "");
    document.getElementById("phone-ring-avatar").textContent = initials.toUpperCase();
}

function acceptPhoneCall() {
    if (state.live.phoneState !== "ringing" || !state.live.phoneCall) return;

    state.live.phoneState = "connected";
    state.live.phoneCall.status = "talking";
    state.live.phoneCall.currentNodeId = "start";
    state.live.phoneDuration = 0;

    document.getElementById("phone-screen-ringing").style.display = "none";
    document.getElementById("phone-screen-connected").style.display = "flex";
    
    document.getElementById("phone-conn-name").textContent = `${state.live.phoneCall.name} ${state.live.phoneCall.lastName}`;
    
    // Play Ringback beep in JS
    playSineBeep(800, 0.2);

    // Run counter timer
    state.live.phoneTimer = setInterval(() => {
        state.live.phoneDuration++;
        const mins = String(Math.floor(state.live.phoneDuration / 60)).padStart(2, '0');
        const secs = String(state.live.phoneDuration % 60).padStart(2, '0');
        document.getElementById("phone-conn-duration").textContent = `${mins}:${secs}`;
    }, 1000);

    // Start executing the connected call IVR steps visually!
    executeInteractiveIVR();
}

function declinePhoneCall() {
    if (state.live.phoneState !== "ringing" || !state.live.phoneCall) return;
    
    state.live.phoneCall.status = "hangup";
    addLog("hangup", `Сброшен вызов абонента ${state.live.phoneCall.phone}`);
    
    hangupPhoneCall();
}

function hangupPhoneCall() {
    if (state.live.phoneTimer) {
        clearInterval(state.live.phoneTimer);
        state.live.phoneTimer = null;
    }
    
    if (state.live.phoneCall) {
        state.live.phoneCall.status = "hangup";
    }

    state.live.phoneCall = null;
    state.live.phoneState = "idle";
    state.live.phoneDuration = 0;

    document.getElementById("phone-screen-idle").style.display = "flex";
    document.getElementById("phone-screen-ringing").style.display = "none";
    document.getElementById("phone-screen-connected").style.display = "none";

    // Clean active nodes visualization highlight
    document.querySelectorAll(".ivr-card").forEach(c => c.classList.remove("node-active"));
}

function playSineBeep(freq = 600, duration = 0.1) {
    try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        const ctx = new AudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start();
        osc.stop(ctx.currentTime + duration);
    } catch(e) {}
}

function executeInteractiveIVR() {
    const call = state.live.phoneCall;
    if (!call || state.live.phoneState !== "connected") return;

    // Remove old highlights
    document.querySelectorAll(".ivr-card").forEach(c => c.classList.remove("node-active"));

    const node = state.nodes.find(n => n.id === call.currentNodeId);
    if (!node) {
        hangupPhoneCall();
        return;
    }

    // Highlight the card currently executing in yellow!
    const nodeCard = document.getElementById(`workspace-card-${node.id}`);
    if (nodeCard) {
        nodeCard.classList.add("node-active");
    }

    document.getElementById("phone-audio-wave").classList.remove("active");

    if (node.type === "start") {
        addLog("ivr", `[Симулятор] Контакт ${call.phone} вошел в автообзвон`);
        setTimeout(() => {
            call.currentNodeId = node.target || "hangup";
            executeInteractiveIVR();
        }, 1000);
        
    } else if (node.type === "play") {
        const audio = state.audioFiles.find(a => a.id === node.audioId);
        document.getElementById("phone-current-audio-name").textContent = audio ? audio.name : "без_звука.wav";
        
        if (audio) {
            document.getElementById("phone-audio-wave").classList.add("active");
            addLog("ivr", `[Симулятор] Воспроизведение звука: ${audio.name}`);
            
            // Play actual audio track through speaker!
            const sound = new Audio(audio.data);
            sound.play();
            
            // Proceed to next node after audio finished
            sound.onended = () => {
                document.getElementById("phone-audio-wave").classList.remove("active");
                call.currentNodeId = node.target || "hangup";
                executeInteractiveIVR();
            };
        } else {
            // Proceed instantly if no audio
            setTimeout(() => {
                call.currentNodeId = node.target || "hangup";
                executeInteractiveIVR();
            }, 1000);
        }
        
    } else if (node.type === "tts") {
        document.getElementById("phone-current-audio-name").textContent = "TTS: Озвучка речи";
        addLog("ivr", `[Симулятор] Синтез речи: "${node.text}"`);

        // Check if Web Speech API exists for local synthesis!
        if ('speechSynthesis' in window && node.text) {
            document.getElementById("phone-audio-wave").classList.add("active");
            const utterance = new SpeechSynthesisUtterance(node.text);
            utterance.lang = "ru-RU";
            window.speechSynthesis.speak(utterance);
            
            utterance.onend = () => {
                document.getElementById("phone-audio-wave").classList.remove("active");
                call.currentNodeId = node.target || "hangup";
                executeInteractiveIVR();
            };
        } else {
            // Safe timeout fallback
            setTimeout(() => {
                call.currentNodeId = node.target || "hangup";
                executeInteractiveIVR();
            }, 1500);
        }

    } else if (node.type === "wait") {
        document.getElementById("phone-current-audio-name").textContent = `Пауза (${node.seconds} сек)`;
        addLog("ivr", `[Симулятор] Блок задержки на ${node.seconds} секунд...`);
        
        setTimeout(() => {
            call.currentNodeId = node.target || "hangup";
            executeInteractiveIVR();
        }, node.seconds * 1000);

    } else if (node.type === "transfer") {
        document.getElementById("phone-current-audio-name").textContent = "Перевод вызова";
        addLog("ivr", `[Симулятор] Переадресация на номер: ${node.destination}`);
        playSineBeep(900, 0.4);
        
        setTimeout(() => {
            alert(`[Симулятор звонка] Абонент переведён на номер оператора: ${node.destination}!`);
            hangupPhoneCall();
        }, 1500);

    } else if (node.type === "hangup") {
        addLog("ivr", `[Симулятор] Завершение вызова.`);
        playSineBeep(300, 0.5);
        setTimeout(() => {
            hangupPhoneCall();
        }, 1000);

    } else if (node.type === "ivr") {
        const audio = state.audioFiles.find(a => a.id === node.audioId);
        document.getElementById("phone-current-audio-name").textContent = audio ? `${audio.name} (ожидание ввода)` : "Голосовое меню IVR";
        addLog("ivr", `[Симулятор] Вошли в голосовое меню. Ждем нажатия клавиш 1, 2 или 3...`);

        if (audio) {
            document.getElementById("phone-audio-wave").classList.add("active");
            const sound = new Audio(audio.data);
            sound.play();
            sound.onended = () => {
                document.getElementById("phone-audio-wave").classList.remove("active");
            };
        }

        // If no keys pressed, trigger timeout route in 6 seconds
        state.live.ivrTimeoutTimer = setTimeout(() => {
            if (state.live.phoneCall && state.live.phoneCall.currentNodeId === node.id) {
                state.live.ivrPressed.timeout++;
                addLog("ivr", `[Симулятор] Истекло время ввода (Таймаут IVR)`);
                call.currentNodeId = node.branches.timeout || "hangup";
                executeInteractiveIVR();
            }
        }, 6000);
    }
}

function pressDTMFKey(key) {
    const call = state.live.phoneCall;
    if (!call || state.live.phoneState !== "connected") return;

    const node = state.nodes.find(n => n.id === call.currentNodeId);
    if (!node || node.type !== "ivr") return;

    // Clear timeout timers
    if (state.live.ivrTimeoutTimer) {
        clearTimeout(state.live.ivrTimeoutTimer);
    }

    // Play DTMF beep
    playSineBeep(697 + key.charCodeAt(0) * 4, 0.15);

    addLog("ivr", `[Симулятор] Пользователь нажал клавишу: [${key}]`);

    if (key === "1" || key === "2" || key === "3") {
        if (node.branches[key]) {
            state.live.ivrPressed[key]++;
            call.currentNodeId = node.branches[key];
        } else {
            state.live.ivrPressed.other++;
            call.currentNodeId = node.branches.invalid || "hangup";
        }
    } else {
        // Other buttons (*, #, 0, etc.)
        state.live.ivrPressed.other++;
        call.currentNodeId = node.branches.invalid || "hangup";
    }

    executeInteractiveIVR();
}

function updateLiveDashboardUI() {
    const indicator = document.getElementById("live-state-indicator");
    const statusText = document.getElementById("live-state-text");
    const status = state.live.status;

    indicator.className = "live-state-indicator " + (status === "running" ? "running" : status === "paused" ? "paused" : "idle");
    statusText.textContent = status === "running" ? "Обзвон запущен" : status === "paused" ? "Приостановлен" : "Остановлен";

    const stats = state.live.stats;
    document.getElementById("live-metric-total").textContent = state.contacts.length;
    document.getElementById("live-metric-answered").textContent = stats.answered || 0;
    document.getElementById("live-metric-retry").textContent = stats.retry || 0;
    document.getElementById("live-metric-failed").textContent = stats.failed || 0;

    const processedCount = (stats.answered || 0) + (stats.retry || 0) + (stats.failed || 0);
    const progressPercent = state.contacts.length > 0 ? Math.min(100, Math.round((processedCount / state.contacts.length) * 100)) : 0;
    document.getElementById("live-progress-percent").textContent = `${progressPercent}%`;
    document.getElementById("live-progress-bar").style.width = `${progressPercent}%`;

    const grid = document.getElementById("active-channels-container");
    grid.innerHTML = "";
    const activeCalls = state.live.activeCalls || [];
    document.getElementById("live-active-channels-count").textContent = activeCalls.length;
    document.getElementById("live-max-channels-count").textContent = state.campaign.maxCalls;

    if (activeCalls.length === 0) {
        grid.innerHTML = `<div class="no-active-calls-msg text-center text-muted">Нет активных вызовов. Запустите обзвон.</div>`;
        return;
    }

    activeCalls.forEach(call => {
        const node = document.createElement("div");
        node.className = `active-call-node ${call.status}`;
        const initials = ((call.name || "")[0] || "") + ((call.lastName || "")[0] || "");
        const minutes = String(Math.floor(call.duration / 60)).padStart(2, "0");
        const seconds = String(call.duration % 60).padStart(2, "0");
        const currentNode = state.nodes.find(n => n.id === call.currentNodeId);
        node.innerHTML = `
            <div class="call-node-header">
                <div class="call-node-avatar">${initials.toUpperCase()}</div>
                <div class="call-node-duration">${minutes}:${seconds}</div>
            </div>
            <div class="call-node-details">
                <span class="call-node-name">${call.name} ${call.lastName}</span>
                <code class="call-node-phone">${call.phone}</code>
            </div>
            <div class="call-node-status-row">
                <span>Статус: <strong>${call.status === "talking" ? "Разговор" : "Вызов"}</strong></span>
                <span class="call-node-active-block">${currentNode ? currentNode.name : "Начало"}</span>
            </div>`;
        grid.appendChild(node);
    });
}

// --- ANALYTICS & REPORTS PAGE MODULE ---
function initReports() {
    document.getElementById("btn-export-excel").addEventListener("click", () => exportToCSV());
    document.getElementById("btn-export-pdf").addEventListener("click", () => {
        window.print(); // Triggers customized CSS styled A4 printing dashboard
    });
    ["report-date-from", "report-date-to", "report-phone-filter", "report-status-filter", "report-ivr-filter"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener("input", () => updateReportsUI());
    });
    const resetBtn = document.getElementById("btn-report-reset");
    if (resetBtn) {
        resetBtn.addEventListener("click", () => {
            ["report-date-from", "report-date-to", "report-phone-filter", "report-status-filter", "report-ivr-filter"].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = "";
            });
            updateReportsUI();
        });
    }
}

async function updateReportsUI() {
    if (!dbConnected || !state.campaignId) return;

    const filters = {
        id: state.campaignId,
        date_from: document.getElementById("report-date-from")?.value || "",
        date_to: document.getElementById("report-date-to")?.value || "",
        phone: document.getElementById("report-phone-filter")?.value || "",
        dial_status: document.getElementById("report-status-filter")?.value || "",
        ivr_result: document.getElementById("report-ivr-filter")?.value || "",
    };
    const data = await apiCall("get_analytics", "GET", null, filters);
    if (!data.success) return;

    const stats = data.stats;
    const totalCalls = (stats.answered || 0) + (stats.retry || 0) + (stats.failed || 0);
    const ansPct = totalCalls > 0 ? Math.round((stats.answered / totalCalls) * 100) : 0;
    const busyPct = totalCalls > 0 ? Math.round((stats.retry / totalCalls) * 100) : 0;
    const failPct = totalCalls > 0 ? Math.min(100, 100 - ansPct - busyPct) : 0;

    document.getElementById("report-conversion-percent").textContent = `${ansPct}%`;
    document.getElementById("report-legend-ans").textContent = `${stats.answered || 0} (${ansPct}%)`;
    document.getElementById("report-legend-busy").textContent = `${stats.retry || 0} (${busyPct}%)`;
    document.getElementById("report-legend-fail").textContent = `${stats.failed || 0} (${failPct}%)`;

    const donutAns = document.getElementById("donut-segment-ans");
    const donutBusy = document.getElementById("donut-segment-busy");
    const donutFail = document.getElementById("donut-segment-fail");
    if (donutAns && donutBusy && donutFail) {
        donutAns.setAttribute("stroke-dasharray", `${ansPct} 100`);
        donutBusy.setAttribute("stroke-dasharray", `${busyPct} 100`);
        donutBusy.setAttribute("stroke-dashoffset", `${100 - ansPct + 25}`);
        donutFail.setAttribute("stroke-dasharray", `${failPct} 100`);
        donutFail.setAttribute("stroke-dashoffset", `${100 - ansPct - busyPct + 25}`);
    }

    const ivr = data.ivrPressed || {};
    const keys = ["1", "2", "3", "4", "5", "other", "timeout", "none"];
    const totalPresses = keys.reduce((s, k) => s + (ivr[k] || 0), 0) + (ivr.invalid || 0);
    const ivrAll = { ...ivr, other: (ivr.other || 0) + (ivr.invalid || 0) };

    keys.forEach(k => {
        const val = ivrAll[k] || 0;
        const pct = totalPresses > 0 ? Math.round((val / totalPresses) * 100) : 0;
        const fillBar = document.getElementById(`bar-ivr-${k}`);
        const textBar = document.getElementById(`bar-ivr-${k}-text`);
        if (fillBar && textBar) {
            fillBar.style.width = `${pct}%`;
            textBar.textContent = `${pct}% (${val})`;
        }
    });

    const tbody = document.getElementById("report-history-tbody");
    tbody.innerHTML = "";
    const history = data.history || [];

    if (history.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" class="text-center text-muted">Звонки не найдены.</td></tr>`;
        return;
    }

    const ivrLabels = {
        "1": "Нажал 1", "2": "Нажал 2", "3": "Нажал 3", "4": "Нажал 4", "5": "Нажал 5",
        timeout: "Таймаут", invalid: "Ошибся", none: "Без ввода"
    };

    history.forEach(row => {
        let statusBadge = `<span class="badge badge-pending">${row.dial_status}</span>`;
        if (row.dial_status === "Answered") statusBadge = `<span class="badge badge-success">Отвечено</span>`;
        else if (row.dial_status === "Busy") statusBadge = `<span class="badge badge-warning">Занято</span>`;
        else if (row.dial_status === "Failed") statusBadge = `<span class="badge badge-danger">Ошибка</span>`;

        const dur = row.duration_sec || 0;
        const mins = String(Math.floor(dur / 60)).padStart(2, "0");
        const secs = String(dur % 60).padStart(2, "0");
        const recording = row.recording_url
            ? `<a href="${row.recording_url}" target="_blank" rel="noopener">WAV</a>`
            : (row.recording_file ? `<span title="${row.recording_file}">WAV</span>` : "—");
        const timeline = formatCallTimeline(row.events || []);
        const ivrText = row.ivr_result ? (ivrLabels[row.ivr_result] || row.ivr_result) : "—";
        const started = row.started_at ? new Date(row.started_at.replace(" ", "T")).toLocaleString("ru-RU") : "—";

        tbody.innerHTML += `<tr>
            <td><strong>${row.name} ${row.last_name || ""}</strong></td>
            <td><code>${row.phone}</code></td>
            <td>${started}</td>
            <td>${statusBadge}</td>
            <td>${row.tries || 1}</td>
            <td>${ivrText}</td>
            <td>${mins}:${secs}</td>
            <td>${recording}</td>
            <td class="timeline-cell">${timeline}</td>
        </tr>`;
    });
}

function formatCallTimeline(events) {
    if (!events.length) return "—";
    const labels = {
        answered: "Ответил",
        node_enter: "Этап",
        dtmf: "Нажал",
        timeout: "Таймаут",
        invalid: "Ошибка ввода",
        transfer_start: "Перевод",
        transfer_end: "Итог перевода",
        hangup: "Завершил",
        final: "Итог",
    };

    return events.map(event => {
        const label = labels[event.event_type] || event.event_type;
        const parts = [label];
        if (event.dtmf_digit) parts.push(event.dtmf_digit);
        if (event.node_name && event.node_name !== "Final status") parts.push(event.node_name);
        if (event.destination) parts.push(`→ ${event.destination}`);
        return `<span class="timeline-chip">${parts.join(" ")}</span>`;
    }).join("");
}

function exportToCSV() {
    let csvContent = "\ufeffИмя,Телефон,Результат Звонка,Количество Попыток,Дата Вызова\n";
    state.contacts.forEach(c => {
        csvContent += `${c.name} ${c.lastName || ""},${c.phone},${c.status},${c.tries},${new Date().toLocaleDateString()}\n`;
    });

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", `crocus_report_${state.campaign.name}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// --- ASTERISK CONFIGURATION & CODE GENERATORS ---
let activeCodeTab = "dialplan";

function initExportPage() {
    const tabs = document.querySelectorAll(".code-tab-btn");
    const displayArea = document.getElementById("code-display-area");
    
    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
            activeCodeTab = tab.getAttribute("data-code");
            
            generateAsteriskCode();
        });
    });

    // Copy Code button
    document.getElementById("btn-copy-code").addEventListener("click", () => {
        const code = displayArea.textContent;
        navigator.clipboard.writeText(code).then(() => {
            alert("Код успешно скопирован в буфер обмена!");
        });
    });

    // Download buttons
    document.getElementById("btn-download-dialplan").addEventListener("click", async () => {
        let dialplan = buildDialplanText();
        if (dbConnected) {
            const data = await apiCall("get_dialplan", "GET", null, { name: state.campaign.name });
            if (data.success) dialplan = data.dialplan;
        }
        downloadTextFile(dialplan, "extensions_custom.conf");
    });

    document.getElementById("btn-download-shell-script").addEventListener("click", () => {
        const shell = buildShellScriptText();
        const blob = new Blob([shell], { type: "text/plain;charset=utf-8" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.setAttribute("download", "run_dialer.sh");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });
}

function generateAsteriskCode() {
    const displayArea = document.getElementById("code-display-area");
    if (!displayArea) return;
    if (activeCodeTab === "dialplan") {
        displayArea.textContent = buildDialplanText();
        if (dbConnected) {
            apiCall("get_dialplan", "GET", null, { name: state.campaign.name }).then(data => {
                if (data.success) displayArea.textContent = data.dialplan;
            });
        }
    } else {
        displayArea.textContent = buildShellScriptText();
    }
}

// Transpiles block diagram to extensions_custom.conf (sub-context per node)
function buildDialplanText() {
const camp = sanitizeCampaignName(state.campaign.name);
    let code = `; extensions_custom.conf — ${camp}\n\n`;
    code += `[dialer-outbound-${camp}]\n`;
    code += `exten => s,1,Dial(${state.campaign.trunk}/\${NUM},${state.campaign.waitTime},t)\n`;
    code += ` same => n,GotoIf($["\${DIALSTATUS}" = "ANSWER"]?ok:end)\n`;
    code += ` same => n(ok),Goto(dialer-ivr-${camp},s,1)\n`;
    code += ` same => n(end),Hangup()\n\n`;
    code += `[dialer-ivr-${camp}]\n`;
    const startNode = state.nodes.find(n => n.id === "start");
    code += `exten => s,1,Answer()\n`;
    code += startNode && startNode.target
        ? ` same => n,Goto(dialer-ivr-${camp}-${startNode.target},s,1)\n\n`
        : ` same => n,Hangup()\n\n`;
    state.nodes.forEach(node => {
        if (node.id !== "start") code += buildNodeContextDialplan(camp, node);
    });
    return code;
}

function buildNodeContextDialplan(camp, node) {
    const ctx = `dialer-ivr-${camp}-${node.id}`;
    let code = `[${ctx}]\n`;
    const gotoNext = (t) => t ? ` same => n,Goto(dialer-ivr-${camp}-${t},s,1)\n` : ` same => n,Hangup()\n`;
    
const getSound = (id) => {
    const a = state.audioFiles.find(x => x.id === id);
    if (!a) return "intro";
    if (a.filePath) {
        // /var/lib/asterisk/sounds/custom/Camp/file.wav → custom/Camp/file
        const p = a.filePath.replace(/\.[^/.]+$/, "");
        const m = p.match(/\/sounds\/(.+)$/);
        return m ? m[1] : p.split("/").pop();
    }
    return a.name.replace(/\.[^/.]+$/, "");
};
    switch (node.type) {
        case "play":
code += `exten => s,1,Playback(${getSound(node.audioId)})\n` + gotoNext(node.target);
            break;
        case "tts":
            code += `exten => s,1,Festival("${(node.text || "").replace(/"/g, '\\"')}")\n` + gotoNext(node.target);
            break;
        case "wait":
            code += `exten => s,1,Wait(${node.seconds || 5})\n` + gotoNext(node.target);
            break;
        case "transfer":
            code += `exten => s,1,Dial(Local/${node.destination || "701"}@from-internal,60,tr)\n same => n,Hangup()\n`;
            break;
        case "hangup":
            code += `exten => s,1,Hangup()\n`;
            break;
        case "ivr":
code += `exten => s,1,Background(${getSound(node.audioId)})\n same => n,WaitExten(10)\n`;            
            for (let i = 1; i <= 5; i++) {
                const k = String(i);
                if (node.branches && node.branches[k]) {
                    code += `exten => ${k},1,Goto(dialer-ivr-${camp}-${node.branches[k]},s,1)\n`;
                }
            }
            code += `exten => t,1,` + (node.branches?.timeout ? `Goto(dialer-ivr-${camp}-${node.branches.timeout},s,1)\n` : `Hangup()\n`);
            code += `exten => i,1,` + (node.branches?.invalid ? `Goto(dialer-ivr-${camp}-${node.branches.invalid},s,1)\n` : `Hangup()\n`);
            break;
        default:
            code += `exten => s,1,Hangup()\n`;
    }
    return code + "\n";
}

// Generates high quality Bash Shell Script with contacts database embedded
// Uses live active channels checking on Asterisk rather than sub-minute crons
function buildShellScriptText() {
    const camp = state.campaign.name;
    const trunk = state.campaign.trunk;
    const maxCalls = state.campaign.maxCalls;
    const maxRetries = state.campaign.maxRetries;
    const retryTime = state.campaign.retryTime;

    let code = `#!/bin/bash\n`;
    code += `#====================================================================\n`;
    code += `# СКРИПТ АВТООБЗВОНА ДЛЯ ASTERISK (CALL FILES GENERATOR)\n`;
    code += `# Создано для кампании: ${camp}\n`;
    code += `# Ограничение: ${maxCalls} одновременных звонков | Канал: ${trunk}\n`;
    code += `#====================================================================\n\n`;

    code += `# --- ПАРАМЕТРЫ ОБЗВОНА ---\n`;
    code += `CAMP_NAME="${camp}"\n`;
    code += `TRUNK="${trunk}"\n`;
    code += `MAX_CHANNELS=${maxCalls}\n`;
    code += `WAIT_TIME=${state.campaign.waitTime}\n`;
    code += `MAX_RETRIES=${maxRetries}\n`;
    code += `RETRY_TIME=${retryTime}\n`;
    code += `SPOOL_DIR="/var/spool/asterisk/outgoing"\n`;
    code += `TMP_DIR="/tmp/asterisk_dialer_${camp}"\n\n`;

    code += `# Создание временной папки\n`;
    code += `mkdir -p \$TMP_DIR\n\n`;

    code += `# --- БАЗА КОНТАКТОВ ДЛЯ ОБЗВОНА ---\n`;
    code += `declare -A contacts\n`;
    
    // Embed contacts database
    if (state.contacts.length === 0) {
        code += `# Внимание: База контактов пуста! Загрузите номера перед экспортом.\n`;
        code += `contacts[0]="Иван;Иванов;+79991234567"\n`;
    } else {
        state.contacts.forEach((c, idx) => {
            code += `contacts[${idx}]="${c.name};${c.lastName || ""};${c.phone}"\n`;
        });
    }
    
    code += `TOTAL_CONTACTS=\${#contacts[@]}\n\n`;

    code += `echo "Запуск автообзвона для кампании '\$CAMP_NAME'..."\n`;
    code += `echo "Всего номеров к обработке: \$TOTAL_CONTACTS"\n\n`;

    code += `# --- ОСНОВНОЙ РАБОЧИЙ ЦИКЛ ОБЗВОНА ---\n`;
    code += `for (( i=0; i<\$TOTAL_CONTACTS; i++ )); do\n`;
    code += `    # Разбираем данные контакта\n`;
    code += `    IFS=';' read -r -a contact_info <<< "\${contacts[\$i]}"\n`;
    code += `    NAME="\${contact_info[0]}"\n`;
    code += `    LASTNAME="\${contact_info[1]}"\n`;
    code += `    PHONE="\${contact_info[2]}"\n\n`;

    code += `    # Проверка загруженности каналов Asterisk перед созданием нового вызова\n`;
    code += `    while true; do\n`;
    code += `        # Считаем количество активных Local-каналов обзвона в консоли Asterisk\n`;
    code += `        ACTIVE_CHANNELS=\$(asterisk -rx "core show channels" | grep -c "Local/s@dialer-outbound-\$CAMP_NAME")\n`;
    code += `        if [ \$ACTIVE_CHANNELS -lt \$MAX_CHANNELS ]; then\n`;
    code += `            break\n`;
    code += `        fi\n`;
    code += `        # Если линии забиты, спим 2 секунды перед повторной проверкой\n`;
    code += `        sleep 2\n`;
    code += `    done\n\n`;

    code += `    echo "[\$(date +%T)] Инициируем вызов №\$i: \$NAME \$LASTNAME (\$PHONE)..."\n\n`;

    code += `    # --- ГЕНЕРАЦИЯ CALL FILE ---\n`;
    code += `    CALLFILE="\$TMP_DIR/\${i}_\${CAMP_NAME}_\${PHONE}.call"\n`;
    code += `    cat <<EOT > \$CALLFILE\n`;
    code += `Channel: Local/s@dialer-outbound-\$CAMP_NAME\n`;
    code += `CallerID: "\$NAME \$LASTNAME" <\$PHONE>\n`;
    code += `MaxRetries: \$MAX_RETRIES\n`;
    code += `RetryTime: \$RETRY_TIME\n`;
    code += `WaitTime: \$WAIT_TIME\n`;
    code += `Context: dialer-ivr-\$CAMP_NAME\n`;
    code += `Extension: s\n`;
    code += `Priority: 1\n`;
    code += `Set: NUM=\$PHONE\n`;
    code += `Set: NAME=\$NAME\n`;
    code += `Set: LASTNAME=\$LASTNAME\n`;
    code += `Archive: Yes\n`;
    code += `EOT\n\n`;

    code += `    # Даем права доступа для Asterisk и переносим в spool директорию\n`;
    code += `    chown asterisk:asterisk \$CALLFILE\n`;
    code += `    mv \$CALLFILE \$SPOOL_DIR/\n`;
    code += `done\n\n`;

    code += `echo "Все файлы вызовов успешно отправлены в спулер Asterisk!"\n`;
    code += `rm -rf \$TMP_DIR\n`;

    return code;
}
