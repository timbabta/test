<?php
// =====================================================================
// КОНФИГУРАЦИЯ SMARTDIALER FLOW
// =====================================================================


error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Конфигурация подключения к MySQL/MariaDB
$db_host = 'localhost';
$db_user = 'dialer_admin';        // Укажи здесь пользователя БД
$db_pass = '';            // Укажи здесь пароль БД (например, StrongPass13!)
$db_name = 'asterisk_dialer';

// Попытка подключения к MySQL
$db = @new mysqli($db_host, $db_user, $db_pass);
if ($db->connect_error) {
    $db_connected = false;
    $db_error = "Ошибка подключения к MySQL: " . $db->connect_error;
} else {
    $db_connected = true;
}
// Пути для файлов Asterisk (на Linux-сервере)
$base_dir = __DIR__;

// Временные файлы (промежуточные, .tmp)
$temp_dir = $base_dir . "/temp";

// Готовые выходные файлы
$output_dir = $base_dir . "/output";

// Производные пути
$sounds_base_dir      = "/var/lib/asterisk/sounds/custom";          // WAV файлы кампаний
$dialplan_output_file = "/etc/asterisk/extensions_custom.conf";  // диалплан Asterisk
$call_files_dir       = $output_dir . "/call_files";      // архив созданных .call файлов

// =====================================================================
// ASTERISK НАСТРОЙКИ (заполнить при деплое)
// =====================================================================

// Spool Asterisk — куда PHP кладёт .call файлы (реальный путь на сервере)
// Права: chown asterisk:www-data /var/spool/asterisk/outgoing && chmod 775 ...
$asterisk_spool_dir  = "/var/spool/asterisk/outgoing";

// Звуки Asterisk
$asterisk_sounds_dir = "/var/lib/asterisk/sounds/custom";

// AGI-скрипты Asterisk
// Права: chown asterisk:www-data /var/lib/asterisk/agi-bin/agi_callback.php && chmod 755 ...
$asterisk_agi_dir    = "/var/lib/asterisk/agi-bin";

$recordings_base_dir = "/var/spool/asterisk/monitor/dialer";
$recordings_base_url = "";

// URL этого сервера — используется в call-файлах и AGI
// Пример: "http://192.168.1.10/smartdialer"
$api_base_url = "http://localhost/zvonok";

// =====================================================================
// РЕЖИМ ОБЗВОНА
// "simulation" — без Asterisk, результаты случайные (для теста)
// "asterisk"   — реальные звонки через call-файлы
// =====================================================================
$dialer_mode = "asterisk";

// =====================================================================

ini_set('display_errors', 0);
error_reporting(E_ALL);

// Создаём рабочие директории если не существуют
foreach ([
    $temp_dir,
    $output_dir,
    $sounds_base_dir,
    $recordings_base_dir,
    dirname($dialplan_output_file),
    $call_files_dir,
] as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}
