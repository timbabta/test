<?php
// =====================================================================
// REST API Crocus FLOW v2
// =====================================================================

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/dialplan_generator.php';
require_once __DIR__ . '/dialer_engine.php';

function jsonResponse(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function getInput(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function ensureSchema(PDO $pdo): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    $dbName = $pdo->query('SELECT DATABASE()')->fetchColumn();

    $columnExists = function (string $table, string $column) use ($pdo, $dbName): bool {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?"
        );
        $stmt->execute([$dbName, $table, $column]);
        return intval($stmt->fetchColumn()) > 0;
    };

    $indexExists = function (string $table, string $index) use ($pdo, $dbName): bool {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
             WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?"
        );
        $stmt->execute([$dbName, $table, $index]);
        return intval($stmt->fetchColumn()) > 0;
    };

    $addColumn = function (string $table, string $column, string $definition) use ($pdo, $columnExists): void {
        if ($columnExists($table, $column)) return;
        $sql = "ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}";
        try {
            $pdo->exec($sql);
        } catch (Exception $e) {
            error_log(date('Y-m-d H:i:s') . " schema migration failed: {$sql} | " . $e->getMessage() . "\n", 3, '/tmp/obzvon_schema_error.log');
        }
    };

    $addIndex = function (string $table, string $index, string $columns) use ($pdo, $indexExists): void {
        if ($indexExists($table, $index)) return;
        $sql = "ALTER TABLE `{$table}` ADD INDEX `{$index}` ({$columns})";
        try {
            $pdo->exec($sql);
        } catch (Exception $e) {
            error_log(date('Y-m-d H:i:s') . " schema index failed: {$sql} | " . $e->getMessage() . "\n", 3, '/tmp/obzvon_schema_error.log');
        }
    };

    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS call_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        campaign_id INT NOT NULL,
        contact_id INT NOT NULL,
        contact_name VARCHAR(200) NULL,
        contact_phone VARCHAR(30) NULL,
        started_at DATETIME NOT NULL,
        ended_at DATETIME NULL,
        duration_sec INT NOT NULL DEFAULT 0,
        dial_status VARCHAR(20) NOT NULL DEFAULT 'Pending',
        ivr_result VARCHAR(20) NULL,
        recording_file VARCHAR(500) NULL,
        recording_url VARCHAR(500) NULL,
        hangup_cause VARCHAR(50) NULL,
        asterisk_uniqueid VARCHAR(80) NULL,
        tries INT NOT NULL DEFAULT 1,
        current_node VARCHAR(100) NULL,
        notes TEXT NULL,
        INDEX idx_history_campaign (campaign_id),
        INDEX idx_history_ivr (ivr_result),
        INDEX idx_history_started (started_at),
        INDEX idx_history_status (dial_status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) {
        error_log(date('Y-m-d H:i:s') . " create call_history failed: " . $e->getMessage() . "\n", 3, '/tmp/obzvon_schema_error.log');
    }

    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS call_events (
        id INT AUTO_INCREMENT PRIMARY KEY,
        call_history_id INT NOT NULL,
        campaign_id INT NOT NULL,
        contact_id INT NOT NULL,
        event_at DATETIME NOT NULL,
        event_type VARCHAR(40) NOT NULL,
        node_id VARCHAR(100) NULL,
        node_name VARCHAR(200) NULL,
        dtmf_digit VARCHAR(10) NULL,
        destination VARCHAR(100) NULL,
        operator_number VARCHAR(100) NULL,
        queue_number VARCHAR(100) NULL,
        details TEXT NULL,
        asterisk_uniqueid VARCHAR(80) NULL,
        INDEX idx_call_events_history (call_history_id),
        INDEX idx_call_events_campaign (campaign_id),
        INDEX idx_call_events_type (event_type),
        INDEX idx_call_events_at (event_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) {
        error_log(date('Y-m-d H:i:s') . " create call_events failed: " . $e->getMessage() . "\n", 3, '/tmp/obzvon_schema_error.log');
    }

    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS active_calls (
        id INT AUTO_INCREMENT PRIMARY KEY,
        campaign_id INT NOT NULL,
        contact_id INT NOT NULL,
        call_history_id INT NULL,
        phone VARCHAR(30) NOT NULL,
        contact_name VARCHAR(200) NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'dialing',
        current_node VARCHAR(100) NULL DEFAULT 'start',
        started_at DATETIME NOT NULL,
        duration_sec INT NOT NULL DEFAULT 0,
        INDEX idx_active_campaign (campaign_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) {
        error_log(date('Y-m-d H:i:s') . " create active_calls failed: " . $e->getMessage() . "\n", 3, '/tmp/obzvon_schema_error.log');
    }

    $addColumn('campaigns', 'dialer_started_at', 'DATETIME NULL');
    $addColumn('campaigns', 'dialer_stopped_at', 'DATETIME NULL');
    $addColumn('audio_files', 'file_path', 'VARCHAR(500) NULL');
    $addColumn('contacts', 'last_call_at', 'DATETIME NULL');
    $addColumn('call_history', 'contact_name', 'VARCHAR(200) NULL');
    $addColumn('call_history', 'contact_phone', 'VARCHAR(30) NULL');
    $addColumn('call_history', 'recording_file', 'VARCHAR(500) NULL');
    $addColumn('call_history', 'recording_url', 'VARCHAR(500) NULL');
    $addColumn('call_history', 'hangup_cause', 'VARCHAR(50) NULL');
    $addColumn('call_history', 'asterisk_uniqueid', 'VARCHAR(80) NULL');
    $addIndex('call_history', 'idx_history_started', '`started_at`');
    $addIndex('call_history', 'idx_history_status', '`dial_status`');
}

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    jsonResponse(['success' => false, 'connected' => false, 'error' => 'Ошибка подключения к БД: ' . $e->getMessage()], 503);
}

$action = $_GET['action'] ?? '';
$input = getInput();
$dialer = new DialerEngine($pdo, $dialer_mode ?? 'simulation');

if ($action !== 'health') {
    ensureSchema($pdo);
}

function getCampaignByName(PDO $pdo, string $name): ?array
{
    $stmt = $pdo->prepare("SELECT * FROM campaigns WHERE name = ?");
    $stmt->execute([$name]);
    return $stmt->fetch() ?: null;
}

function getCampaignById(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare("SELECT * FROM campaigns WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

function loadCampaignData(PDO $pdo, array $campaign): array
{
    $id = intval($campaign['id']);

    $stmt = $pdo->prepare("SELECT id, name, last_name as lastName, phone, birth_date as birthDate, status, tries FROM contacts WHERE campaign_id = ?");
    $stmt->execute([$id]);
    $contacts = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT id, name, duration, size_bytes as sizeBytes, file_path as filePath FROM audio_files WHERE campaign_id = ?");
$stmt->execute([$id]);
$audioFiles = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT timestamp as time, type, text FROM logs WHERE campaign_id = ? ORDER BY id ASC LIMIT 100");
    $stmt->execute([$id]);
    $logs = $stmt->fetchAll();

    $nodes = json_decode($campaign['ivr_flow'] ?? '[]', true);
    if (!is_array($nodes) || empty($nodes)) {
        $nodes = [['id' => 'start', 'type' => 'start', 'name' => 'Начало звонка', 'target' => '']];
    }

    return [
        'success' => true,
        'campaignId' => $id,
        'campaign' => [
            'id' => $id,
            'name' => $campaign['name'],
            'trunk' => $campaign['trunk'],
            'maxCalls' => intval($campaign['max_calls']),
            'waitTime' => intval($campaign['wait_time']),
            'maxRetries' => intval($campaign['max_retries']),
            'retryTime' => intval($campaign['retry_time']),
            'scheduleEnabled' => $campaign['schedule_enabled'] == 1,
            'scheduleTime' => $campaign['schedule_time'] ? str_replace(' ', 'T', $campaign['schedule_time']) : '',
            'status' => $campaign['status'],
        ],
        'nodes' => $nodes,
        'contacts' => $contacts,
        'audioFiles' => $audioFiles,
        'logs' => $logs,
    ];
}

switch ($action) {

    case 'health':
        $pdo->query('SELECT 1');
        jsonResponse(['success' => true, 'connected' => true, 'message' => 'БД подключена']);
        break;

    case 'list_campaigns':
        $stmt = $pdo->query("SELECT id, name, status, max_calls, created_at, updated_at,
            (SELECT COUNT(*) FROM contacts WHERE campaign_id = campaigns.id) as contacts_count
            FROM campaigns ORDER BY updated_at DESC");
        jsonResponse(['success' => true, 'campaigns' => $stmt->fetchAll()]);
        break;

    case 'create_campaign':
        $name = preg_replace('/[^a-zA-Z0-9_]/', '_', trim($input['name'] ?? ''));
        if (!$name) jsonResponse(['success' => false, 'error' => 'Укажите имя кампании']);
        $existing = getCampaignByName($pdo, $name);
        if ($existing) jsonResponse(['success' => false, 'error' => 'Кампания уже существует']);
        $defaultFlow = json_encode([['id' => 'start', 'type' => 'start', 'name' => 'Начало звонка', 'target' => '']]);
        $stmt = $pdo->prepare("INSERT INTO campaigns (name, trunk, ivr_flow) VALUES (?, 'SIP/sip_trunk_name', ?)");
        $stmt->execute([$name, $defaultFlow]);
        jsonResponse(['success' => true, 'id' => intval($pdo->lastInsertId()), 'name' => $name]);
        break;

    case 'delete_campaign':
        $id = intval($input['id'] ?? $_GET['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'ID не указан']);
        $stmt = $pdo->prepare("DELETE FROM campaigns WHERE id = ?");
        $stmt->execute([$id]);
        jsonResponse(['success' => true]);
        break;

    case 'get_campaign':
        $campName = trim($_GET['name'] ?? 'AutoDialer_Promo');
        $campaign = getCampaignByName($pdo, $campName);
        if (!$campaign) {
            $defaultFlow = json_encode([['id' => 'start', 'type' => 'start', 'name' => 'Начало звонка', 'target' => '']]);
            $stmt = $pdo->prepare("INSERT INTO campaigns (name, trunk, ivr_flow) VALUES (?, 'SIP/sip_trunk_name', ?)");
            $stmt->execute([$campName, $defaultFlow]);
            $campaign = getCampaignByName($pdo, $campName);
        }
        jsonResponse(loadCampaignData($pdo, $campaign));
        break;

    case 'save_campaign':
        if (!$input) jsonResponse(['success' => false, 'error' => 'Данные не переданы']);
        $campName = $input['campaign']['name'] ?? '';
        $campaign = getCampaignByName($pdo, $campName);
        $ivrFlow = json_encode($input['nodes'] ?? []);
        $schedTime = !empty($input['campaign']['scheduleTime']) ? str_replace('T', ' ', $input['campaign']['scheduleTime']) : null;
        $schedEnabled = !empty($input['campaign']['scheduleEnabled']) ? 1 : 0;

        if ($campaign) {
            $stmt = $pdo->prepare("UPDATE campaigns SET trunk=?, max_calls=?, wait_time=?, max_retries=?, retry_time=?, schedule_enabled=?, schedule_time=?, ivr_flow=? WHERE id=?");
            $stmt->execute([
                $input['campaign']['trunk'], $input['campaign']['maxCalls'], $input['campaign']['waitTime'],
                $input['campaign']['maxRetries'], $input['campaign']['retryTime'], $schedEnabled, $schedTime, $ivrFlow, $campaign['id']
            ]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO campaigns (name, trunk, max_calls, wait_time, max_retries, retry_time, schedule_enabled, schedule_time, ivr_flow) VALUES (?,?,?,?,?,?,?,?,?)");
            $stmt->execute([
                $campName, $input['campaign']['trunk'], $input['campaign']['maxCalls'], $input['campaign']['waitTime'],
                $input['campaign']['maxRetries'], $input['campaign']['retryTime'], $schedEnabled, $schedTime, $ivrFlow
            ]);
        }
        jsonResponse(['success' => true]);
        break;

    case 'save_ivr':
        if (!$input) jsonResponse(['success' => false, 'error' => 'Данные не переданы']);
        $campName = $input['campaignName'] ?? '';
        $campaign = getCampaignByName($pdo, $campName);
        if (!$campaign) jsonResponse(['success' => false, 'error' => 'Кампания не найдена']);

        $nodes = $input['nodes'] ?? [];
        $stmt = $pdo->prepare("UPDATE campaigns SET ivr_flow = ? WHERE id = ?");
        $stmt->execute([json_encode($nodes), $campaign['id']]);

$stmt = $pdo->prepare("SELECT id, name, file_path as filePath, duration, size_bytes as sizeBytes FROM audio_files WHERE campaign_id = ?");
        $stmt->execute([$campaign['id']]);
        $audioFiles = $stmt->fetchAll();

        $campData = [
            'name' => $campaign['name'],
            'trunk' => $campaign['trunk'],
            'waitTime' => $campaign['wait_time'],
        ];
        $generator = new DialplanGenerator($campData, $nodes, $audioFiles);
        $dialplan = $generator->generate();


global $dialplan_output_file;

// 1. Пишем резервную копию в output/
$outputPath = $dialplan_output_file;
$dir = dirname($outputPath);
if (!is_dir($dir)) mkdir($dir, 0755, true);
file_put_contents($outputPath, $dialplan);

// 2. Пишем напрямую в Asterisk
$asteriskConf = '/etc/asterisk/extensions_custom.conf';
$writeOk  = false;
$reloadOk = false;
$reloadMsg = '';

if (is_writable($asteriskConf) || is_writable(dirname($asteriskConf))) {
    $writeOk = file_put_contents($asteriskConf, $dialplan) !== false;
    if ($writeOk) {
        // 3. Делаем dialplan reload
        $reloadOutput = shell_exec('asterisk -rx "dialplan reload" 2>&1');
        $reloadOk  = true;
        $reloadMsg = trim($reloadOutput ?? '');
    }
} else {
    $reloadMsg = 'Нет прав на запись в ';
}

jsonResponse([
    'success'    => true,
    'dialplan'   => $dialplan,
    'written_to' => $writeOk ? $asteriskConf : $outputPath,
    'reload'     => $reloadOk,
    'reloadMsg'  => $reloadMsg,
]);
        break;

    case 'get_dialplan':
        $campName = trim($_GET['name'] ?? '');
        $campaign = getCampaignByName($pdo, $campName);
        if (!$campaign) jsonResponse(['success' => false, 'error' => 'Кампания не найдена']);
        $nodes = json_decode($campaign['ivr_flow'] ?? '[]', true) ?: [];
$stmt = $pdo->prepare("SELECT id, name, file_path as filePath FROM audio_files WHERE campaign_id = ?");        
$stmt->execute([$campaign['id']]);
        $audioFiles = $stmt->fetchAll();
        $generator = new DialplanGenerator(['name' => $campaign['name'], 'trunk' => $campaign['trunk']], $nodes, $audioFiles);
        jsonResponse(['success' => true, 'dialplan' => $generator->generate()]);
        break;

    case 'upload_contacts':
        if (!$input) jsonResponse(['success' => false, 'error' => 'Данные не переданы']);
        $campName = $input['campaignName'] ?? '';
        $campaign = getCampaignByName($pdo, $campName);
        if (!$campaign) jsonResponse(['success' => false, 'error' => 'Кампания не найдена']);
        $campaignId = $campaign['id'];

        $pdo->beginTransaction();
        try {
            $pdo->prepare("DELETE FROM contacts WHERE campaign_id = ?")->execute([$campaignId]);
            $stmt = $pdo->prepare("INSERT INTO contacts (campaign_id, name, last_name, phone, birth_date, status, tries) VALUES (?,?,?,?,?,?,?)");
            foreach ($input['contacts'] as $c) {
                $stmt->execute([
                    $campaignId, $c['name'], $c['lastName'] ?? '', $c['phone'],
                    $c['birthDate'] ?? '', $c['status'] ?? 'Pending', intval($c['tries'] ?? 0)
                ]);
            }
            $pdo->commit();
            jsonResponse(['success' => true, 'count' => count($input['contacts'])]);
        } catch (Exception $e) {
            $pdo->rollBack();
            jsonResponse(['success' => false, 'error' => $e->getMessage()]);
        }
        break;

    case 'upload_audio':
        if (!$input) jsonResponse(['success' => false, 'error' => 'Данные не переданы']);

        $campName = trim($input['campaignName'] ?? '');
        if (!$campName) jsonResponse(['success' => false, 'error' => 'campaignName не передан']);

        // Ищем кампанию, если нет — создаём автоматически
        $campaign = getCampaignByName($pdo, $campName);
        if (!$campaign) {
            $defaultFlow = json_encode([['id' => 'start', 'type' => 'start', 'name' => 'Начало звонка', 'target' => '']]);
            $stmt = $pdo->prepare("INSERT INTO campaigns (name, trunk, ivr_flow) VALUES (?, 'SIP/sip_trunk_name', ?)");
            $stmt->execute([$campName, $defaultFlow]);
            $campaign = getCampaignByName($pdo, $campName);
            if (!$campaign) jsonResponse(['success' => false, 'error' => 'Не удалось создать кампанию']);
        }

        $audio = $input['audio'] ?? null;
        if (!$audio) jsonResponse(['success' => false, 'error' => 'Данные аудио не переданы']);

        $audioId   = trim($audio['id'] ?? ('audio_' . time()));
        // originalName — то что видит пользователь (исходное имя файла)
        $originalName = trim($audio['originalName'] ?? $audio['name'] ?? 'audio');
        // Уникальное безопасное имя для хранения на диске
        $safeName  = preg_replace('/[^a-zA-Z0-9_]/', '_', pathinfo($audio['name'] ?? 'audio', PATHINFO_FILENAME));
        $uniqueFileName = $safeName . '_' . $audioId . '.wav';

        global $sounds_base_dir;
        $campSafeName = preg_replace('/[^a-zA-Z0-9_]/', '_', $campaign['name']);
        $campDir = rtrim($sounds_base_dir, '/') . '/' . $campSafeName;

        if (!is_dir($campDir) && !mkdir($campDir, 0755, true)) {
            jsonResponse(['success' => false, 'error' => 'Не удалось создать директорию: ' . $campDir]);
        }

        $filePath = $campDir . '/' . $uniqueFileName;

        // Декодируем и записываем файл на диск
        $rawData = $audio['data'] ?? '';
        if (strpos($rawData, 'base64,') !== false) {
            $rawData = explode('base64,', $rawData)[1];
        }
        $rawData = trim($rawData);

        if (!empty($rawData)) {
            $decoded = base64_decode($rawData, true);
            if ($decoded === false) {
                jsonResponse(['success' => false, 'error' => 'Некорректные base64 данные аудио']);
            }
            $written = file_put_contents($filePath, $decoded);
            if ($written === false) {
                jsonResponse(['success' => false, 'error' => 'Не удалось записать файл: ' . $filePath]);
            }
        } else {
            jsonResponse(['success' => false, 'error' => 'Аудиоданные пусты']);
        }

        // Сохраняем в БД: name = оригинальное имя (для отображения), file_path = путь к уникальному файлу
        try {
            $stmt = $pdo->prepare("
                INSERT INTO audio_files (id, campaign_id, name, duration, size_bytes, file_path, data_base64)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    campaign_id  = VALUES(campaign_id),
                    name         = VALUES(name),
                    duration     = VALUES(duration),
                    size_bytes   = VALUES(size_bytes),
                    file_path    = VALUES(file_path),
                    data_base64  = VALUES(data_base64)
            ");
            $stmt->execute([
                $audioId,
                $campaign['id'],
                $originalName,                        // пользователь видит исходное имя
                floatval($audio['duration']  ?? 0),
                intval($audio['sizeBytes']   ?? 0),
                $filePath,                            // уникальный путь на диске
                $audio['data'] ?? null
            ]);
        } catch (PDOException $e) {
            jsonResponse(['success' => false, 'error' => 'Ошибка БД: ' . $e->getMessage()]);
        }

        jsonResponse(['success' => true, 'filePath' => $filePath, 'displayName' => $originalName, 'fileName' => $uniqueFileName]);
        break;

    case 'delete_audio':
        $audioId = trim($_GET['id'] ?? '');
        $stmt = $pdo->prepare("SELECT file_path FROM audio_files WHERE id = ?");
        $stmt->execute([$audioId]);
        $row = $stmt->fetch();
        if ($row && !empty($row['file_path']) && file_exists($row['file_path'])) {
            @unlink($row['file_path']);
        }
        $pdo->prepare("DELETE FROM audio_files WHERE id = ?")->execute([$audioId]);
        jsonResponse(['success' => true]);
        break;

    case 'dialer_start':
        $id = intval($input['campaignId'] ?? $_GET['id'] ?? 0);
        if (!$id) {
            $camp = getCampaignByName($pdo, $input['campaignName'] ?? '');
            $id = $camp ? intval($camp['id']) : 0;
        }
        jsonResponse($dialer->startCampaign($id));
        break;

    case 'dialer_pause':
        $id = intval($input['campaignId'] ?? $_GET['id'] ?? 0);
        jsonResponse($dialer->pauseCampaign($id));
        break;

    case 'dialer_stop':
        $id = intval($input['campaignId'] ?? $_GET['id'] ?? 0);
        jsonResponse($dialer->stopCampaign($id));
        break;

    case 'get_live_status':
        $id = intval($_GET['id'] ?? 0);
        if (!$id) {
            $camp = getCampaignByName($pdo, $_GET['name'] ?? '');
            $id = $camp ? intval($camp['id']) : 0;
        }
        jsonResponse($dialer->getLiveStatus($id));
        break;

    case 'get_analytics':
        $id = intval($_GET['id'] ?? 0);
        if (!$id) {
            $camp = getCampaignByName($pdo, $_GET['name'] ?? '');
            $id = $camp ? intval($camp['id']) : 0;
        }
        jsonResponse($dialer->getAnalytics($id, $_GET));
        break;

    case 'reset_campaign':
        $campName = trim($_GET['name'] ?? '');
        $campaign = getCampaignByName($pdo, $campName);
        if ($campaign) {
            $id = $campaign['id'];
            $pdo->prepare("UPDATE contacts SET status='Pending', tries=0 WHERE campaign_id=?")->execute([$id]);
            $pdo->prepare("DELETE FROM logs WHERE campaign_id=?")->execute([$id]);
            $pdo->prepare("DELETE FROM call_history WHERE campaign_id=?")->execute([$id]);
            $pdo->prepare("DELETE FROM active_calls WHERE campaign_id=?")->execute([$id]);
            $pdo->prepare("UPDATE campaigns SET status='idle' WHERE id=?")->execute([$id]);
        }
        jsonResponse(['success' => true]);
        break;

    case 'add_log':
        if (!$input) jsonResponse(['success' => false, 'error' => 'Данные не переданы']);
        $campaign = getCampaignByName($pdo, $input['campaignName'] ?? '');
        if (!$campaign) jsonResponse(['success' => false, 'error' => 'Кампания не найдена']);
        $stmt = $pdo->prepare("INSERT INTO logs (campaign_id, timestamp, type, text) VALUES (?,?,?,?)");
        $stmt->execute([$campaign['id'], $input['time'] ?? date('H:i:s'), $input['type'], $input['text']]);
        jsonResponse(['success' => true]);
        break;

    default:
        jsonResponse(['success' => false, 'error' => 'Неизвестное действие: ' . $action]);
}
