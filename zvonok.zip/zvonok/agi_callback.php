<?php
// =====================================================================
// AGI CALLBACK — вызывается Asterisk'ом после завершения каждого звонка
// Записывает результат (ответил/занят/нажал кнопку) в MySQL
//
// Установка:
//   cp agi_callback.php /var/lib/asterisk/agi-bin/agi_callback.php
//   chown asterisk:asterisk /var/lib/asterisk/agi-bin/agi_callback.php
//   chmod 755 /var/lib/asterisk/agi-bin/agi_callback.php
//
// Вызов из диалплана (extensions_custom.conf):
//   exten => h,1,AGI(agi_callback.php,${HISTORY_ID},${CAMPAIGN_ID},${CONTACT_ID},${DIALSTATUS},${IVR_RESULT},${CDR(billsec)})
// =====================================================================

// Определяем путь к config.php независимо от того, откуда запущен скрипт
$rootCandidates = [
    getenv('SMARTDIALER_ROOT') ?: '',
    '/var/www/html/obzvon',
    '/var/www/html/zvonok',
    dirname(__DIR__),
];
$configPath = '';
foreach ($rootCandidates as $root) {
    if ($root && file_exists(rtrim($root, '/') . '/config.php')) {
        $configPath = rtrim($root, '/') . '/config.php';
        break;
    }
}
if (!file_exists($configPath)) {
    file_put_contents('/tmp/agi_callback_error.log',
        date('Y-m-d H:i:s') . " ОШИБКА: config.php не найден по пути: {$configPath}\n"
        . "Отредактируй SMARTDIALER_ROOT в agi_callback.php\n",
        FILE_APPEND);
    exit(1);
}
require_once $configPath;
$agiVars = [];
while (($line = fgets(STDIN)) !== false) {
    $line = trim($line);
    if ($line === '') break;
    if (strpos($line, ':') !== false) {
        [$k, $v] = explode(':', $line, 2);
        $agiVars[trim($k)] = trim($v);
    }
}
// ----------------------------------------------------------------
// Читаем AGI-переменные окружения (Asterisk передаёт их как agi_arg_N)
// ----------------------------------------------------------------
function agiEnv(string $key, string $default = ''): string
{
    global $agiVars;
    return $agiVars[$key] ?? $_ENV[$key] ?? getenv($key) ?: $default;
}

$historyId  = intval(agiEnv('agi_arg_1'));
$campaignId = intval(agiEnv('agi_arg_2'));
$contactId  = intval(agiEnv('agi_arg_3'));
$dialStatus = strtoupper(trim(agiEnv('agi_arg_4', 'UNKNOWN')));
$ivrResult  = trim(agiEnv('agi_arg_5', ''));
$duration   = intval(agiEnv('agi_arg_6', '0'));
$recordingFile = trim(agiEnv('agi_arg_7', ''));
$uniqueId = trim(agiEnv('agi_arg_8', ''));

if (ctype_digit($dialStatus)) {
    $hangupcause = intval($dialStatus);
    switch ($hangupcause) {
        case 16: $dialStatus = 'ANSWER'; break;
        case 17: $dialStatus = 'BUSY'; break;
        case 18:
        case 19: $dialStatus = 'NOANSWER'; break;
        case 21: $dialStatus = 'CANCEL'; break;
        case 34:
        case 38:
        case 41:
        case 42: $dialStatus = 'CONGESTION'; break;
        default: $dialStatus = 'FAILED'; break;
    }
}

// Логируем входящие параметры для отладки
$logLine = date('Y-m-d H:i:s')
    . " | history={$historyId} campaign={$campaignId} contact={$contactId}"
    . " dial={$dialStatus} ivr={$ivrResult} dur={$duration} rec={$recordingFile}\n";
file_put_contents('/tmp/agi_callback.log', $logLine, FILE_APPEND);

// Базовая валидация
if (!$historyId || !$campaignId || !$contactId) {
    file_put_contents('/tmp/agi_callback.log', date('Y-m-d H:i:s') . " ОШИБКА: неполные параметры\n", FILE_APPEND);
    exit(1);
}

// ----------------------------------------------------------------
// Подключение к БД
// ----------------------------------------------------------------
try {
    $pdo = new PDO(
        "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    file_put_contents('/tmp/agi_callback.log',
        date('Y-m-d H:i:s') . " Ошибка БД: " . $e->getMessage() . "\n", FILE_APPEND);
    exit(1);
}

// ----------------------------------------------------------------
// Маппинг статусов Asterisk → наши статусы
// ANSWER      → Answered  (ответил)
// BUSY        → Busy      (занято, попробовать позже)
// NOANSWER    → Busy      (не ответил, повтор)
// CONGESTION  → Failed    (перегрузка сети)
// CHANUNAVAIL → Failed    (канал недоступен)
// CANCEL      → Busy      (отменён)
// ----------------------------------------------------------------
$dbName = $pdo->query('SELECT DATABASE()')->fetchColumn();
$addColumnIfMissing = function (string $column, string $definition) use ($pdo, $dbName): void {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'call_history' AND COLUMN_NAME = ?"
    );
    $stmt->execute([$dbName, $column]);
    if (intval($stmt->fetchColumn()) > 0) return;
    try {
        $pdo->exec("ALTER TABLE call_history ADD COLUMN `{$column}` {$definition}");
    } catch (Exception $e) {
        file_put_contents('/tmp/agi_callback.log', date('Y-m-d H:i:s') . " ALTER {$column}: " . $e->getMessage() . "\n", FILE_APPEND);
    }
};
$addColumnIfMissing('recording_file', 'VARCHAR(500) NULL');
$addColumnIfMissing('recording_url', 'VARCHAR(500) NULL');
$addColumnIfMissing('hangup_cause', 'VARCHAR(50) NULL');
$addColumnIfMissing('asterisk_uniqueid', 'VARCHAR(80) NULL');
$addColumnIfMissing('contact_name', 'VARCHAR(200) NULL');
$addColumnIfMissing('contact_phone', 'VARCHAR(30) NULL');

$pdo->exec("CREATE TABLE IF NOT EXISTS call_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    call_history_id INT NOT NULL,
    campaign_id INT NOT NULL,
    contact_id INT NOT NULL,
    event_at DATETIME NOT NULL,
    event_type VARCHAR(40) NOT NULL,
    node_id VARCHAR(100) NULL,
    node_name VARCHAR(200) NULL,
    dtmf_digit VARCHAR(10) NULL,
    destination VARCHAR(100) NULL,
    operator_number VARCHAR(100) NULL,
    queue_number VARCHAR(100) NULL,
    details TEXT NULL,
    asterisk_uniqueid VARCHAR(80) NULL,
    INDEX idx_call_events_history (call_history_id),
    INDEX idx_call_events_campaign (campaign_id),
    INDEX idx_call_events_type (event_type),
    INDEX idx_call_events_at (event_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$statusMap = [
    'ANSWER'      => 'Answered',
    'BUSY'        => 'Busy',
    'NOANSWER'    => 'Busy',
    'CONGESTION'  => 'Failed',
    'CHANUNAVAIL' => 'Failed',
    'CANCEL'      => 'Busy',
];
$contactStatus = $statusMap[$dialStatus] ?? 'Failed';
if ($duration > 0 || in_array($ivrResult, ['1','2','3','4','5','timeout','invalid','none','transfer'], true)) {
    $contactStatus = 'Answered';
}

// Нормализуем ivr_result: пустая строка → null
$ivrResultDb = ($ivrResult !== '') ? $ivrResult : null;
if ($contactStatus !== 'Answered') {
    $ivrResultDb = null; // нет смысла писать IVR если не ответил
}

// ----------------------------------------------------------------
// Обновляем call_history
// ----------------------------------------------------------------
$pdo->prepare(
    "UPDATE call_history
     SET ended_at    = NOW(),
         dial_status = ?,
         ivr_result  = ?,
         duration_sec = ?,
         recording_file = ?,
         recording_url = ?,
         hangup_cause = ?,
         asterisk_uniqueid = ?,
         notes       = ?
     WHERE id = ?"
)->execute([
    $contactStatus,
    $ivrResultDb,
    $duration,
    $recordingFile ?: null,
    (!empty($recordings_base_url) && $recordingFile) ? rtrim($recordings_base_url, '/') . '/' . basename($recordingFile) : null,
    $dialStatus,
    $uniqueId ?: null,
    "Asterisk: {$dialStatus}" . ($ivrResult ? ", IVR: {$ivrResult}" : ""),
    $historyId,
]);

// ----------------------------------------------------------------
// Обновляем контакт
// ----------------------------------------------------------------
$pdo->prepare(
    "UPDATE contacts
     SET status       = ?,
         last_call_at = NOW()
     WHERE id = ?"
)->execute([$contactStatus, $contactId]);

// ----------------------------------------------------------------
// Удаляем из active_calls
// ----------------------------------------------------------------
$pdo->prepare("DELETE FROM active_calls WHERE call_history_id = ?")->execute([$historyId]);

$pdo->prepare(
    "INSERT INTO call_events
     (call_history_id, campaign_id, contact_id, event_at, event_type, node_id, node_name, dtmf_digit, details, asterisk_uniqueid)
     VALUES (?, ?, ?, NOW(), 'final', 'final', 'Final status', ?, ?, ?)"
)->execute([
    $historyId,
    $campaignId,
    $contactId,
    $ivrResultDb,
    "status={$contactStatus}; hangup={$dialStatus}; duration={$duration}; recording={$recordingFile}",
    $uniqueId ?: null,
]);

// ----------------------------------------------------------------
// Лог в БД
// ----------------------------------------------------------------
$ivrLabel = [
    '1'=>'Нажал 1','2'=>'Нажал 2','3'=>'Нажал 3','4'=>'Нажал 4','5'=>'Нажал 5',
    'timeout'=>'Таймаут','invalid'=>'Ошибся','none'=>'Без ввода',
];
$logText = "Звонок #{$historyId}: {$contactStatus}";
if ($ivrResultDb) {
    $logText .= ", IVR: " . ($ivrLabel[$ivrResultDb] ?? $ivrResultDb);
}
$logText .= ", длит. {$duration}с";

$pdo->prepare(
    "INSERT INTO logs (campaign_id, timestamp, type, text) VALUES (?, ?, ?, ?)"
)->execute([$campaignId, date('H:i:s'), 'ivr', $logText]);

// ----------------------------------------------------------------
// Проверяем — все ли контакты обработаны
// ----------------------------------------------------------------
$stmt = $pdo->prepare(
    "SELECT COUNT(*) FROM contacts WHERE campaign_id = ? AND status IN ('Pending','Busy')"
);
$stmt->execute([$campaignId]);
$remaining = intval($stmt->fetchColumn());

$activeStmt = $pdo->prepare("SELECT COUNT(*) FROM active_calls WHERE campaign_id = ?");
$activeStmt->execute([$campaignId]);
$activeCnt = intval($activeStmt->fetchColumn());

if ($remaining === 0 && $activeCnt === 0) {
    $pdo->prepare(
        "UPDATE campaigns SET status = 'idle', dialer_stopped_at = NOW() WHERE id = ? AND status = 'running'"
    )->execute([$campaignId]);
    $pdo->prepare(
        "INSERT INTO logs (campaign_id, timestamp, type, text) VALUES (?, ?, ?, ?)"
    )->execute([$campaignId, date('H:i:s'), 'system', 'Все контакты обработаны. Asterisk-кампания завершена.']);
}

file_put_contents('/tmp/agi_callback.log',
    date('Y-m-d H:i:s') . " OK: history#{$historyId} → {$contactStatus}\n", FILE_APPEND);

exit(0);
