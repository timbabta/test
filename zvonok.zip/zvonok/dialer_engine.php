<?php
// =====================================================================
// ДВИЖОК АВТООБЗВОНА v2 — поддержка simulation + asterisk (call-файлы)
// =====================================================================

require_once __DIR__ . '/config.php';

class DialerEngine
{
    private PDO    $pdo;
    private string $mode;

    public function __construct(PDO $pdo, string $mode = 'simulation')
    {
        $this->pdo  = $pdo;
        $this->mode = $mode;
    }

    // ----------------------------------------------------------------
    // PUBLIC: старт / пауза / стоп
    // ----------------------------------------------------------------

    public function startCampaign(int $campaignId): array
    {
        $campaign = $this->getCampaign($campaignId);
        if (!$campaign) {
            return ['success' => false, 'error' => 'Кампания не найдена'];
        }

        $pending = $this->countContacts($campaignId, ['Pending', 'Busy']);
        if ($pending === 0) {
            return ['success' => false, 'error' => 'Нет контактов для обзвона'];
        }

        if ($this->mode === 'asterisk') {
            // Шаг 1 — проверяем spool
            global $asterisk_spool_dir;
            $spoolDir = rtrim($asterisk_spool_dir ?? '/var/spool/asterisk/outgoing', '/');
            if (!is_dir($spoolDir)) {
                return ['success' => false, 'error' => "Spool-директория не найдена: {$spoolDir}"];
            }
            if (!is_writable($spoolDir)) {
                return ['success' => false, 'error' => "Нет прав на запись в {$spoolDir}. chown asterisk:www-data {$spoolDir} && chmod 775 {$spoolDir}"];
            }

            // Шаг 2 — генерируем extensions_custom.conf из IVR-конструктора
            $dialplanResult = $this->generateAndWriteDialplan($campaign);
            if (!$dialplanResult['success']) {
                return $dialplanResult;
            }
            $this->addLog($campaignId, 'system', "Диалплан сгенерирован: {$dialplanResult['file']}");

            // Шаг 3 — перезагружаем диалплан в Asterisk
            $reloadResult = $this->reloadAsteriskDialplan();
            if (!$reloadResult['success']) {
                return $reloadResult;
            }
            $this->addLog($campaignId, 'system', 'Asterisk dialplan reload — OK');
        }

        // Шаг 4 — ставим статус running, tick() начнёт создавать call-файлы
        $this->pdo->prepare(
            "UPDATE campaigns SET status = 'running', dialer_started_at = NOW(), dialer_stopped_at = NULL WHERE id = ?"
        )->execute([$campaignId]);

        $mode = $this->mode === 'asterisk' ? 'asterisk' : 'simulation';
        $this->addLog($campaignId, 'system', "Автообзвон запущен ({$mode}), max_calls={$campaign['max_calls']}");

        return ['success' => true, 'status' => 'running', 'mode' => $mode];
    }

    public function pauseCampaign(int $campaignId): array
    {
        $this->pdo->prepare("UPDATE campaigns SET status = 'paused' WHERE id = ? AND status = 'running'")
            ->execute([$campaignId]);
        $this->addLog($campaignId, 'system', 'Обзвон приостановлен');
        return ['success' => true, 'status' => 'paused'];
    }

    public function stopCampaign(int $campaignId): array
    {
        $this->pdo->prepare(
            "UPDATE campaigns SET status = 'idle', dialer_stopped_at = NOW() WHERE id = ?"
        )->execute([$campaignId]);
        $this->pdo->prepare("DELETE FROM active_calls WHERE campaign_id = ?")->execute([$campaignId]);
        $this->addLog($campaignId, 'system', 'Обзвон остановлен');
        return ['success' => true, 'status' => 'idle'];
    }

    // ----------------------------------------------------------------
    // ASTERISK: генерация диалплана и перезагрузка
    // ----------------------------------------------------------------

    private function generateAndWriteDialplan(array $campaign): array
    {
        global $dialplan_output_file;

        require_once __DIR__ . '/dialplan_generator.php';

        $campaignId = intval($campaign['id']);

        // Берём IVR-узлы из БД
        $nodes = json_decode($campaign['ivr_flow'] ?? '[]', true) ?: [];

        // Берём аудиофайлы
        $stmt = $this->pdo->prepare(
"SELECT id, name, file_path as filePath, duration, size_bytes as sizeBytes FROM audio_files WHERE campaign_id = ?"
        );
        $stmt->execute([$campaignId]);
        $audioFiles = $stmt->fetchAll();

        $campData = [
            'name'     => $campaign['name'],
            'trunk'    => $campaign['trunk'],
            'waitTime' => $campaign['wait_time'],
        ];

        $generator = new DialplanGenerator($campData, $nodes, $audioFiles);
        $dialplan  = $generator->generate();

        $outputPath = $dialplan_output_file ?? __DIR__ . '/output/extensions_custom.conf';
        $dir        = dirname($outputPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        if (file_put_contents($outputPath, $dialplan) === false) {
            return ['success' => false, 'error' => "Не удалось записать диалплан: {$outputPath}"];
        }

        return ['success' => true, 'file' => $outputPath];
    }

    private function reloadAsteriskDialplan(): array
    {
        // Выполняем: asterisk -rx "dialplan reload"
        // www-data должен иметь право на sudo asterisk или быть в группе asterisk
        $output   = [];
        $exitCode = 0;
        exec('asterisk -rx "dialplan reload" 2>&1', $output, $exitCode);

        $outputStr = implode(' ', $output);

        if ($exitCode !== 0) {
            return [
                'success' => false,
                'error'   => "Ошибка dialplan reload (код {$exitCode}): {$outputStr}",
            ];
        }

        return ['success' => true, 'output' => $outputStr];
    }

    // ----------------------------------------------------------------
    // ASTERISK: создание одного call-файла (вызывается из tick())
    // tick() сам контролирует количество — не больше max_calls одновременно
    // ----------------------------------------------------------------

    private function originateCallAsterisk(array $campaign, array $contact): void
    {
        global $asterisk_spool_dir, $api_base_url;

        $spoolDir   = rtrim($asterisk_spool_dir ?? '/var/spool/asterisk/outgoing', '/');
        $campSafe   = preg_replace('/[^a-zA-Z0-9_]/', '_', $campaign['name']);
        $campaignId = intval($campaign['id']);
        $contactId  = intval($contact['id']);
        $tries      = intval($contact['tries']) + 1;

        // Записываем в call_history
        $this->pdo->prepare(
            "INSERT INTO call_history (campaign_id, contact_id, contact_name, contact_phone, started_at, dial_status, tries, current_node)
             VALUES (?, ?, ?, ?, NOW(), 'Pending', ?, 'start')"
        )->execute([$campaignId, $contactId, trim(($contact['name'] ?? '') . ' ' . ($contact['last_name'] ?? '')), $contact['phone'], $tries]);
        $historyId = intval($this->pdo->lastInsertId());

        // Записываем в active_calls — счётчик активных линий
        $name = trim(($contact['name'] ?? '') . ' ' . ($contact['last_name'] ?? ''));
        $this->pdo->prepare(
            "INSERT INTO active_calls (campaign_id, contact_id, call_history_id, phone, contact_name, status, current_node, started_at)
             VALUES (?, ?, ?, ?, ?, 'dialing', 'start', NOW())"
        )->execute([$campaignId, $contactId, $historyId, $contact['phone'], $name]);

        // Помечаем контакт как "в процессе"
        $this->pdo->prepare(
            "UPDATE contacts SET tries = ?, status = 'Pending', last_call_at = NOW() WHERE id = ?"
        )->execute([$tries, $contactId]);

        // Создаём call-файл атомарно:
        // 1. Пишем в temp/ (Asterisk туда не смотрит)
        // 2. rename() в spool/ — атомарная операция, Asterisk подхватит уже готовый файл
        global $temp_dir;
        $fileName = "sd_{$campaignId}_{$contactId}_{$historyId}.call";
        $content  = $this->buildCallFile($campaign, $contact, $historyId, $campSafe, $api_base_url ?? '');
        $tmpDir   = $this->getWritableTempDir($temp_dir ?? null);
        $tmp      = "{$tmpDir}/{$fileName}";
        $dest     = "{$spoolDir}/{$fileName}";

        $writeOk = @file_put_contents($tmp, $content);
        if ($writeOk !== false) {
            @chmod($tmp, 0644);
            if (!@rename($tmp, $dest)) {
                $error = error_get_last();
                @unlink($tmp);
                $this->pdo->prepare("DELETE FROM active_calls WHERE call_history_id = ?")->execute([$historyId]);
                $this->pdo->prepare("DELETE FROM call_history WHERE id = ?")->execute([$historyId]);
                $this->addLog($campaignId, 'error', "Ошибка переноса call-файла в spool для {$contact['phone']}: {$tmp} -> {$dest}. " . ($error['message'] ?? 'rename failed'));
                return;
            }
            $this->addLog($campaignId, 'dial', "Звоним: {$name} ({$contact['phone']}) [попытка {$tries}]");
        } else {
            // Откатываем если не удалось создать файл
            $this->pdo->prepare("DELETE FROM active_calls WHERE call_history_id = ?")->execute([$historyId]);
            $this->pdo->prepare("DELETE FROM call_history WHERE id = ?")->execute([$historyId]);
            $this->addLog($campaignId, 'error', "Ошибка записи call-файла для {$contact['phone']}");
        }
    }

    private function buildCallFile(array $campaign, array $contact, int $historyId, string $campSafe, string $apiUrl): string
    {
        $phone     = $contact['phone'];
        $waitTime  = intval($campaign['wait_time']   ?? 45);
        $maxRetry  = intval($campaign['max_retries'] ?? 3);
        $retryTime = intval($campaign['retry_time']  ?? 60);
        $trunk     = $campaign['trunk'];
        $apiUrl    = rtrim($apiUrl, '/');

        return implode("\n", [
            "Channel: {$trunk}/{$phone}",
            "CallerID: SmartDialer <{$phone}>",
            "MaxRetries: {$maxRetry}",
            "RetryTime: {$retryTime}",
            "WaitTime: {$waitTime}",
            "Context: dialer-ivr-{$campSafe}",
            "Extension: s",
            "Priority: 1",
            "Set: CONTACT_ID={$contact['id']}",
            "Set: CAMPAIGN_ID={$campaign['id']}",
            "Set: HISTORY_ID={$historyId}",
            "Set: API_URL={$apiUrl}",
            "Set: __IVR_RESULT=none",
            "Set: NUM={$phone}",
            "Archive: Yes",
        ]) . "\n";
    }

    // ----------------------------------------------------------------
    // SIMULATION: tick-цикл (вызывается из getLiveStatus)
    // ----------------------------------------------------------------

    public function tick(int $campaignId): array
    {
        $campaign = $this->getCampaign($campaignId);
        if (!$campaign || $campaign['status'] !== 'running') {
            return ['success' => true, 'processed' => 0];
        }

        $maxCalls   = intval($campaign['max_calls']);
        $maxRetries = intval($campaign['max_retries']);
        $nodes      = json_decode($campaign['ivr_flow'] ?? '[]', true) ?: [];

        if ($this->mode === 'asterisk') {
            // В asterisk-режиме: чистим зависшие звонки, затем добиваем пул до max_calls
            $this->cleanStalledAsteriskCalls($campaignId);

            $activeCount = $this->countActiveCalls($campaignId);
            $originated  = 0;

            while ($activeCount < $maxCalls) {
                $contact = $this->getNextContact($campaignId, $maxRetries);
                if (!$contact) break;
                $this->originateCallAsterisk($campaign, $contact);
                $activeCount++;
                $originated++;
            }

            // Проверяем завершение кампании
            $activeCount = $this->countActiveCalls($campaignId);
            $pending     = $this->countContacts($campaignId, ['Pending']);
            $retryable   = $this->countRetryableContacts($campaignId, $maxRetries);
            if ($activeCount === 0 && $pending === 0 && $retryable === 0) {
                $this->stopCampaign($campaignId);
                $this->addLog($campaignId, 'system', 'Все контакты обработаны. Asterisk-кампания завершена.');
            }

            return ['success' => true, 'processed' => $originated];
        }

        // Simulation-режим
        $this->pdo->prepare(
            "UPDATE active_calls SET duration_sec = duration_sec + 2 WHERE campaign_id = ?"
        )->execute([$campaignId]);

        $this->processActiveCalls($campaignId, $nodes);

        $activeCount = $this->countActiveCalls($campaignId);
        $originated  = 0;

        while ($activeCount < $maxCalls) {
            $contact = $this->getNextContact($campaignId, $maxRetries);
            if (!$contact) break;
            $this->originateCallSimulation($campaign, $contact);
            $activeCount++;
            $originated++;
        }

        $activeCount = $this->countActiveCalls($campaignId);
        $pending     = $this->countContacts($campaignId, ['Pending']);
        $retryable   = $this->countRetryableContacts($campaignId, $maxRetries);

        if ($activeCount === 0 && $pending === 0 && $retryable === 0) {
            $this->stopCampaign($campaignId);
            $this->addLog($campaignId, 'system', 'Все контакты обработаны. Кампания завершена.');
        }

        return ['success' => true, 'processed' => $originated];
    }

    /**
     * Удаляет active_calls, которые "зависли" дольше wait_time + 60 сек
     * (Asterisk уже завершил звонок, но agi_callback по какой-то причине не сработал)
     */
    private function cleanStalledAsteriskCalls(int $campaignId): void
    {
        $stmt = $this->pdo->prepare(
            "SELECT ac.*, cam.wait_time FROM active_calls ac
             JOIN campaigns cam ON cam.id = ac.campaign_id
             WHERE ac.campaign_id = ?
               AND ac.started_at < DATE_SUB(NOW(), INTERVAL (cam.wait_time + 60) SECOND)"
        );
        $stmt->execute([$campaignId]);
        $stalled = $stmt->fetchAll();

        foreach ($stalled as $call) {
            $events = [];
            try {
                $eventStmt = $this->pdo->prepare(
                    "SELECT event_type, dtmf_digit
                     FROM call_events
                     WHERE call_history_id = ?
                     ORDER BY event_at DESC, id DESC"
                );
                $eventStmt->execute([$call['call_history_id']]);
                $events = $eventStmt->fetchAll();
            } catch (Exception $e) {
                error_log(date('Y-m-d H:i:s') . " read call_events failed: " . $e->getMessage() . "\n", 3, '/tmp/obzvon_schema_error.log');
            }
            $hasAnsweredEvent = false;
            $lastIvr = null;
            foreach ($events as $event) {
                if (!$lastIvr && !empty($event['dtmf_digit'])) {
                    $lastIvr = $event['dtmf_digit'];
                }
                if (in_array($event['event_type'], ['answered', 'dtmf', 'transfer_start', 'transfer_end'], true)) {
                    $hasAnsweredEvent = true;
                }
            }
            $stalledStatus = $hasAnsweredEvent ? 'Answered' : 'Failed';
            $stalledNote = $hasAnsweredEvent
                ? 'Timeout: final AGI did not answer, restored by call_events'
                : 'Timeout: no AGI answer';
            $this->pdo->prepare(
                "UPDATE call_history SET ended_at = NOW(), dial_status = 'Failed', notes = 'Timeout: нет ответа от AGI'
                 WHERE id = ?"
            )->execute([$call['call_history_id']]);
            $this->pdo->prepare(
                "UPDATE contacts SET status = 'Failed', last_call_at = NOW() WHERE id = ?"
            )->execute([$call['contact_id']]);
            if ($hasAnsweredEvent) {
                $this->pdo->prepare(
                    "UPDATE call_history SET dial_status = 'Answered', ivr_result = COALESCE(?, ivr_result), notes = ? WHERE id = ?"
                )->execute([$lastIvr, $stalledNote, $call['call_history_id']]);
                $this->pdo->prepare(
                    "UPDATE contacts SET status = 'Answered', last_call_at = NOW() WHERE id = ?"
                )->execute([$call['contact_id']]);
            }
            $this->pdo->prepare("DELETE FROM active_calls WHERE id = ?")->execute([$call['id']]);
            $this->addLog($campaignId, 'hangup', "Звонок {$call['phone']} завис — удалён (stalled)");
        }

        // Проверяем завершение кампании после чистки
        $pending = $this->countContacts($campaignId, ['Pending']);
        $active  = $this->countActiveCalls($campaignId);
        if ($active === 0 && $pending === 0) {
            $this->pdo->prepare(
                "UPDATE campaigns SET status = 'idle', dialer_stopped_at = NOW() WHERE id = ? AND status = 'running'"
            )->execute([$campaignId]);
            $this->addLog($campaignId, 'system', 'Все контакты обработаны. Asterisk-кампания завершена.');
        }
    }

    // ----------------------------------------------------------------
    // SIMULATION internals
    // ----------------------------------------------------------------

    private function processActiveCalls(int $campaignId, array $nodes): void
    {
        $stmt = $this->pdo->prepare("SELECT * FROM active_calls WHERE campaign_id = ?");
        $stmt->execute([$campaignId]);

        foreach ($stmt->fetchAll() as $call) {
            if ($call['status'] === 'dialing' && $call['duration_sec'] >= 3) {
                $this->resolveDialing($call, $nodes);
            } elseif ($call['status'] === 'talking' && $call['duration_sec'] >= 6) {
                $this->completeTalkingCall($call, $nodes);
            }
        }
    }

    private function resolveDialing(array $call, array $nodes): void
    {
        $rand       = mt_rand(1, 100);
        $contactId  = intval($call['contact_id']);
        $campaignId = intval($call['campaign_id']);

        if ($rand <= 55) {
            $this->pdo->prepare(
                "UPDATE active_calls SET status = 'talking', current_node = 'start', duration_sec = 0 WHERE id = ?"
            )->execute([$call['id']]);
            $this->pdo->prepare("UPDATE contacts SET status = 'Answered' WHERE id = ?")->execute([$contactId]);
            $this->pdo->prepare("UPDATE call_history SET dial_status = 'Answered' WHERE id = ?")
                ->execute([$call['call_history_id']]);
            $this->addLog($campaignId, 'answer', "Номер {$call['phone']} ответил");
        } elseif ($rand <= 80) {
            $this->finishCall($call, 'Busy', null, 'Занято');
            $this->addLog($campaignId, 'dial', "Номер {$call['phone']} занят");
        } else {
            $this->finishCall($call, 'Failed', null, 'Недоступен');
            $this->addLog($campaignId, 'hangup', "Номер {$call['phone']} недоступен");
        }
    }

    private function completeTalkingCall(array $call, array $nodes): void
    {
        $ivrResult = $this->simulateIvrResult($nodes);
        $this->finishCall($call, 'Answered', $ivrResult, $this->ivrResultLabel($ivrResult));
        $this->addLog(intval($call['campaign_id']), 'ivr', "IVR {$call['phone']}: {$this->ivrResultLabel($ivrResult)}");
    }

    private function simulateIvrResult(array $nodes): string
    {
        $ivrNodes = array_filter($nodes, function ($n) {
            return ($n['type'] ?? '') === 'ivr';
        });
        if (empty($ivrNodes)) return 'none';

        $options = ['1', '2', '3', '4', '5', 'timeout', 'invalid', 'none'];
        $weights = [20,   15,  15,  10,  10,    15,        10,       5  ];
        $total   = array_sum($weights);
        $rand    = mt_rand(1, $total);
        $sum     = 0;

        foreach ($options as $i => $opt) {
            $sum += $weights[$i];
            if ($rand <= $sum) return $opt;
        }
        return 'none';
    }

    private function finishCall(array $call, string $dialStatus, ?string $ivrResult, string $note): void
    {
        $duration = max(intval($call['duration_sec']), 3);

        $this->pdo->prepare(
            "UPDATE call_history SET ended_at = NOW(), duration_sec = ?, dial_status = ?, ivr_result = ?, notes = ? WHERE id = ?"
        )->execute([$duration, $dialStatus, $ivrResult, $note, $call['call_history_id']]);

        $this->pdo->prepare("DELETE FROM active_calls WHERE id = ?")->execute([$call['id']]);

        $status = ($dialStatus === 'Answered') ? 'Answered' : $dialStatus;
        $this->pdo->prepare("UPDATE contacts SET status = ?, last_call_at = NOW() WHERE id = ?")
            ->execute([$status, $call['contact_id']]);
    }

    private function originateCallSimulation(array $campaign, array $contact): void
    {
        $campaignId = intval($campaign['id']);
        $contactId  = intval($contact['id']);
        $tries      = intval($contact['tries']) + 1;

        $this->pdo->prepare(
            "UPDATE contacts SET tries = ?, status = 'Pending', last_call_at = NOW() WHERE id = ?"
        )->execute([$tries, $contactId]);

        $this->pdo->prepare(
            "INSERT INTO call_history (campaign_id, contact_id, contact_name, contact_phone, started_at, dial_status, tries, current_node)
             VALUES (?, ?, ?, ?, NOW(), 'Dialing', ?, 'start')"
        )->execute([$campaignId, $contactId, trim(($contact['name'] ?? '') . ' ' . ($contact['last_name'] ?? '')), $contact['phone'], $tries]);
        $historyId = intval($this->pdo->lastInsertId());

        $name = trim(($contact['name'] ?? '') . ' ' . ($contact['last_name'] ?? ''));
        $this->pdo->prepare(
            "INSERT INTO active_calls (campaign_id, contact_id, call_history_id, phone, contact_name, status, current_node, started_at)
             VALUES (?, ?, ?, ?, ?, 'dialing', 'start', NOW())"
        )->execute([$campaignId, $contactId, $historyId, $contact['phone'], $name]);

        $this->addLog($campaignId, 'dial', "Звоним (sim): {$name} ({$contact['phone']}) [попытка {$tries}]");
    }

    // ----------------------------------------------------------------
    // PUBLIC: статус / аналитика
    // ----------------------------------------------------------------

    public function getLiveStatus(int $campaignId): array
    {
        $campaign = $this->getCampaign($campaignId);
        if (!$campaign) {
            return ['success' => false, 'error' => 'Кампания не найдена'];
        }

        if ($campaign['status'] === 'running') {
            $this->tick($campaignId);
            $campaign = $this->getCampaign($campaignId);
        }

        return [
            'success'       => true,
            'status'        => $campaign['status'],
            'stats'         => $this->getStats($campaignId),
            'activeCalls'   => $this->getActiveCalls($campaignId),
            'logs'          => $this->getRecentLogs($campaignId, 50),
            'totalContacts' => $this->countAllContacts($campaignId),
            'maxCalls'      => intval($campaign['max_calls']),
            'mode'          => $this->mode,
        ];
    }

    public function getAnalytics(int $campaignId, array $filters = []): array
    {
        [$whereSql, $params] = $this->buildHistoryFilterSql($campaignId, $filters, true);

        $stmt = $this->pdo->prepare(
            "SELECT ch.ivr_result, COUNT(*) as cnt
             FROM call_history ch
             LEFT JOIN contacts c ON c.id = ch.contact_id
             WHERE {$whereSql} AND ch.ivr_result IS NOT NULL GROUP BY ch.ivr_result"
        );
        $stmt->execute($params);

        $ivrPressed = ['1'=>0,'2'=>0,'3'=>0,'4'=>0,'5'=>0,'timeout'=>0,'invalid'=>0,'none'=>0,'other'=>0];
        foreach ($stmt->fetchAll() as $row) {
            $key = $row['ivr_result'];
            isset($ivrPressed[$key]) ? $ivrPressed[$key] += $row['cnt'] : $ivrPressed['other'] += $row['cnt'];
        }

        $stmt = $this->pdo->prepare(
            "SELECT ch.*,
                    COALESCE(NULLIF(ch.contact_name, ''), NULLIF(TRIM(CONCAT(COALESCE(c.name, ''), ' ', COALESCE(c.last_name, ''))), ''), CONCAT('Contact #', ch.contact_id)) as name,
                    COALESCE(c.last_name, '') as last_name,
                    COALESCE(NULLIF(ch.contact_phone, ''), c.phone, '') as phone
             FROM call_history ch LEFT JOIN contacts c ON c.id = ch.contact_id
             WHERE {$whereSql} ORDER BY ch.started_at DESC LIMIT 1000"
        );
        $stmt->execute($params);
        $history = $stmt->fetchAll();
        $this->attachCallEvents($history);

        return [
            'success'    => true,
            'stats'      => $this->getStats($campaignId, $filters),
            'ivrPressed' => $ivrPressed,
            'history'    => $history,
        ];
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private function getStats(int $campaignId, array $filters = []): array
    {
        [$whereSql, $params] = $this->buildHistoryFilterSql($campaignId, $filters, false);
        $stmt = $this->pdo->prepare(
            "SELECT ch.dial_status, COUNT(*) as cnt
             FROM call_history ch
             LEFT JOIN contacts c ON c.id = ch.contact_id
             WHERE {$whereSql}
             GROUP BY ch.dial_status"
        );
        $stmt->execute($params);
        $stats = ['answered'=>0,'retry'=>0,'failed'=>0,'dialing'=>0,'total'=>0];
        foreach ($stmt->fetchAll() as $row) {
            $cnt = intval($row['cnt']);
            $stats['total'] += $cnt;
switch ($row['dial_status']) {
    case 'Answered': $stats['answered'] += $cnt; break;
    case 'Busy':     $stats['retry']    += $cnt; break;
    case 'Failed':   $stats['failed']   += $cnt; break;
    default:         $stats['dialing']  += $cnt; break;
}
        }
        return $stats;
    }

    private function buildHistoryFilterSql(int $campaignId, array $filters, bool $alreadyJoined): array
    {
        $where = ['ch.campaign_id = ?'];
        $params = [$campaignId];

        $dateFrom = trim($filters['date_from'] ?? '');
        if ($dateFrom !== '') {
            $where[] = 'ch.started_at >= ?';
            $params[] = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom) ? "{$dateFrom} 00:00:00" : $dateFrom;
        }

        $dateTo = trim($filters['date_to'] ?? '');
        if ($dateTo !== '') {
            $where[] = 'ch.started_at <= ?';
            $params[] = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo) ? "{$dateTo} 23:59:59" : $dateTo;
        }

        $phone = trim($filters['phone'] ?? '');
        if ($phone !== '') {
            $where[] = 'COALESCE(ch.contact_phone, c.phone, "") LIKE ?';
            $params[] = '%' . $phone . '%';
        }

        $dialStatus = trim($filters['dial_status'] ?? '');
        if ($dialStatus !== '') {
            $where[] = 'ch.dial_status = ?';
            $params[] = $dialStatus;
        }

        $ivrResult = trim($filters['ivr_result'] ?? '');
        if ($ivrResult !== '') {
            if ($ivrResult === 'empty') {
                $where[] = '(ch.ivr_result IS NULL OR ch.ivr_result = "")';
            } else {
                $where[] = 'ch.ivr_result = ?';
                $params[] = $ivrResult;
            }
        }

        return [implode(' AND ', $where), $params];
    }

    private function attachCallEvents(array &$history): void
    {
        if (empty($history)) return;

        $ids = [];
        foreach ($history as $row) {
            $ids[] = intval($row['id']);
        }
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        try {
            $stmt = $this->pdo->prepare(
                "SELECT * FROM call_events WHERE call_history_id IN ({$placeholders}) ORDER BY event_at ASC, id ASC"
            );
            $stmt->execute($ids);
        } catch (Exception $e) {
            foreach ($history as &$row) {
                $row['events'] = [];
            }
            error_log(date('Y-m-d H:i:s') . " attach call_events failed: " . $e->getMessage() . "\n", 3, '/tmp/obzvon_schema_error.log');
            return;
        }

        $eventsByHistory = [];
        foreach ($stmt->fetchAll() as $event) {
            $eventsByHistory[intval($event['call_history_id'])][] = $event;
        }

        foreach ($history as &$row) {
            $row['events'] = $eventsByHistory[intval($row['id'])] ?? [];
        }
    }

    private function getActiveCalls(int $campaignId): array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM active_calls WHERE campaign_id = ? ORDER BY started_at");
        $stmt->execute([$campaignId]);
        return $stmt->fetchAll();
    }

    private function getRecentLogs(int $campaignId, int $limit): array
    {
        $stmt = $this->pdo->prepare(
            "SELECT timestamp as time, type, text FROM logs WHERE campaign_id = ? ORDER BY id DESC LIMIT ?"
        );
        $stmt->bindValue(1, $campaignId, PDO::PARAM_INT);
        $stmt->bindValue(2, $limit,      PDO::PARAM_INT);
        $stmt->execute();
        return array_reverse($stmt->fetchAll());
    }

    private function getCampaign(int $campaignId): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM campaigns WHERE id = ?");
        $stmt->execute([$campaignId]);
        return $stmt->fetch() ?: null;
    }

private function getNextContact(int $campaignId, int $maxRetries): ?array
{
    $stmt = $this->pdo->prepare(
        "SELECT c.* FROM contacts c
         WHERE c.campaign_id = ?
           AND (c.status = 'Pending' OR (c.status = 'Busy' AND c.tries < ?))
           AND c.id NOT IN (
               SELECT contact_id FROM active_calls WHERE campaign_id = ?
           )
         ORDER BY c.id LIMIT 1"
    );
    $stmt->execute([$campaignId, $maxRetries, $campaignId]);
    return $stmt->fetch() ?: null;
}
    private function countActiveCalls(int $campaignId): int
    {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM active_calls WHERE campaign_id = ?");
        $stmt->execute([$campaignId]);
        return intval($stmt->fetchColumn());
    }

    private function countContacts(int $campaignId, array $statuses): int
    {
        $ph     = implode(',', array_fill(0, count($statuses), '?'));
        $params = array_merge([$campaignId], $statuses);
        $stmt   = $this->pdo->prepare("SELECT COUNT(*) FROM contacts WHERE campaign_id = ? AND status IN ({$ph})");
        $stmt->execute($params);
        return intval($stmt->fetchColumn());
    }

    private function countRetryableContacts(int $campaignId, int $maxRetries): int
    {
        $stmt = $this->pdo->prepare(
            "SELECT COUNT(*) FROM contacts WHERE campaign_id = ? AND status = 'Busy' AND tries < ?"
        );
        $stmt->execute([$campaignId, $maxRetries]);
        return intval($stmt->fetchColumn());
    }

    private function countAllContacts(int $campaignId): int
    {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM contacts WHERE campaign_id = ?");
        $stmt->execute([$campaignId]);
        return intval($stmt->fetchColumn());
    }

    private function addLog(int $campaignId, string $type, string $text): void
    {
        $this->pdo->prepare(
            "INSERT INTO logs (campaign_id, timestamp, type, text) VALUES (?, ?, ?, ?)"
        )->execute([$campaignId, date('H:i:s'), $type, $text]);
    }

    private function ivrResultLabel(string $result): string
    {
        return [
            '1'=>'Нажал 1','2'=>'Нажал 2','3'=>'Нажал 3','4'=>'Нажал 4','5'=>'Нажал 5',
            'timeout'=>'Таймаут','invalid'=>'Ошибся','none'=>'Без ввода',
        ][$result] ?? $result;
    }
}
