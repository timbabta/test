<!DOCTYPE html> <html lang="ru"> <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crocus — Умный Автообзвон для Asterisk</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link 
href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Fira+Code:wght@400;500&display=swap" 
rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.sheetjs.com/xlsx-0.20.1/package/dist/xlsx.full.min.js"></script> </head> <body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-logo">
  <img src="logo.png" alt="Logo" class="logo-icon" style="
        width: 50px;
        height: 50px;
        object-fit: contain;
        border-radius: 8px;
    ">
                    <defs>
                        <linearGradient id="logo-grad" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#8b5cf6" />
                            <stop offset="1" stop-color="#3b82f6" />
                        </linearGradient>
                    </defs>
                </svg>
                <div class="logo-text">
                    <span class="logo-title">Crocus</span>
                    <span class="logo-subtitle">robot</span>
                </div>
            </div>
            <nav class="sidebar-menu">
                <button class="menu-item active" data-tab="campaigns">
                    <svg viewBox="0 0 24 24" class="menu-icon"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 
10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 
1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H7c0-2.76 2.24-5 5-5s5 2.24 5 5c0 1.04-.42 1.99-1.07 2.75z" 
fill="currentColor"/></svg>
                    <span>Параметры</span>
                </button>
                <button class="menu-item" data-tab="contacts">
                    <svg viewBox="0 0 24 24" class="menu-icon"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 
1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 
3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z" 
fill="currentColor"/></svg>
                    <span>База контактов</span>
                </button>
                <button class="menu-item" data-tab="audio">
                    <svg viewBox="0 0 24 24" class="menu-icon"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 
4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" fill="currentColor"/></svg>
                    <span>Аудиофайлы</span>
                </button>
                <button class="menu-item" data-tab="ivr">
                    <svg viewBox="0 0 24 24" class="menu-icon"><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 
0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z" 
fill="currentColor"/></svg>
                    <span>Конструктор IVR</span>
                </button>
                <button class="menu-item" data-tab="live">
                    <svg viewBox="0 0 24 24" class="menu-icon"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 
10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="currentColor"/></svg>
                    <span>Панель обзвона</span>
                </button>
                <button class="menu-item" data-tab="reports">
                    <svg viewBox="0 0 24 24" class="menu-icon"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 
2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z" fill="currentColor"/></svg>
                    <span>Аналитика</span>
                </button>
                <button class="menu-item" data-tab="export">
                    <svg viewBox="0 0 24 24" class="menu-icon"><path d="M19 12v7H5v-7H3v7c0 1.1.9 2 2 2h14c1.1 0 2-.9 
2-2v-7h-2zm-6 .67l2.59-2.58L17 11.5l-5 5-5-5 1.41-1.41L11 12.67V3h2v9.67z" fill="currentColor"/></svg>
                    <span>Экспорт Asterisk</span>
                </button>
            </nav>
            <div class="sidebar-status">
                <div class="status-indicator online" id="status-indicator-dot"></div>
                <div class="status-text" id="sidebar-status-text">Обработано: 0 | Осталось: 0</div>
            </div>
        </aside>
        <main class="main-content">
            <header class="content-header">
                <h1 id="panel-title">Параметры кампании</h1>
                <div class="header-actions">
                    <div class="db-status-badge" id="db-status-badge" title="Статус подключения к базе данных">
                        <span class="db-status-dot offline" id="db-status-dot"></span>
                        <span id="db-status-text">БД: проверка...</span>
                    </div>
                    <select id="campaign-selector" class="mode-selector campaign-selector" title="Выбор кампании">
                        <option value="">Загрузка...</option>
                    </select>
                    <button class="btn btn-secondary btn-small" id="btn-new-campaign" title="Создать новую кампанию">+ 
Акция</button>
                    <div class="campaign-badge" id="active-campaign-name">—</div>
                    <button class="btn btn-secondary btn-icon" id="btn-reset-all">
                        <svg viewBox="0 0 24 24" class="icon"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 
8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 
11h7V4l-2.35 2.35z" fill="currentColor"/></svg>
                        Сбросить всё
                    </button>
                </div>
            </header>
            <div class="panel-container">
                <section class="tab-panel active" id="panel-campaigns">
                    <div class="grid-2col">
                        <div class="card glass">
                            <div class="card-header">
                                <h3>Настройки кампании</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="camp-name">Имя кампании</label>
                                    <input type="text" id="camp-name" value="AutoDialer_Promo" placeholder="Например: 
AutoDialer_Promo">
                                    <small>Используется для названия папок и таблиц в Asterisk (без пробелов)</small>
                                </div>
                                <div class="form-group">
                                    <label for="sip-trunk">Канал / SIP-транк для вызова</label>
                                    <input type="text" id="sip-trunk" value="SIP/sip_trunk_name" placeholder="Например: 
SIP/my_operator или PJSIP/trunk">
                                    <small>Куда отправлять исходящий вызов (Channel в Call-файле)</small>
                                </div>
                                <div class="grid-2col-nested">
                                    <div class="form-group">
                                        <label for="max-calls">Одновременные звонки</label>
                                        <input type="number" id="max-calls" value="5" min="1" max="100">
                                        <small>Максимум линий</small>
                                    </div>
                                    <div class="form-group">
                                        <label for="wait-time">Ожидание ответа (сек)</label>
                                        <input type="number" id="wait-time" value="45" min="10" max="120">
                                        <small>WaitTime</small>
                                    </div>
                                </div>
                                <div class="grid-2col-nested">
                                    <div class="form-group">
                                        <label for="max-retries">Попытки (Max Retries)</label>
                                        <input type="number" id="max-retries" value="3" min="1" max="10">
                                        <small>Если занято/нет ответа</small>
                                    </div>
                                    <div class="form-group">
                                        <label for="retry-time">Интервал попыток (сек)</label>
                                        <input type="number" id="retry-time" value="60" min="10" max="3600">
                                        <small>RetryTime</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card glass">
                            <div class="card-header">
                                <h3>Планировщик и Запуск</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label class="switch-container">
<input type="checkbox" id="schedule-enabled">
<div style="display:flex; flex-direction:column; gap:2px;">
    <span class="switch-label">Отложенный запуск</span>
    <span style="font-size:11px; color:var(--text-muted);">Обзвон начнётся автоматически в указанное время</span>
</div>

                                        <span class="switch-label"><br>Запустить по расписанию</span>
                                    </label>
                                </div>
                                <div class="form-group" id="schedule-time-container" style="display: none;">
                                    <label for="schedule-datetime">Дата и время старта</label>
                                    <input type="datetime-local" id="schedule-datetime">
                                    <small>Система начнет обзвон автоматически в указанное время</small>
                                </div>
                                <div class="card-actions-bottom">
                                    <button class="btn btn-primary btn-large" id="btn-save-settings">Сохранить 
настройки</button>
                                </div>
                                <div class="campaigns-list-block" id="campaigns-list-block" style="margin-top: 20px;">
                                    <h4 style="margin-bottom: 10px;">Все кампании</h4>
                                    <div id="campaigns-list-container" class="campaigns-list"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="tab-panel" id="panel-contacts">
                    <div class="grid-contacts">
                        <div class="card glass">
                            <div class="card-header">
                                <h3>Загрузка списка номеров</h3>
                            </div>
                            <div class="card-body">
                                <div class="upload-dropzone" id="csv-dropzone">
                                    <svg viewBox="0 0 24 24" class="upload-icon"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 
9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 
13v4h-4v-4H7l5-5 5 5h-3z" fill="currentColor"/></svg>
                                    <p>Перетащите CSV или Excel (.xlsx) или нажмите для выбора</p>
                                    <small>Колонки: Имя, Фамилия, Телефон</small>
                                    <input type="file" id="csv-file-input" accept=".csv,.xlsx,.xls" style="display: none;">
                                </div>
                                <div class="contacts-actions">
<button class="btn btn-secondary btn-icon" id="btn-download-template-csv">
    <svg viewBox="0 0 24 24" class="icon"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z" fill="currentColor"/></svg>
    Шаблон CSV
</button>
<button class="btn btn-secondary btn-icon" id="btn-download-template-xlsx">
    <svg viewBox="0 0 24 24" class="icon"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z" fill="currentColor"/></svg>
    Шаблон Excel (.xlsx)
</button>
                                    <button class="btn btn-danger btn-icon" id="btn-clear-contacts">
                                        <svg viewBox="0 0 24 24" class="icon"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 
2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" fill="currentColor"/></svg>
                                        Очистить список
                                    </button>
                                </div>
                                <div class="contacts-summary-box">
                                    <div class="summary-metric">
                                        <span class="metric-label">Всего номеров:</span>
                                        <span class="metric-value" id="contacts-count-total">0</span>
                                    </div>
                                    <div class="summary-metric">
                                        <span class="metric-label">Корректных:</span>
                                        <span class="metric-value text-success" id="contacts-count-valid">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card glass">
                            <div class="card-header">
                                <h3>Импортированные контакты</h3>
                                <div class="card-search">
                                    <input type="text" id="contact-search" placeholder="Поиск по имени или номеру...">
                                </div>
                            </div>
                            <div class="card-body scroll-table-container">
                                <table class="data-table" id="table-contacts">
                                    <thead>
                                        <tr>
                                            <th>Имя</th>
                                            <th>Фамилия</th>
                                            <th>Телефон</th>
                                            <th>Дата рожд.</th>
                                            <th>Статус</th>
                                            <th>Действия</th>
                                        </tr>
                                    </thead>
                                    <tbody id="contacts-list-tbody">
                                        <tr>
                                            <td colspan="6" class="text-center text-muted">Список пуст. Загрузите CSV 
файл.</td>
                                        </tr>
                                    </tbody>
                                end</table>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="tab-panel" id="panel-audio">
                    <div class="grid-2col">
                        <div class="card glass">
                            <div class="card-header">
                                <h3>Загрузка аудио</h3>
                            </div>
                            <div class="card-body">
                                <div class="upload-dropzone" id="audio-dropzone">
                                    <svg viewBox="0 0 24 24" class="upload-icon"><path d="M12 
3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" fill="currentColor"/></svg>
                                    <p>Загрузите MP3, WAV или OGG файл</p>
                                    <small>Он будет автоматически конвертирован в WAV PCM 8кГц 16бит</small>
                                    <input type="file" id="audio-file-input" accept="audio/*" style="display: none;">
                                </div>
                                <div class="audio-converter-logs" id="audio-logs">
                                    </div>
                            </div>
                        </div>
                        <div class="card glass">
                            <div class="card-header">
                                <h3>Список аудиозаписей в кампании</h3>
                            </div>
                            <div class="card-body">
                                <div class="audio-playlist" id="audio-list-container">
                                    <div class="no-audio-msg text-center text-muted">
                                        Аудиофайлы не загружены. Загрузите файлы для озвучки IVR.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="tab-panel" id="panel-ivr">
                    <div class="ivr-builder-layout">
                        <div class="ivr-sidebar card glass">
                            <h4>Добавить блок</h4>
                            <div class="ivr-blocks-menu">
                                <button class="btn-block-type" data-type="play">
                                    <span class="block-color-indicator bg-purple"></span>
                                    <svg viewBox="0 0 24 24" class="block-icon"><path d="M12 
3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" fill="currentColor"/></svg>
                                    <span>Воспроизвести звук</span>
                                </button>
                                <button class="btn-block-type" data-type="ivr">
                                    <span class="block-color-indicator bg-blue"></span>
                                    <svg viewBox="0 0 24 24" class="block-icon"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 
2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2zm-2 
1H8v-6c0-2.48 1.51-4.5 4-4.5s4 2.02 4 4.5v6z" fill="currentColor"/></svg>
                                    <span>Сбор клавиш (IVR)</span>
                                </button>
                                <button class="btn-block-type" data-type="tts">
                                    <span class="block-color-indicator bg-teal"></span>
                                    <svg viewBox="0 0 24 24" class="block-icon"><path d="M12 3c-4.97 0-9 4.03-9 9 0 2.12.74 
4.07 1.97 5.61L4.35 19.4c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0l1.9-1.9C9.22 19.58 10.57 20 12 20c4.97 0 9-4.03 
9-9s-4.03-9-9-9zm0 15c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6zm-1-9h2v5h-2V9zm0-3h2v2h-2V6z" 
fill="currentColor"/></svg>
                                    <span>Текст в речь (TTS)</span>
                                </button>
                                <button class="btn-block-type" data-type="transfer">
                                    <span class="block-color-indicator bg-orange"></span>
                                    <svg viewBox="0 0 24 24" class="block-icon"><path d="M17 17h-1.55c-.27 
0-.52-.11-.7-.3l-3.24-3.24c-.45-.45-1.18-.45-1.63 0L6.64 16.7c-.18.19-.43.3-.7.3H3v-2h2.24l3.24-3.24c.78-.78.78-2.05 
0-2.83L6.24 5.7C6.05 5.51 5.8 5.4 5.53 5.4H3V3.4h2.53c.53 0 1.04.21 1.41.59l3.24 3.24c.45.45 1.18.45 1.63 
0l3.24-3.24c.37-.38.88-.59 1.41-.59H17v2h-1.55c-.27 0-.52.11-.7.3l-3.24 3.24c-.78.78-.78 2.05 0 2.83l3.24 
3.24c.18.19.43.3.7.3H17v2zm4-12h-2.93l3 3-3 3H21v-6zm0 10h-2.93l3 3-3 3H21v-6z" fill="currentColor"/></svg>
                                    <span>Перевод звонка</span>
                                </button>
                                <button class="btn-block-type" data-type="wait">
                                    <span class="block-color-indicator bg-yellow"></span>
                                    <svg viewBox="0 0 24 24" class="block-icon"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 
9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 
3.15.75-1.23-4.5-2.67V7z" fill="currentColor"/></svg>
                                    <span>Пауза ожидания</span>
                                </button>
                                <button class="btn-block-type" data-type="hangup">
                                    <span class="block-color-indicator bg-rose"></span>
                                    <svg viewBox="0 0 24 24" class="block-icon"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 
10-4.48 10-10S17.52 2 12 2zm5 11H7v-2h10v2z" fill="currentColor"/></svg>
                                    <span>Повесить трубку</span>
                                </button>
                            </div>
                            <div class="ivr-tips">
                                <h5>Подсказка:</h5>
                                <p>Блоки связываются между собой через параметры перехода в настройках каждого блока. Вся схема 
начинается с блока <strong>Начало (Start)</strong>.</p>
                            </div>
                        </div>
                        <div class="ivr-workspace">
                            <div class="ivr-toolbar">
                                <button class="btn btn-primary btn-icon" id="btn-save-ivr">
                                    <svg viewBox="0 0 24 24" class="icon" width="16" height="16"><path d="M17 3H5c-1.11 0-2 
.9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z" 
fill="currentColor"/></svg>
                                    Сохранить IVR → extensions_custom.conf
                                </button>
                                <span class="ivr-save-status text-muted" id="ivr-save-status"></span>
                            </div>
                            <div class="ivr-flow-container" id="ivr-canvas">
                                <div class="ivr-card start-card" id="node-start">
                                    <div class="node-header">
                                        <span class="node-badge">Старт</span>
                                        <h4>Начало звонка</h4>
                                    </div>
                                    <div class="node-body">
                                        <div class="form-group">
                                            <label for="start-target">Следующий блок</label>
                                            <select class="node-connector" data-node="start" id="start-target">
                                                <option value="">-- Завершить звонок --</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="tab-panel" id="panel-live">
                    <div class="live-dashboard-layout">
                        <div class="live-main-content">
                            <div class="card glass live-controls-card">
                                <div class="live-status-block">
                                    <div class="live-state-indicator idle" id="live-state-indicator"></div>
                                    <span class="live-state-text" id="live-state-text">Остановлен</span>
                                </div>
                                <div class="live-action-buttons">
                                    <button class="btn btn-success btn-icon" id="btn-live-start">
                                        <svg viewBox="0 0 24 24" class="icon"><path d="M8 5v14l11-7z" 
fill="currentColor"/></svg>
                                        Запустить
                                    </button>
                                    <button class="btn btn-warning btn-icon" id="btn-live-pause" disabled>
                                        <svg viewBox="0 0 24 24" class="icon"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" 
fill="currentColor"/></svg>
                                        Пауза
                                    </button>
                                    <button class="btn btn-danger btn-icon" id="btn-live-stop" disabled>
                                        <svg viewBox="0 0 24 24" class="icon"><path d="M6 6h12v12H6z" 
fill="currentColor"/></svg>
                                        Остановить
                                    </button>
                                </div>
                            </div>
                            <div class="live-metrics-row">
                                <div class="metric-card glass">
                                    <span class="label">Всего контактов</span>
                                    <span class="value" id="live-metric-total">0</span>
                                </div>
                                <div class="metric-card glass border-success">
                                    <span class="label">Успешно (Отвечено)</span>
                                    <span class="value text-success" id="live-metric-answered">0</span>
                                </div>
                                <div class="metric-card glass border-warning">
                                    <span class="label">Занято / Нет ответа</span>
                                    <span class="value text-warning" id="live-metric-retry">0</span>
                                </div>
                                <div class="metric-card glass border-danger">
                                    <span class="label">Недоступны / Ошибка</span>
                                    <span class="value text-danger" id="live-metric-failed">0</span>
                                </div>
                            </div>
                            <div class="card glass progress-card">
                                <div class="progress-info-row">
                                    <span>Общий прогресс обзвона</span>
                                    <span id="live-progress-percent">0%</span>
                                </div>
                                <div class="progress-bar-bg">
                                    <div class="progress-bar-fill" id="live-progress-bar" style="width: 0%;"></div>
                                </div>
                            </div>
                            <div class="card glass">
                                <div class="card-header">
                                    <h3>Активные каналы обзвона (<span id="live-active-channels-count">0</span> / <span 
id="live-max-channels-count">5</span>)</h3>
                                </div>
                                <div class="card-body">
                                    <div class="active-channels-grid" id="active-channels-container">
                                        <div class="no-active-calls-msg text-center text-muted">
                                            Нет активных вызовов в данный момент. Запустите обзвон.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card glass terminal-card">
                                <div class="card-header">
                                    <h3>Лог вызовов системы (Asterisk Spool Console)</h3>
                                    <button class="btn btn-secondary btn-small" id="btn-clear-terminal">Очистить</button>
                                </div>
                                <div class="card-body terminal-body" id="live-terminal-logs">
                                    <div class="terminal-line system">[System] Инициализация симулятора автообзвона...</div>
                                    <div class="terminal-line system">[System] Загрузите базу контактов и настройте IVR.</div>
                                </div>
                            </div>
                        </div>
                        <div class="live-sidebar-phone">
                            <div class="phone-wrapper card glass">
                                <div class="phone-screen" id="phone-screen-state">
                                    <div class="phone-state-screen" id="phone-screen-idle">
                                        <div class="phone-logo">
                                            <svg viewBox="0 0 24 24" class="phone-logo-icon"><path d="M6.62 10.79c1.44 2.83 
3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 
0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" 
fill="currentColor"/></svg>
                                        </div>
                                        <div class="phone-status-text">Ожидание входящего звонка от автообзвонщика...</div>
                                        <div class="phone-hint">При симуляции один из звонков поступит на этот телефон, чтобы 
вы могли лично протестировать созданный IVR.</div>
                                    </div>
                                    <div class="phone-state-screen" id="phone-screen-ringing" style="display: none;">
                                        <div class="phone-avatar-ring">
                                            <div class="phone-avatar" id="phone-ring-avatar">AD</div>
                                        </div>
                                        <div class="phone-caller-name" id="phone-ring-name">Иван Иванов</div>
                                        <div class="phone-caller-number" id="phone-ring-number">+7 (999) 123-45-67</div>
                                        <div class="phone-call-title">ВХОДЯЩИЙ ЗВОНОК</div>
                                        <div class="phone-ring-actions">
                                            <button class="btn-phone-action accept" id="btn-phone-accept">
                                                <svg viewBox="0 0 24 24" class="btn-phone-icon"><path d="M20 15.5c-1.25 
0-2.45-.2-3.57-.57-.35-.11-.74-.03-1.02.24l-2.2 2.2c-2.83-1.44-5.15-3.75-6.59-6.59l2.2-2.2c.28-.28.36-.67.25-1.02C8.7 6.45 8.5 
5.25 8.5 4c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1 0 9.39 7.61 17 17 17 .55 0 1-.45 1-1v-3.5c0-.55-.45-1-1-1z" 
fill="currentColor"/></svg>
                                            </button>
                                            <button class="btn-phone-action decline" id="btn-phone-decline">
                                                <svg viewBox="0 0 24 24" class="btn-phone-icon"><path d="M12 2C6.48 2 2 6.48 2 
12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11H7v-2h10v2z" fill="currentColor"/></svg>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="phone-state-screen" id="phone-screen-connected" style="display: none;">
                                        <div class="phone-connected-header">
                                            <div class="phone-conn-name" id="phone-conn-name">Иван Иванов</div>
                                            <div class="phone-conn-duration" id="phone-conn-duration">00:00</div>
                                        </div>
                                        
                                        <div class="phone-audio-player-status">
                                            <span class="phone-audio-badge">Аудио:</span>
                                            <span id="phone-current-audio-name">intro.wav</span>
                                            <div class="phone-wave-animation" id="phone-audio-wave">
                                                <span></span><span></span><span></span><span></span><span></span>
                                            </div>
                                        </div>
                                        <div class="phone-dialpad">
                                            <button class="dial-btn" data-dtmf="1">1</button>
                                            <button class="dial-btn" data-dtmf="2">2</button>
                                            <button class="dial-btn" data-dtmf="3">3</button>
                                            <button class="dial-btn" data-dtmf="4">4</button>
                                            <button class="dial-btn" data-dtmf="5">5</button>
                                            <button class="dial-btn" data-dtmf="6">6</button>
                                            <button class="dial-btn" data-dtmf="7">7</button>
                                            <button class="dial-btn" data-dtmf="8">8</button>
                                            <button class="dial-btn" data-dtmf="9">9</button>
                                            <button class="dial-btn" data-dtmf="*">*</button>
                                            <button class="dial-btn" data-dtmf="0">0</button>
                                            <button class="dial-btn" data-dtmf="#">#</button>
                                        </div>
                                        <div class="phone-ring-actions connected-actions">
                                            <button class="btn-phone-action decline" id="btn-phone-hangup">
                                                <svg viewBox="0 0 24 24" class="btn-phone-icon"><path d="M12 2C6.48 2 2 6.48 2 
12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11H7v-2h10v2z" fill="currentColor"/></svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="tab-panel" id="panel-reports">
                    <div class="reports-header-box card glass">
                        <div class="reports-header-content">
                            <h3>Аналитический отчет кампании</h3>
                            <p>Детальные показатели эффективности автообзвона и активности IVR</p>
                        </div>
                        <div class="reports-actions-row">
                            <button class="btn btn-secondary btn-icon" id="btn-export-excel">
                                <svg viewBox="0 0 24 24" class="icon"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 
5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM19 15l-7 
7-7-7h4V9h6v6h4z" fill="currentColor"/></svg>
                                Выгрузить в Excel (CSV)
                            </button>
                            <button class="btn btn-primary btn-icon" id="btn-export-pdf">
                                <svg viewBox="0 0 24 24" class="icon"><path d="M19 8H5c-1.66 0-3 1.34-3 
3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z" 
fill="currentColor"/></svg>
                                Экспортировать в PDF
                            </button>
                        </div>
                    </div>
                    <div class="grid-2col">
                        <div class="card glass">
                            <div class="card-header">
                                <h3>Конверсия звонков (Воронка дозвона)</h3>
                            </div>
                            <div class="card-body chart-container-wrapper">
                                <div class="chart-donut-container">
                                    <svg viewBox="0 0 36 36" class="donut-chart" id="svg-donut">
                                        <circle class="donut-ring" cx="18" cy="18" r="15.915" fill="transparent" 
stroke="#1f2937" stroke-width="3"></circle>
                                        <circle class="donut-segment segment-answered" id="donut-segment-ans" cx="18" cy="18" 
r="15.915" fill="transparent" stroke="#10b981" stroke-width="3" stroke-dasharray="0 100" stroke-dashoffset="25"></circle>
                                        <circle class="donut-segment segment-busy" id="donut-segment-busy" cx="18" cy="18" 
r="15.915" fill="transparent" stroke="#f59e0b" stroke-width="3" stroke-dasharray="0 100" stroke-dashoffset="25"></circle>
                                        <circle class="donut-segment segment-failed" id="donut-segment-fail" cx="18" cy="18" 
r="15.915" fill="transparent" stroke="#f43f5e" stroke-width="3" stroke-dasharray="0 100" stroke-dashoffset="25"></circle>
                                    </svg>
                                    <div class="donut-center-text">
                                        <span class="donut-percent" id="report-conversion-percent">0%</span>
                                        <span class="donut-label">Дозвон</span>
                                    </div>
                                </div>
                                <div class="chart-legend">
                                    <div class="legend-item"><span class="legend-color bg-success"></span>Отвечено: <span 
id="report-legend-ans">0</span></div>
                                    <div class="legend-item"><span class="legend-color bg-warning"></span>Занято/Ретраи: <span 
id="report-legend-busy">0</span></div>
                                    <div class="legend-item"><span class="legend-color bg-danger"></span>Сбой/Недоступен: <span 
id="report-legend-fail">0</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="card glass">
                            <div class="card-header">
                                <h3>Статистика нажатий в IVR</h3>
                            </div>
                            <div class="card-body chart-container-wrapper">
                                <div class="bar-chart-container" id="ivr-bar-chart">
                                    <div class="bar-item">
                                        <div class="bar-label">Кнопка 1</div>
                                        <div class="bar-value-wrapper">
                                            <div class="bar-fill bg-purple" id="bar-ivr-1" style="width: 0%;"></div>
                                            <span class="bar-value-text" id="bar-ivr-1-text">0% (0)</span>
                                        </div>
                                    </div>
                                    <div class="bar-item">
                                        <div class="bar-label">Кнопка 2</div>
                                        <div class="bar-value-wrapper">
                                            <div class="bar-fill bg-blue" id="bar-ivr-2" style="width: 0%;"></div>
                                            <span class="bar-value-text" id="bar-ivr-2-text">0% (0)</span>
                                        </div>
                                    </div>
                                    <div class="bar-item">
                                        <div class="bar-label">Кнопка 3</div>
                                        <div class="bar-value-wrapper">
                                            <div class="bar-fill bg-teal" id="bar-ivr-3" style="width: 0%;"></div>
                                            <span class="bar-value-text" id="bar-ivr-3-text">0% (0)</span>
                                        </div>
                                    </div>
                                    <div class="bar-item">
                                        <div class="bar-label">Кнопка 4</div>
                                        <div class="bar-value-wrapper">
                                            <div class="bar-fill bg-orange" id="bar-ivr-4" style="width: 0%;"></div>
                                            <span class="bar-value-text" id="bar-ivr-4-text">0% (0)</span>
                                        </div>
                                    </div>
                                    <div class="bar-item">
                                        <div class="bar-label">Кнопка 5</div>
                                        <div class="bar-value-wrapper">
                                            <div class="bar-fill bg-purple" id="bar-ivr-5" style="width: 0%;"></div>
                                            <span class="bar-value-text" id="bar-ivr-5-text">0% (0)</span>
                                        </div>
                                    </div>
                                    <div class="bar-item">
                                        <div class="bar-label">Ошибся / другие</div>
                                        <div class="bar-value-wrapper">
                                            <div class="bar-fill bg-yellow" id="bar-ivr-other" style="width: 0%;"></div>
                                            <span class="bar-value-text" id="bar-ivr-other-text">0% (0)</span>
                                        </div>
                                    </div>
                                    <div class="bar-item">
                                        <div class="bar-label">Без ввода (Таймаут)</div>
                                        <div class="bar-value-wrapper">
                                            <div class="bar-fill bg-rose" id="bar-ivr-timeout" style="width: 0%;"></div>
                                            <span class="bar-value-text" id="bar-ivr-timeout-text">0% (0)</span>
                                        </div>
                                    </div>
                                    <div class="bar-item">
                                        <div class="bar-label">Не нажал ничего</div>
                                        <div class="bar-value-wrapper">
                                            <div class="bar-fill bg-yellow" id="bar-ivr-none" style="width: 0%;"></div>
                                            <span class="bar-value-text" id="bar-ivr-none-text">0% (0)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card glass">
                        <div class="card-header">
                            <h3>Детализация всех совершенных звонков</h3>
                        </div>
                        <div class="report-filters">
                            <input type="date" id="report-date-from" title="Дата с">
                            <input type="date" id="report-date-to" title="Дата по">
                            <input type="search" id="report-phone-filter" placeholder="Телефон">
                            <select id="report-status-filter" title="Статус">
                                <option value="">Все статусы</option>
                                <option value="Answered">Отвечено</option>
                                <option value="Busy">Занято / повтор</option>
                                <option value="Failed">Ошибка</option>
                                <option value="Pending">В процессе</option>
                            </select>
                            <select id="report-ivr-filter" title="IVR">
                                <option value="">Все IVR</option>
                                <option value="1">Нажал 1</option>
                                <option value="2">Нажал 2</option>
                                <option value="3">Нажал 3</option>
                                <option value="4">Нажал 4</option>
                                <option value="5">Нажал 5</option>
                                <option value="timeout">Таймаут</option>
                                <option value="invalid">Ошибка ввода</option>
                                <option value="none">Не нажал ничего</option>
                                <option value="empty">Пусто</option>
                            </select>
                            <button class="btn btn-secondary btn-small" id="btn-report-reset" type="button">Сброс</button>
                        </div>
                        <div class="card-body scroll-table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Имя контакта</th>
                                        <th>Телефон</th>
                                        <th>Дата/Время</th>
                                        <th>Статус звонка</th>
                                        <th>Попыток</th>
                                        <th>Результат IVR</th>
                                        <th>Длительность</th>
                                        <th>Запись</th>
                                        <th>Хронология</th>
                                    </tr>
                                </thead>
                                <tbody id="report-history-tbody">
                                    <tr>
                                        <td colspan="9" class="text-center text-muted">Звонки ещё не совершались.</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
                <section class="tab-panel" id="panel-export">
                    <div class="export-layout">
                        <div class="export-sidebar">
                            <div class="card glass">
                                <div class="card-header">
                                    <h3>Скачать конфигурации</h3>
                                </div>
                                <div class="card-body export-actions-card">
                                    <button class="btn btn-primary btn-large btn-icon btn-block-width" 
id="btn-download-dialplan">
                                        <svg viewBox="0 0 24 24" class="icon"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 
18v2h14v-2H5z" fill="currentColor"/></svg>
                                        Скачать extensions_custom.conf
                                    </button>
                                    <button class="btn btn-success btn-large btn-icon btn-block-width" 
id="btn-download-shell-script">
                                        <svg viewBox="0 0 24 24" class="icon"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 
18v2h14v-2H5z" fill="currentColor"/></svg>
                                        Скачать скрипт .call файлов
                                    </button>
                                    <button class="btn btn-purple btn-large btn-icon btn-block-width" 
id="btn-download-sounds-zip" style="display: none;">
                                        <svg viewBox="0 0 24 24" class="icon"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 
18v2h14v-2H5z" fill="currentColor"/></svg>
                                        Скачать WAV Аудио (ZIP)
                                    </button>
                                    <div class="export-badge-info">
                                        Все файлы автоматически сформированы на основе ваших параметров и схемы IVR!
                                    </div>
                                </div>
                            </div>
                            <div class="card glass">
                                <div class="card-header">
                                    <h3>Как перенести в Asterisk</h3>
                                </div>
                                <div class="card-body installation-guide">
                                    <ol>
                                        <li>Поместите сгенерированный диалплан в ваш файл 
<code>/etc/asterisk/extensions_custom.conf</code>.</li>
                                        <li>Выполните в консоли Asterisk команду: <br><code>asterisk -rx "dialplan 
reload"</code>.</li>
                                        <li>Скачайте и загрузите сконвертированные аудиофайлы в папку 
<code>/var/lib/asterisk/sounds/dialer-sounds/</code>.</li>
                                        <li>Загрузите сгенерированный bash-скрипт (например, <code>run_dialer.sh</code>) на ваш 
сервер.</li>
                                        <li>Запустите скрипт через терминал: <br><code>bash run_dialer.sh</code>. Он 
автоматически создаст Call-файлы с учетом ограничений на количество каналов и интервалы повторов.</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <div class="export-main-view">
                            <div class="card glass code-preview-card">
                                <div class="card-header code-preview-header">
                                    <div class="code-tabs">
                                        <button class="code-tab-btn active" 
data-code="dialplan">extensions_custom.conf</button>
                                        <button class="code-tab-btn" data-code="shell">run_dialer.sh (Скрипт запуска)</button>
                                    </div>
                                    <button class="btn btn-secondary btn-small" id="btn-copy-code">Копировать</button>
                                </div>
                                <div class="card-body code-body-wrapper">
                                    <pre><code class="code-view" id="code-display-area">; Загрузите настройки или соберите IVR 
для генерации кода.</code></pre>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </main>
    </div>
    <div class="modal-overlay" id="node-settings-modal" style="display: none;">
        <div class="modal-content card glass">
            <div class="modal-header">
                <h3 id="modal-node-title">Настройки блока</h3>
                <button class="btn-close-modal" id="btn-close-node-modal">&times;</button>
            </div>
            <div class="modal-body" id="modal-node-body">
                </div>
            <div class="modal-footer">
                <button class="btn btn-danger" id="btn-delete-node">Удалить блок</button>
                <button class="btn btn-primary" id="btn-save-node-settings">Сохранить</button>
            </div>
        </div>
    </div>
    <script src="app.js"></script> </body>
</html>
