-- =====================================================================
-- СХЕМА БАЗЫ ДАННЫХ SMARTDIALER FLOW v2 (MYSQL / MARIADB)
-- Поддержка нескольких кампаний, истории звонков, IVR 1-5
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `smartdialer_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smartdialer_db`;

-- 1. КАМПАНИИ ОБЗВОНА (можно запускать несколько одновременно)
CREATE TABLE IF NOT EXISTS `campaigns` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `trunk` VARCHAR(100) NOT NULL DEFAULT 'SIP/sip_trunk_name',
    `max_calls` INT NOT NULL DEFAULT 5,
    `wait_time` INT NOT NULL DEFAULT 45,
    `max_retries` INT NOT NULL DEFAULT 3,
    `retry_time` INT NOT NULL DEFAULT 60,
    `schedule_enabled` TINYINT(1) NOT NULL DEFAULT 0,
    `schedule_time` DATETIME NULL,
    `ivr_flow` LONGTEXT NULL,
    `status` VARCHAR(20) NOT NULL DEFAULT 'idle',
    `dialer_started_at` DATETIME NULL,
    `dialer_stopped_at` DATETIME NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    INDEX `idx_campaigns_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. КОНТАКТЫ ДЛЯ ОБЗВОНА
CREATE TABLE IF NOT EXISTS `contacts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `campaign_id` INT NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `last_name` VARCHAR(100) NULL,
    `phone` VARCHAR(30) NOT NULL,
    `birth_date` VARCHAR(50) NULL,
    `status` VARCHAR(20) NOT NULL DEFAULT 'Pending',
    `tries` INT NOT NULL DEFAULT 0,
    `last_call_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON DELETE CASCADE,
    INDEX `idx_contacts_campaign` (`campaign_id`),
    INDEX `idx_contacts_status` (`status`),
    INDEX `idx_contacts_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. АУДИОФАЙЛЫ (base64 для веб-плеера + путь на диске для Asterisk)
CREATE TABLE IF NOT EXISTS `audio_files` (
    `id` VARCHAR(50) PRIMARY KEY,
    `campaign_id` INT NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `duration` FLOAT NOT NULL DEFAULT 0,
    `size_bytes` INT NOT NULL DEFAULT 0,
    `file_path` VARCHAR(500) NULL,
    `data_base64` LONGTEXT NULL,
    `created_at` DATETIME NULL,
    FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON DELETE CASCADE,
    INDEX `idx_audio_campaign` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. ИСТОРИЯ ЗВОНКОВ (аналитика, IVR 1-5 / timeout / invalid / none)
CREATE TABLE IF NOT EXISTS `call_history` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `campaign_id` INT NOT NULL,
    `contact_id` INT NOT NULL,
    `contact_name` VARCHAR(200) NULL,
    `contact_phone` VARCHAR(30) NULL,
    `started_at` DATETIME NOT NULL,
    `ended_at` DATETIME NULL,
    `duration_sec` INT NOT NULL DEFAULT 0,
    `dial_status` VARCHAR(20) NOT NULL DEFAULT 'Pending',
    `ivr_result` VARCHAR(20) NULL,
    `recording_file` VARCHAR(500) NULL,
    `recording_url` VARCHAR(500) NULL,
    `hangup_cause` VARCHAR(50) NULL,
    `asterisk_uniqueid` VARCHAR(80) NULL,
    `tries` INT NOT NULL DEFAULT 1,
    `current_node` VARCHAR(100) NULL,
    `notes` TEXT NULL,
    FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`contact_id`) REFERENCES `contacts`(`id`) ON DELETE CASCADE,
    INDEX `idx_history_campaign` (`campaign_id`),
    INDEX `idx_history_contact` (`contact_id`),
    INDEX `idx_history_started` (`started_at`),
    INDEX `idx_history_dial_status` (`dial_status`),
    INDEX `idx_history_ivr_result` (`ivr_result`),
    INDEX `idx_history_recording` (`recording_file`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `call_events` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `call_history_id` INT NOT NULL,
    `campaign_id` INT NOT NULL,
    `contact_id` INT NOT NULL,
    `event_at` DATETIME NOT NULL,
    `event_type` VARCHAR(40) NOT NULL,
    `node_id` VARCHAR(100) NULL,
    `node_name` VARCHAR(200) NULL,
    `dtmf_digit` VARCHAR(10) NULL,
    `destination` VARCHAR(100) NULL,
    `operator_number` VARCHAR(100) NULL,
    `queue_number` VARCHAR(100) NULL,
    `details` TEXT NULL,
    `asterisk_uniqueid` VARCHAR(80) NULL,
    INDEX `idx_call_events_history` (`call_history_id`),
    INDEX `idx_call_events_campaign` (`campaign_id`),
    INDEX `idx_call_events_type` (`event_type`),
    INDEX `idx_call_events_at` (`event_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. АКТИВНЫЕ ЗВОНКИ (мониторинг в реальном времени)
CREATE TABLE IF NOT EXISTS `active_calls` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `campaign_id` INT NOT NULL,
    `contact_id` INT NOT NULL,
    `call_history_id` INT NULL,
    `phone` VARCHAR(30) NOT NULL,
    `contact_name` VARCHAR(200) NOT NULL,
    `status` VARCHAR(20) NOT NULL DEFAULT 'dialing',
    `current_node` VARCHAR(100) NULL DEFAULT 'start',
    `started_at` DATETIME NOT NULL,
    `duration_sec` INT NOT NULL DEFAULT 0,
    FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`contact_id`) REFERENCES `contacts`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`call_history_id`) REFERENCES `call_history`(`id`) ON DELETE SET NULL,
    INDEX `idx_active_campaign` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. ЛОГИ СОБЫТИЙ
CREATE TABLE IF NOT EXISTS `logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `campaign_id` INT NOT NULL,
    `timestamp` VARCHAR(50) NOT NULL,
    `type` VARCHAR(20) NOT NULL,
    `text` TEXT NOT NULL,
    FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON DELETE CASCADE,
    INDEX `idx_logs_campaign` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дефолтная кампания
INSERT IGNORE INTO `campaigns` (`name`, `trunk`, `ivr_flow`, `status`)
VALUES (
    'AutoDialer_Promo',
    'SIP/sip_trunk_name',
    '[{"id":"start","type":"start","name":"Начало звонка","target":""}]',
    'idle'
);
