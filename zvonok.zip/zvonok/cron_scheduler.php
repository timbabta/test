<?php
// cron_scheduler.php — запускать каждую минуту через cron
// Проверяет кампании с расписанием и запускает их в нужное время
//
// Установка: crontab -e
// * * * * * php /var/www/html/zvonok/cron_scheduler.php >> /var/log/smartdialer_cron.log 2>&1

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/dialer_engine.php';

$pdo = new PDO(
    "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4",
    $db_user, $db_pass,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

// Ищем кампании у которых:
// - schedule_enabled = 1
// - status = 'idle' (ещё не запущена)
// - schedule_time <= NOW() (время пришло)
// - schedule_time >= NOW() - 2 минуты (не старше 2 минут — защита от повтора)
$stmt = $pdo->query(
    "SELECT * FROM campaigns
     WHERE schedule_enabled = 1
       AND status = 'idle'
       AND schedule_time IS NOT NULL
       AND schedule_time <= NOW()
       AND schedule_time >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)"
);
$campaigns = $stmt->fetchAll();

if (empty($campaigns)) {
    echo date('Y-m-d H:i:s') . " — нет кампаний для запуска\n";
    exit(0);
}

$dialer = new DialerEngine($pdo, $dialer_mode ?? 'simulation');

foreach ($campaigns as $campaign) {
    echo date('Y-m-d H:i:s') . " — запускаем кампанию: {$campaign['name']}\n";
    $result = $dialer->startCampaign(intval($campaign['id']));

    if ($result['success']) {
        // Сбрасываем расписание чтобы не запустить повторно
        $pdo->prepare(
            "UPDATE campaigns SET schedule_enabled = 0 WHERE id = ?"
        )->execute([$campaign['id']]);
        echo date('Y-m-d H:i:s') . " — ОК: {$campaign['name']} запущена\n";
    } else {
        echo date('Y-m-d H:i:s') . " — ОШИБКА: {$campaign['name']}: {$result['error']}\n";
    }
}
