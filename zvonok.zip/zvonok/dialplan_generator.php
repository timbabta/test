<?php
// =====================================================================
// ГЕНЕРАТОР ДИАЛПЛАНА ASTERISK (extensions_custom.conf)
// Каждый IVR-блок получает отдельный контекст — без коллизий exten
// AGI-callback пишет результат звонка в MySQL после завершения
// =====================================================================

class DialplanGenerator
{
    private $campaign;
    private $nodes;
    private $audioFiles;
    private $campName;

    public function __construct(array $campaign, array $nodes, array $audioFiles)
    {
        $this->campaign   = $campaign;
        $this->nodes      = $nodes;
        $this->audioFiles = $audioFiles;
        $this->campName   = preg_replace('/[^a-zA-Z0-9_]/', '_', $campaign['name'] ?? 'campaign');
    }

    public function generate(): string
    {
        $code  = ";====================================================================\n";
        $code .= "; АВТОГЕНЕРИРОВАННЫЙ ДИАЛПЛАН: {$this->campName}\n";
        $code .= "; SmartDialer Flow — " . date('Y-m-d H:i:s') . "\n";
        $code .= ";====================================================================\n\n";

        $code .= $this->buildOutboundContext();
        $code .= $this->buildIvrContexts();

        return $code;
    }

    // ----------------------------------------------------------------
    // Контекст набора номера
    // ----------------------------------------------------------------
    private function buildOutboundContext(): string
    {
        $trunk = $this->campaign['trunk'] ?? 'SIP/sip_trunk_name';
        $wait  = intval($this->campaign['waitTime'] ?? $this->campaign['wait_time'] ?? 45);
        $camp  = $this->campName;

        $code  = "[dialer-outbound-{$camp}]\n";
        $code .= "exten => s,1,NoOp(*** SmartDialer: вызов \${NUM} ***)\n";
        $code .= " same => n,Set(CDR(accountcode)=DIALER_{$camp})\n";
        $code .= " same => n,Set(CDR(userfield)=\${NUM})\n";
        $code .= " same => n,Set(__IVR_RESULT=none)\n";
        $code .= " same => n,Dial({$trunk}/\${NUM},{$wait},t)\n";
        $code .= " same => n,GotoIf(\$[\"\${DIALSTATUS}\" = \"ANSWER\"]?answered:failed)\n";
        $code .= " same => n(answered),Goto(dialer-ivr-{$camp},s,1)\n";
        $code .= " same => n(failed),NoOp(--- Результат: \${DIALSTATUS} ---)\n";
        $code .= " same => n,Hangup()\n\n";

        return $code;
    }

    // ----------------------------------------------------------------
    // Главный IVR-контекст + все дочерние контексты
    // ----------------------------------------------------------------
    private function buildIvrContexts(): string
    {
        $camp = $this->campName;

        $code  = "; --- IVR сценарий кампании {$camp} ---\n";
        $code .= "[dialer-ivr-{$camp}]\n";
        $code .= "exten => s,1,Answer()\n";
        $code .= " same => n,NoOp(=== Абонент ответил. Запуск IVR ===)\n";
        $code .= " same => n,Set(__IVR_RESULT=none)\n";
        $code .= " same => n,Set(__RECORDING_FILE={$this->recordingPath()}/\${STRFTIME(\${EPOCH},,%Y%m%d-%H%M%S)}_\${CAMPAIGN_ID}_\${CONTACT_ID}_\${HISTORY_ID}_\${UNIQUEID}.wav)\n";
        $code .= " same => n,MixMonitor(\${RECORDING_FILE})\n";
        $code .= $this->eventLine('answered', 'start', 'Answered', '', '');

        $startNode = $this->findNode('start');
        if ($startNode && !empty($startNode['target'])) {
            $code .= " same => n,Goto(dialer-ivr-{$camp}-{$startNode['target']},s,1)\n";
        } else {
            $code .= " same => n,Hangup()\n";
        }

        // h-extension: вызывается при любом завершении звонка — пишет результат в БД
        $code .= "\n; Завершение звонка — AGI callback пишет результат в MySQL\n";
$code .= "exten => h,1,NoOp(=== Завершение: HIST=\${HISTORY_ID} CAMP=\${CAMPAIGN_ID} CONT=\${CONTACT_ID} ===)\n";
$code .= $this->eventLine('hangup', 'h', 'Hangup', '${IVR_RESULT}', '');
$code .= " same => n,AGI(/var/lib/asterisk/agi-bin/agi_callback.php,\${HISTORY_ID},\${CAMPAIGN_ID},\${CONTACT_ID},\${HANGUPCAUSE},\${IVR_RESULT},\${CDR(billsec)},\${RECORDING_FILE},\${UNIQUEID})\n";
        $code .= "\n";

        foreach ($this->nodes as $node) {
            if ($node['id'] === 'start') continue;
            $code .= $this->buildNodeContext($node);
        }

        return $code;
    }

    // ----------------------------------------------------------------
    // Контекст одного узла IVR
    // ----------------------------------------------------------------
    private function buildNodeContext(array $node): string
    {
        $camp = $this->campName;
        $ctx  = "dialer-ivr-{$camp}-{$node['id']}";
        $code = "[{$ctx}]\n";
        $nodeId = $this->escapeArg($node['id'] ?? '');
        $nodeName = $this->escapeArg($node['name'] ?? ($node['type'] ?? 'node'));

        switch ($node['type']) {
case 'play':
    $sound = $this->getSoundName($node['audioId'] ?? '');
    if ($sound) {
        $code .= "exten => s,1,NoOp(=== Воспроизведение: {$sound} ===)\n";
        $code .= $this->eventLine('node_enter', $nodeId, $nodeName, '', '');
        $code .= " same => n,Playback({$sound})\n";
    } else {
        $code .= "exten => s,1,NoOp(=== ОШИБКА: аудиофайл не выбран ===)\n";
    }
    $code .= $this->gotoNext($node['target'] ?? '');
    break;

            case 'tts':
                $text  = addslashes($node['text'] ?? '');
                $code .= "exten => s,1,NoOp(=== TTS: {$text} ===)\n";
                $code .= $this->eventLine('node_enter', $nodeId, $nodeName, '', '');
                $code .= " same => n,Festival(\"{$text}\")\n";
                $code .= $this->gotoNext($node['target'] ?? '');
                break;

            case 'wait':
                $sec   = intval($node['seconds'] ?? 5);
                $code .= "exten => s,1,NoOp(=== Wait {$sec} ===)\n";
                $code .= $this->eventLine('node_enter', $nodeId, $nodeName, '', '');
                $code .= " same => n,Wait({$sec})\n";
                $code .= $this->gotoNext($node['target'] ?? '');
                break;

            case 'transfer':
                $dest  = $node['destination'] ?? '701';
                $code .= "exten => s,1,NoOp(=== Перевод на {$dest} ===)\n";
                $code .= $this->eventLine('transfer_start', $nodeId, $nodeName, '', $this->escapeArg($dest));
                $code .= " same => n,Set(__IVR_RESULT=transfer)\n";
                $code .= " same => n,Dial(Local/{$dest}@from-internal,60,tr)\n";
                $code .= $this->eventLine('transfer_end', $nodeId, $nodeName, '${DIALSTATUS}', $this->escapeArg($dest) . ' operator=${DIALEDPEERNUMBER}');
                $code .= " same => n,Hangup()\n";
                break;

            case 'hangup':
                $code .= "exten => s,1,Hangup()\n";
                break;

case 'ivr':
    $sound   = $this->getSoundName($node['audioId'] ?? '');
    $branches = $node['branches'] ?? [];
    $timeout  = intval($node['timeout'] ?? 10);

    $code .= "exten => s,1,NoOp(=== IVR меню: {$node['name']} ===)\n";
    $code .= $this->eventLine('node_enter', $nodeId, $nodeName, '', '');
    if ($sound) {
        $code .= " same => n,Background({$sound})\n";
    }
    $code .= " same => n,WaitExten({$timeout})\n";

                // Кнопки 1–5
                for ($i = 1; $i <= 5; $i++) {
                    $key    = (string)$i;
                    $target = $branches[$key] ?? '';
                    if ($target) {
                        $code .= "exten => {$key},1,NoOp(*** Нажата клавиша {$key} ***)\n";
                        $code .= " same => n,Set(__IVR_RESULT={$key})\n";           // <-- запоминаем нажатую кнопку
                        $code .= " same => n,Set(CDR(userfield)=IVR_{$key})\n";
                        $code .= $this->eventLine('dtmf', $nodeId, $nodeName, $key, '');
                        $code .= " same => n,Goto(dialer-ivr-{$camp}-{$target},s,1)\n";
                    }
                }

                // Таймаут
                $timeoutTarget = $branches['timeout'] ?? '';
                $code .= "exten => t,1,NoOp(*** Таймаут IVR ***)\n";
                $code .= " same => n,Set(__IVR_RESULT=timeout)\n";
                $code .= $this->eventLine('timeout', $nodeId, $nodeName, 'timeout', '');
                if ($timeoutTarget) {
                    $code .= " same => n,Set(CDR(userfield)=IVR_timeout)\n";
                    $code .= " same => n,Goto(dialer-ivr-{$camp}-{$timeoutTarget},s,1)\n";
                } else {
                    $code .= " same => n,Hangup()\n";
                }

                // Неверный ввод
                $invalidTarget = $branches['invalid'] ?? '';
                $code .= "exten => i,1,NoOp(*** Неверный ввод ***)\n";
                $code .= " same => n,Set(__IVR_RESULT=invalid)\n";
                $code .= $this->eventLine('invalid', $nodeId, $nodeName, 'invalid', '');
                if ($invalidTarget) {
                    $code .= " same => n,Set(CDR(userfield)=IVR_invalid)\n";
                    $code .= " same => n,Goto(dialer-ivr-{$camp}-{$invalidTarget},s,1)\n";
                } else {
                    $code .= " same => n,Hangup()\n";
                }
                break;

		default:
                $code .= "exten => s,1,Hangup()\n";
        }

        // Пробрасываем h в главный контекст где живёт AGI
        $code .= "exten => h,1,Goto(dialer-ivr-{$this->campName},h,1)\n";

        return $code . "\n";
    }
    private function gotoNext(?string $targetId): string
    {
        if ($targetId) {
            return " same => n,Goto(dialer-ivr-{$this->campName}-{$targetId},s,1)\n";
        }
        return " same => n,Hangup()\n";
    }


private function getSoundName(?string $audioId): string
{
    if (!$audioId) return 'intro';
    foreach ($this->audioFiles as $audio) {
        if (($audio['id'] ?? '') === $audioId) {
            if (!empty($audio['filePath'])) {
                $path = preg_replace('/\.[^.]+$/', '', $audio['filePath']);
                if (preg_match('#/sounds/(.+)$#', $path, $m)) {
                    return $m[1];
                }
                return basename($path);
            }
        }
    }
    return 'intro'; // ← всегда string, никогда null
}

    private function recordingPath(): string
    {
        global $recordings_base_dir;
        $dir = $recordings_base_dir ?? '/var/spool/asterisk/monitor/dialer';
        return rtrim($dir, '/');
    }

    private function eventLine(string $type, string $nodeId, string $nodeName, string $digit, string $destination): string
    {
        return " same => n,AGI(/var/lib/asterisk/agi-bin/agi_event.php,\${HISTORY_ID},\${CAMPAIGN_ID},\${CONTACT_ID},{$type},{$nodeId},{$nodeName},{$digit},{$destination},\${UNIQUEID})\n";
    }

    private function escapeArg(?string $value): string
    {
        $value = (string)$value;
        $value = str_replace([',', "\r", "\n"], [' ', ' ', ' '], $value);
        return trim($value);
    }

    private function findNode(string $id): ?array
    {
        foreach ($this->nodes as $node) {
            if (($node['id'] ?? '') === $id) return $node;
        }
        return null;
    }
}
