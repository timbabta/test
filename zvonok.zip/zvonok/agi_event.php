<?php
$rootCandidates = [
    getenv('SMARTDIALER_ROOT') ?: '',
    '/var/www/html/obzvon',
    '/var/www/html/zvonok',
    dirname(__DIR__),
];

$configPath = '';
foreach ($rootCandidates as $root) {
    if ($root && file_exists(rtrim($root, '/') . '/config.php')) {
        $configPath = rtrim($root, '/') . '/config.php';
        break;
    }
}

if (!file_exists($configPath)) {
    file_put_contents('/tmp/agi_event_error.log', date('Y-m-d H:i:s') . " config.php not found\n", FILE_APPEND);
    exit(1);
}
require_once $configPath;

$agiVars = [];
while (($line = fgets(STDIN)) !== false) {
    $line = trim($line);
    if ($line === '') break;
    if (strpos($line, ':') !== false) {
        [$k, $v] = explode(':', $line, 2);
        $agiVars[trim($k)] = trim($v);
    }
}

function agiArg(string $key, string $default = ''): string
{
    global $agiVars;
    return $agiVars[$key] ?? $_ENV[$key] ?? getenv($key) ?: $default;
}

$historyId = intval(agiArg('agi_arg_1'));
$campaignId = intval(agiArg('agi_arg_2'));
$contactId = intval(agiArg('agi_arg_3'));
$eventType = trim(agiArg('agi_arg_4', 'event'));
$nodeId = trim(agiArg('agi_arg_5', ''));
$nodeName = trim(agiArg('agi_arg_6', ''));
$digit = trim(agiArg('agi_arg_7', ''));
$destination = trim(agiArg('agi_arg_8', ''));
$uniqueId = trim(agiArg('agi_arg_9', ''));

if (!$historyId || !$campaignId || !$contactId) {
    file_put_contents('/tmp/agi_event.log', date('Y-m-d H:i:s') . " missing ids\n", FILE_APPEND);
    exit(1);
}

try {
    $pdo = new PDO(
        "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4",
        $db_user,
        $db_pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $pdo->exec("CREATE TABLE IF NOT EXISTS call_events (
        id INT AUTO_INCREMENT PRIMARY KEY,
        call_history_id INT NOT NULL,
        campaign_id INT NOT NULL,
        contact_id INT NOT NULL,
        event_at DATETIME NOT NULL,
        event_type VARCHAR(40) NOT NULL,
        node_id VARCHAR(100) NULL,
        node_name VARCHAR(200) NULL,
        dtmf_digit VARCHAR(10) NULL,
        destination VARCHAR(100) NULL,
        operator_number VARCHAR(100) NULL,
        queue_number VARCHAR(100) NULL,
        details TEXT NULL,
        asterisk_uniqueid VARCHAR(80) NULL,
        INDEX idx_call_events_history (call_history_id),
        INDEX idx_call_events_campaign (campaign_id),
        INDEX idx_call_events_type (event_type),
        INDEX idx_call_events_at (event_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $queueNumber = null;
    $operatorNumber = null;
    if (stripos($destination, 'queue') !== false || preg_match('/^\d+$/', $destination)) {
        $queueNumber = $destination;
    } elseif ($destination !== '') {
        $operatorNumber = $destination;
    }

    $pdo->prepare(
        "INSERT INTO call_events
         (call_history_id, campaign_id, contact_id, event_at, event_type, node_id, node_name, dtmf_digit, destination, operator_number, queue_number, details, asterisk_uniqueid)
         VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )->execute([
        $historyId,
        $campaignId,
        $contactId,
        $eventType,
        $nodeId ?: null,
        $nodeName ?: null,
        $digit ?: null,
        $destination ?: null,
        $operatorNumber,
        $queueNumber,
        null,
        $uniqueId ?: null,
    ]);

    file_put_contents('/tmp/agi_event.log', date('Y-m-d H:i:s') . " {$historyId} {$eventType} {$nodeId} {$digit} {$destination}\n", FILE_APPEND);
} catch (Exception $e) {
    file_put_contents('/tmp/agi_event_error.log', date('Y-m-d H:i:s') . " " . $e->getMessage() . "\n", FILE_APPEND);
    exit(1);
}

exit(0);
